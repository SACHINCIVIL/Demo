require("dotenv").config();
const fs = require("fs");
const path = require("path");

const TARGET_DIRS = [path.join(__dirname, "public", "files")];

const HOURS = parseInt(process.env.CLEANUP_DURATION_HOURS || "24", 10);
const cutoff = Date.now() - HOURS * 60 * 60 * 1000;

const validExtensions = [".doc", ".docx", ".xlsx", ".ppt", ".pptx", ".pdf"];

console.log(`🚀 Cleanup started | Deleting files older than ${HOURS} hours`);

TARGET_DIRS.forEach((dir) => {
  fs.readdir(dir, (err, files) => {
    if (err) {
      console.error(`Error reading ${dir}:`, err.message);
      return;
    }

    files.forEach((file) => {
      const filePath = path.join(dir, file);
      const ext = path.extname(file).toLowerCase();
      if (!validExtensions.includes(ext)) return;

      fs.stat(filePath, (err, stats) => {
        if (err) {
          console.error(`Stat error → ${filePath}:`, err.message);
          return;
        }

        if (stats.mtimeMs < cutoff) {
          fs.unlink(filePath, (err) => {
            if (err) console.error(`❌ Failed → ${filePath}`);
            else console.log(`🗑️ Deleted → ${filePath}`);
          });
        }
      });
    });
  });
});
