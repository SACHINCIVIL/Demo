# Docs Utils Server

A TypeScript Express server for processing DOCX files with header and footer attachments.

## Features

### Document Processing
- Add headers and footers to DOCX files
- Convert DOC files to DOCX format
- Convert HTML content to DOCX format
- Support for images in headers
- Table-based header layouts
- Page numbering support
- Customizable header and footer alignment
- Document summary and metadata integration

### File Format Support
- **DOCX**: Native processing with headers/footers
- **DOC**: Legacy format conversion to DOCX
- **HTML**: Web content conversion to DOCX
- **PDF**: Export to PDF format (optional)

### Advanced Features
- **Watermarks**: Text watermarks with customizable:
  - Text content and styling
  - Opacity and positioning
  - Font family, size, and color
  - Diagonal orientation and angle
- **Document Summaries**: Rich metadata tables including:
  - Workflow history tracking
  - Version logs
  - Document review information
- **PDF Export**: Convert processed documents to PDF format
- **S3 Integration**: Cloud storage support for file processing
- **File Upload**: Direct file upload for DOC conversion

### Technical Features
- TypeScript support with full type safety
- LibreOffice integration for DOC conversion
- Pandoc integration for HTML conversion
- Modern DOCX compatibility mode
- Error handling and validation
- Temporary file cleanup
- Cross-platform support (Windows, Linux, macOS)

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- AWS S3 access
- **For DOC processing**: LibreOffice (for DOC to DOCX conversion)
  - Windows: Install LibreOffice from https://www.libreoffice.org/
  - Linux: `sudo apt-get install libreoffice` or `sudo yum install libreoffice`
  - macOS: `brew install --cask libreoffice`
  
  **Detailed LibreOffice Installation for Linux:**
  
  🧩 Step 1: Update Your System
  ```bash
  sudo apt update && sudo apt upgrade -y
  ```
  
  🧰 Step 2: Install LibreOffice
  ```bash
  sudo apt install -y libreoffice
  ```
  
  This installs the full LibreOffice suite (including soffice, which you'll use in your backend scripts).
  
  🧪 Step 3: Verify Installation
  
  Run:
  ```bash
  libreoffice --version
  ```
  
  You should see something like:
  ```
  LibreOffice 7.6.2.1 20(Build:1)
  ```
- **For document conversion**: Pandoc 3.8.2.1
  - 🛠️ Option 1: Install Pandoc 3.8.2.1 from the binary tarball

    Download the binary tarball:

    ```bash
    wget https://github.com/jgm/pandoc/releases/download/3.8.2.1/pandoc-3.8.2.1-linux-amd64.tar.gz
    ```

    Extract the tarball:

    ```bash
    tar -xvzf pandoc-3.8.2.1-linux-amd64.tar.gz
    ```

    Move the binary to a directory in your PATH:

    ```bash
    sudo mv pandoc-3.8.2.1/bin/pandoc /usr/local/bin/
    ```

    Verify the installation:

    ```bash
    pandoc --version
    ```

    This should display pandoc 3.8.2.1.

## Installation

1. Clone the repository
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy the environment file and configure:

   ```bash
   cp env.example .env
   ```

4. Update the `.env` file with your AWS credentials and S3 bucket names.

## Configuration

Create a `.env` file with the following variables:

```env
PORT=4040
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key_here
AWS_SECRET_ACCESS_KEY=your_secret_key_here
BUCKET_NAME=your-source-bucket-name
TEMP_BUCKET_NAME=your-temp-bucket-name
NODE_ENV=development
```

## Development

Run the development server:

```bash
npm run dev
```

Build the project:

```bash
npm run build
```

Start the production server:

```bash
npm start
```

## API Endpoints

### 1. DOCX Processing

- **POST** `/api/attach-docx` - Process DOCX files with headers/footers

### 2. DOC Processing

- **POST** `/api/convert-doc-with-headers` - Convert DOC files to DOCX and add headers/footers
- **POST** `/api/doc-to-docx` - Convert DOC files to DOCX format (file upload)

### 3. HTML Processing

- **POST** `/api/convert-html-to-docx` - Convert HTML content to DOCX with headers/footers

#### Request Body for `/api/attach-docx`:

```json
{
  "s3Path": "path/to/your/file.docx",
  "s3Version": "optional-version-id",
  "sourceBucketName": "your-source-bucket",
  "tempBucketName": "your-temp-bucket",
  "filename": "output.docx",
  "headerText": "Your header text",
  "footerText": "Your footer text",
  "includePageNumbers": true,
  "allPages": true,
  "headerAlign": "center",
  "footerAlign": "right",
  "headerImageUrl": "https://example.com/image.png",
  "headerImageWidthInch": 1.8,
  "headerMarginInch": 1.0,
  "footerMarginInch": 1.0,
  "layout": "table",
  "docCode": "DOC-001",
  "docTitle": "Document Title",
  "company": "Your Company",
  "seriesLabel": "Series Label",
  "docNo": "12345",
  "versionNo": "1.0",
  "issueDate": "2024-01-01",
  "effectiveDate": "2024-01-01"
}
```

#### Response:

```json
{
  "fileBase64": "base64-encoded-docx-content",
  "filename": "modified.docx",
  "warning": "optional-warning-message"
}
```

#### Request Body for `/api/convert-doc-with-headers`:

```json
{
  "s3Path": "path/to/your/file.doc",
  "s3Version": "optional-version-id",
  "sourceBucketName": "your-source-bucket",
  "filename": "converted.docx",
  "headerText": "Your header text",
  "footerText": "Your footer text",
  "includePageNumbers": true,
  "allPages": true,
  "headerAlign": "center",
  "footerAlign": "right",
  "headerImageUrl": "https://example.com/image.png",
  "headerImageWidthInch": 1.8,
  "headerMarginInch": 1.0,
  "footerMarginInch": 1.0,
  "layout": "table",
  "docCode": "DOC-001",
  "docTitle": "Document Title",
  "company": "Your Company",
  "seriesLabel": "Series Label",
  "docNo": "12345",
  "versionNo": "1.0",
  "issueDate": "2024-01-01",
  "effectiveDate": "2024-01-01"
}
```

#### Response for DOC Conversion:

```json
{
  "fileBase64": "base64-encoded-docx-content",
  "filename": "converted_and_processed.docx",
  "warning": "optional-warning-message",
  "conversionInfo": "DOC converted to DOCX and processed with headers/footers"
}
```

#### Request Body for `/api/doc-to-docx`:

**Content-Type**: `multipart/form-data`

**Form Data**:
- `file` (required): DOC file to convert

**Response**:
- **Content-Type**: `application/vnd.openxmlformats-officedocument.wordprocessingml.document`
- **Content-Disposition**: `attachment; filename="converted.docx"`
- **Body**: Binary DOCX file content

#### Request Body for `/api/convert-html-to-docx`:

```json
{
  "s3Path": "path/to/your/file.html",
  "s3Version": "optional-version-id",
  "sourceBucketName": "your-source-bucket",
  "htmlContent": "HTML content as string",
  "filename": "converted.docx",
  "headerText": "Your header text",
  "footerText": "Your footer text",
  "includePageNumbers": true,
  "allPages": true,
  "headerAlign": "center",
  "footerAlign": "right",
  "headerImageUrl": "https://example.com/image.png",
  "headerImageWidthInch": 1.8,
  "headerMarginInch": 1.0,
  "footerMarginInch": 1.0,
  "layout": "table",
  "docCode": "DOC-001",
  "docTitle": "Document Title",
  "company": "Your Company",
  "seriesLabel": "Series Label",
  "docNo": "12345",
  "versionNo": "1.0",
  "issueDate": "2024-01-01",
  "effectiveDate": "2024-01-01",
  "documentSummary": {
    "workflowHistory": [...],
    "versionLog": [...],
    "documentReview": [...]
  },
  "shouldPrint": false
}
```

#### Response for HTML Conversion:

```json
{
  "fileBase64": "base64-encoded-docx-content",
  "filename": "html_converted_and_processed.docx",
  "warning": "optional-warning-message",
  "conversionInfo": "HTML converted to DOCX and processed with headers/footers"
}
```

**Note**: If `shouldPrint: true` is set in the request, the response will be a PDF file instead of DOCX.

## DOC Conversion Process

The DOC API (`/api/convert-doc-with-headers`) performs a two-step process:

1. **DOC to DOCX Conversion**: Uses LibreOffice to convert the legacy DOC format to modern DOCX format
2. **Header/Footer Processing**: Applies the same header and footer logic as the DOCX API

### Requirements for DOC Conversion:

- LibreOffice must be installed and accessible in the system PATH
- The conversion process runs Python scripts that interface with LibreOffice
- Conversion timeout is set to 2 minutes for large files
- Temporary files are automatically cleaned up after processing

### Supported DOC Formats:

- Legacy Microsoft Word DOC files (.doc)
- DOC files with various encoding formats
- Password-protected DOC files (if LibreOffice can process them)

## Server Information

- **Port**: 4040 (configurable via PORT environment variable)
- **DOCX Processing**: http://localhost:4040/api/attach-docx
- **DOC to DOCX Conversion**: http://localhost:4040/api/convert-doc-with-headers
- **DOC File Upload**: http://localhost:4040/api/doc-to-docx
- **HTML to DOCX Conversion**: http://localhost:4040/api/convert-html-to-docx

## Project Structure

```
components_docs-attacher/
├── node_modules/                    # Node.js dependencies
├── package-lock.json               # Dependency lock file
├── package.json                    # Project configuration and dependencies
├── README.md                       # Project documentation
├── tsconfig.json                   # TypeScript configuration
└── src/                           # Source code directory
    ├── server.ts                  # Main server file with all route definitions
    ├── handlers/                  # API route handlers
    │   ├── documentSummary.ts     # Document summary functionality
    │   ├── docxHandler.ts         # DOCX processing logic
    │   ├── htmlToDocxHandler.ts  # HTML to DOCX conversion
    │   └── uploadDoc.ts           # File upload handling
    └── types/                     # TypeScript type definitions
        └── express-multer.d.ts    # Express multer type definitions
```

## License

MIT
