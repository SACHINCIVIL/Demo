import moment from "moment";

export function formatDateValue(value: any, dateFormat?: string): string {
  if (!dateFormat) return String(value ?? "");
  if (value == null || value === "") return "";

  // Numbers: treat as epoch (sec or ms)
  if (typeof value === "number") {
    const epochMs = value > 1e12 ? value : value * 1000;
    const mNum = moment(epochMs);
    return mNum.isValid() ? mNum.format(dateFormat) : String(value);
  }

  const s = String(value).trim();
  // Pure digits: epoch seconds/ms
  if (/^\d{10,13}$/.test(s)) {
    const num = Number(s);
    const epochMs = s.length === 13 ? num : num * 1000;
    const mEpoch = moment(epochMs);
    return mEpoch.isValid() ? mEpoch.format(dateFormat) : s;
  }

  // Try strict parsing with provided format first, then fallbacks
  const fallbackFormats = [
    moment.ISO_8601 as any,
    "YYYY-MM-DD",
    "YYYY/MM/DD",
    "DD/MM/YYYY",
    "MM/DD/YYYY",
    "DD-MM-YYYY",
    "MM-DD-YYYY",
    "YYYY-MM-DDTHH:mm:ssZ",
    "YYYY-MM-DD HH:mm:ss",
  ];

  let m: moment.Moment | undefined = moment(
    s,
    [dateFormat, ...fallbackFormats] as any,
    true,
  );
  if (!m.isValid()) {
    // Final attempt: non-strict ISO
    m = moment(s);
  }
  if (!m.isValid()) return s;
  return m.format(dateFormat);
}

function keyLooksLikeDate(key: string): boolean {
  const k = key.toLowerCase();
  return (
    // common generic keys
    k === "date" ||
    k === "dateTime" ||
    k === "datetime" ||
    k === "date time" ||
    k === "dateandtime" ||
    // footer/header known keys
    k === "datetime" ||
    k === "date time periodic" ||
    k === "date_time_periodic" ||
    k === "date and time" ||
    k === "date_time" ||
    k === "date-time" ||
    k === "date time" ||
    k === "created on" ||
    k === "created_on" ||
    k === "createdon" ||
    k === "published on" ||
    k === "published_on" ||
    k === "publishedon" ||
    k === "modified on" ||
    k === "modified_on" ||
    k === "modifiedon" ||
    k === "approvedon" ||
    k === "reviewedon" ||
    k === "issueddate" ||
    k === "supersedesdate" ||
    // loose match as last resort (was present originally)
    k.includes("date")
  );
}

export function formatDatesInObject<T extends Record<string, any>>(
  obj: T | undefined,
  dateFormat?: string,
): T | undefined {
  if (!obj) return obj;
  if (!dateFormat) return obj;
  const out: Record<string, any> = { ...obj };
  for (const [k, v] of Object.entries(obj)) {
    if (v == null) continue;
    if (keyLooksLikeDate(k)) {
      out[k] = formatDateValue(v, dateFormat);
    }
  }
  return out as T;
}

export function formatDatesInDocumentSummary(
  summary: any,
  dateFormat?: string,
): any {
  if (!summary) return summary;
  const clone = { ...summary };
  // GFSI sends grouped summary under versionLog; reuse existing versionSummary render path.
  if (Array.isArray(clone.versionLog)) {
    clone.versionSummary = clone.versionLog;
    clone.versionLog = [];
  }
  if (!dateFormat) return clone;

  const processRows = (rows?: Array<Record<string, any>>) => {
    if (!Array.isArray(rows)) return rows;
    return rows.map((row) => {
      const newRow: Record<string, any> = { ...row };
      for (const [k, v] of Object.entries(row)) {
        if (v == null) continue;
        if (keyLooksLikeDate(k)) {
          newRow[k] = formatDateValue(v, dateFormat);
        }
      }
      return newRow;
    });
  };
  if (clone.workflowHistory)
    clone.workflowHistory = processRows(clone.workflowHistory);
  if (clone.versionLog) clone.versionLog = processRows(clone.versionLog);
  if (clone.documentReview)
    clone.documentReview = processRows(clone.documentReview);
  if (clone.versionSummary)
    clone.versionSummary = processRows(clone.versionSummary);
  return clone;
}
