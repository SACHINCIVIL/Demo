import * as crypto from "crypto";

/**
 * Time-related fields to exclude from hash calculation
 * These fields change frequently and shouldn't affect file caching
 * Note: publishedOn and createdOn are included in hash to detect content changes
 * All keys are lowercase for case-insensitive matching
 */
const TIME_FIELDS = new Set(["datetime", "timestamp", "time", "date"]);

/**
 * Fields to exclude from hash (internal/metadata fields)
 */
const EXCLUDED_FIELDS = new Set([
  "shouldPrint", // Always false for view endpoints
  ...TIME_FIELDS,
]);

/**
 * Recursively clean an object by removing time fields
 */
function cleanObject(obj: any): any {
  if (obj === null || obj === undefined) {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(cleanObject).sort();
  }

  if (typeof obj !== "object") {
    return obj;
  }

  const cleaned: any = {};
  for (const [key, value] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();

    // Skip time fields and excluded fields
    if (EXCLUDED_FIELDS.has(lowerKey) || TIME_FIELDS.has(lowerKey)) {
      continue;
    }

    // Skip undefined and null values
    if (value === undefined || value === null) {
      continue;
    }

    // Recursively clean nested objects
    cleaned[key] = cleanObject(value);
  }

  return cleaned;
}

/**
 * Create a hash from payload metadata (excluding time fields)
 * This ensures same document + settings = same hash = same cached file
 */
export function createPayloadHash(payload: any, fileExtension: string): string {
  // Create a clean copy of payload without time fields
  const cleanPayload = cleanObject(payload);

  // Add file extension to hash
  cleanPayload._fileExt = fileExtension;

  // Sort keys recursively for consistent hashing
  function sortKeys(obj: any): any {
    if (obj === null || obj === undefined) {
      return obj;
    }
    if (Array.isArray(obj)) {
      return obj.map(sortKeys);
    }
    if (typeof obj !== "object") {
      return obj;
    }
    const sorted: any = {};
    for (const key of Object.keys(obj).sort()) {
      sorted[key] = sortKeys(obj[key]);
    }
    return sorted;
  }

  const sortedPayload = sortKeys(cleanPayload);

  // Create hash
  const hash = crypto
    .createHash("sha256")
    .update(JSON.stringify(sortedPayload))
    .digest("hex");

  // Return first 16 characters (sufficient for uniqueness)
  return hash.substring(0, 16);
}
