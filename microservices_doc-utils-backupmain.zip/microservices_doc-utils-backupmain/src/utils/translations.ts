import * as fs from "fs";
import * as path from "path";

const LANGUAGE_KEYS = [
  "en",
  "es",
  "fr",
  "pt",
  "de",
  "it",
  "ru",
  "ar",
  "hi",
  "ur",
  "bn",
  "zh",
  "ja",
  "ko",
  "tr",
  "nl",
  "pl",
  "sv",
  "fi",
  "da",
  "no",
  "uk",
  "cs",
  "hu",
  "ro",
  "el",
  "he",
  "th",
  "vi",
  "id",
  "ms",
  "sw",
  "af",
  "zu",
  "xh",
  "fil",
  "fa",
  "ps",
  "am",
  "ta",
  "te",
  "mr",
  "gu",
  "pa",
] as const;

type TranslationKey = (typeof LANGUAGE_KEYS)[number];

const validLangSet = new Set<TranslationKey>(LANGUAGE_KEYS);

interface Translations {
  header: {
    publishedBy: string;
    docNo: string;
    docName: string;
    version: string;
    createdBy: string;
    publishedOn: string;
    createdOn: string;
    modifiedBy: string;
    modifiedOn: string;
  };
  documentSummary: {
    title: string;
    workflowHistory: string;
    versionLog: string;
    documentReview: string;
    action: string;
    user: string;
    dateAndTime: string;
    signature: string;
    version: string;
    changeLogDescription: string;
    createdBy: string;
    createdOn: string;
    reviewComments: string;
    dateTimePeriodic: string;
    reviewedBy: string;
    performedBy: string;
    comments: string;
    actionType: string;
  };
  xlsx: {
    createdBy: string;
    publishedOn: string;
    createdOn: string;
    publishedBy: string;
    version: string;
    docNo: string;
    docName: string;
    userInitials: string;
    issuedDate: string;
    supersedesDate: string;
    printedBy: string;
    downloadedBy: string;
    date: string;
    pageNo: string;
    footerComments: string;
    printedOn: string;
    downloadedOn: string;
    downloadedPrintedOn: string;
    companyAddress: string;
  };
}

let translationsCache: Map<TranslationKey, Translations> = new Map();

function loadTranslations(lang: TranslationKey = "en"): Translations {
  if (translationsCache.has(lang)) {
    return translationsCache.get(lang)!;
  }

  const translationsPath = path.join(
    __dirname,
    "../translations",
    `${lang}.json`,
  );

  try {
    const fileContent = fs.readFileSync(translationsPath, "utf-8");
    const translations = JSON.parse(fileContent) as Translations;
    translationsCache.set(lang, translations);
    return translations;
  } catch (error) {
    console.warn(`Failed to load translations for ${lang}, falling back to en`);
    if (lang !== "en") {
      return loadTranslations("en");
    }
    // Fallback to English defaults if even en.json fails
    return {
      header: {
        publishedBy: "Published By",
        docNo: "Doc No",
        docName: "Document Name",
        version: "Version",
        createdBy: "Created By",
        publishedOn: "Published On",
        createdOn: "Created On",
        modifiedBy: "Modified By",
        modifiedOn: "Modified On",
      },
      documentSummary: {
        title: "Document Control Summary",
        workflowHistory: "Documents Workflow :",
        versionLog: "Version Log :",
        documentReview: "Document Review :",
        action: "Action",
        user: "User",
        dateAndTime: "Date and time",
        signature: "Signature",
        version: "Version",
        changeLogDescription: "Change Log Description",
        createdBy: "Created by",
        createdOn: "Created On",
        reviewComments: "Review comments",
        dateTimePeriodic: "Date time periodic",
        reviewedBy: "Reviewed by",
        performedBy: "Performed By",
        comments: "Comments",
        actionType: "Action Type",
      },
      xlsx: {
        createdBy: "Created By",
        publishedOn: "Published On",
        createdOn: "Created On",
        publishedBy: "Published By",
        version: "Version",
        docNo: "Doc No",
        docName: "Document Name",
        userInitials: "User",
        issuedDate: "Issued Date",
        supersedesDate: "Supersedes Date",
        printedBy: "Printed by",
        downloadedBy: "Downloaded by",
        date: "Date",
        pageNo: "Page No",
        footerComments: "Footer Comments",
        printedOn: "Printed On",
        downloadedOn: "Downloaded On",
        downloadedPrintedOn: "Downloaded On",
        companyAddress: "Company Address",
      },
    };
  }
}

export function getTranslations(lang?: string): Translations {
  const normalizedLang = (lang || "en").toLowerCase() as TranslationKey;
  const translationKey = validLangSet.has(normalizedLang)
    ? normalizedLang
    : "en";
  return loadTranslations(translationKey);
}

export function getHeaderTranslation(key: string, lang?: string): string {
  const translations = getTranslations(lang);
  const headerKey = key as keyof typeof translations.header;
  return translations.header[headerKey] || key;
}

export function getDocumentSummaryTranslation(
  key: string,
  lang?: string,
): string {
  const translations = getTranslations(lang);
  const summaryKey = key as keyof typeof translations.documentSummary;
  return translations.documentSummary[summaryKey] || key;
}

export function getXlsxTranslation(key: string, lang?: string): string {
  const translations = getTranslations(lang);
  const xlsxKey = key as keyof typeof translations.xlsx;
  return translations.xlsx[xlsxKey] || key;
}
