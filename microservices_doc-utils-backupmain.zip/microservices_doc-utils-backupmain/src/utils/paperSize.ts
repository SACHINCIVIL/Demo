/**
 * Reads paper size from Word document.xml content (OOXML).
 * Uses the last w:sectPr (body-level section) and its w:pgSz.
 * Dimensions are in twentieths of a point; 1 inch = 1440 twentieths.
 */

const TWENTIETHS_PER_INCH = 72 * 20; // 1440
const CM_PER_INCH = 2.54;

/** Known Word paper size codes (subset) */
const PAPER_CODE_NAMES: Record<number, string> = {
  1: "Letter",
  5: "Legal",
  7: "Executive",
  9: "A4",
  10: "A5",
  11: "B5 (JIS)",
  12: "Envelope #10",
};

export interface PaperSizeInfo {
  /** Width in inches */
  widthInches: number | null;
  /** Height in inches */
  heightInches: number | null;
  /** Width in centimetres */
  widthCm: number | null;
  /** Height in centimetres */
  heightCm: number | null;
  /** Portrait or landscape */
  orientation: "portrait" | "landscape" | null;
  /** Word paper size code if present (e.g. 9 = A4) */
  code: number | null;
  /** Human-readable name when code is known */
  name: string | null;
}

/**
 * Extracts paper size from DOCX document.xml XML string.
 * Returns dimensions, orientation, and optional code/name; nulls when not found.
 */
export function getPaperSizeFromDocumentXml(docXml: string): PaperSizeInfo {
  const result: PaperSizeInfo = {
    widthInches: null,
    heightInches: null,
    widthCm: null,
    heightCm: null,
    orientation: null,
    code: null,
    name: null,
  };

  const sectPrRegex = /<w:sectPr[\s\S]*?<\/w:sectPr>/g;
  const matches = [...docXml.matchAll(sectPrRegex)];
  if (matches.length === 0) return result;

  const lastSectPr = matches[matches.length - 1]![0];
  const pgSzMatch = lastSectPr.match(
    /<w:pgSz\s+([^>]*)\/?>/,
  );
  const attrs = pgSzMatch?.[1] ?? "";
  if (!attrs) return result;

  const getAttr = (name: string): string | null => {
    const re = new RegExp(`w:${name}="([^"]*)"`);
    const m = attrs.match(re);
    const val = m?.[1];
    return val !== undefined ? val : null;
  };

  const w = getAttr("w");
  const h = getAttr("h");
  const orient = getAttr("orient");
  const codeStr = getAttr("code");

  if (w) {
    const n = parseInt(w, 10);
    if (!Number.isNaN(n)) {
      const inches = n / TWENTIETHS_PER_INCH;
      result.widthInches = inches;
      result.widthCm = Math.round(inches * CM_PER_INCH * 100) / 100;
    }
  }
  if (h) {
    const n = parseInt(h, 10);
    if (!Number.isNaN(n)) {
      const inches = n / TWENTIETHS_PER_INCH;
      result.heightInches = inches;
      result.heightCm = Math.round(inches * CM_PER_INCH * 100) / 100;
    }
  }
  if (orient === "landscape" || orient === "portrait") {
    result.orientation = orient;
  }
  if (codeStr) {
    const code = parseInt(codeStr, 10);
    if (!Number.isNaN(code)) {
      result.code = code;
      result.name = PAPER_CODE_NAMES[code] ?? null;
    }
  }

  return result;
}

/**
 * Logs paper size to console in a readable way.
 */
export function logPaperSize(docXml: string): PaperSizeInfo {
  const info = getPaperSizeFromDocumentXml(docXml);
  console.log("[paperSize] Paper size:", {
    widthInches: info.widthInches,
    heightInches: info.heightInches,
    widthCm: info.widthCm,
    heightCm: info.heightCm,
    orientation: info.orientation,
    code: info.code,
    name: info.name,
  });
  return info;
}
