import { Request, Response, NextFunction } from "express";
import * as fs from "fs";
import * as path from "path";
import { createReadStream, statSync, utimesSync } from "fs";

const FILE_EXPIRY_MINUTES = 5;
const FILE_EXPIRY_MS = FILE_EXPIRY_MINUTES * 60 * 1000;

/**
 * Custom file streaming middleware with expiration
 * Files expire after 5 minutes and are automatically cleaned up
 */
export function streamFilesWithExpiry(
  filesDir: string,
): (req: Request, res: Response, next: NextFunction) => void {
  return (req: Request, res: Response, next: NextFunction) => {
    // Handle OPTIONS for CORS preflight
    if (req.method === "OPTIONS") {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Range");
      return res.status(200).end();
    }

    // Only handle GET and HEAD requests
    if (req.method !== "GET" && req.method !== "HEAD") {
      return next();
    }

    // When mounted at /files, req.path has /files stripped, so use req.path directly
    // Remove leading slash if present and decode URL-encoded filename
    let filename = req.path.startsWith("/") ? req.path.substring(1) : req.path;

    // Decode URL-encoded filename (handles spaces, special characters, etc.)
    try {
      filename = decodeURIComponent(filename);
    } catch (err) {
      // If decoding fails, use original filename
      console.warn(`[FILE_STREAMER] Failed to decode filename: ${filename}`);
    }

    // Security: prevent directory traversal (allow spaces but not path separators)
    if (
      !filename ||
      filename.includes("..") ||
      filename.includes("/") ||
      filename.includes("\\")
    ) {
      return res.status(400).json({ error: "Invalid filename" });
    }

    const filePath = path.join(filesDir, filename);

    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: "File not found" });
    }

    try {
      // Get file stats to check modification time (for expiration tracking)
      const stats = statSync(filePath);

      // Use modification time for expiration tracking
      // When file is first created, mtime equals birthtime
      // When file is accessed, we update mtime to reset the expiration timer
      const fileAge = Date.now() - stats.mtime.getTime();

      // Single console log for file request
      console.log(
        `[FILE_STREAMER] Streaming: ${filename} (${Math.floor(
          fileAge / 1000,
        )}s old, ${stats.size} bytes)`,
      );

      // Check if file has expired (older than 5 minutes since last access)
      if (fileAge > FILE_EXPIRY_MS) {
        // Delete expired file
        try {
          fs.unlinkSync(filePath);
        } catch (deleteErr) {
          console.error(
            `[FILE_STREAMER] Failed to delete expired file: ${filename}`,
            deleteErr,
          );
        }
        return res.status(410).json({
          error: "File has expired",
          message: "This file is no longer available (expired after 5 minutes)",
        });
      }

      // Reset expiration timer by updating file access/modification time
      // This ensures cached files get a fresh 5-minute timer when accessed
      try {
        const now = new Date();
        utimesSync(filePath, now, now);
        // After updating mtime, the file is now "fresh" - reset age to 0
        // This means next access will see it as newly accessed
      } catch (utimesErr) {
        // If updating times fails, log but continue (non-critical)
        console.warn(
          `[FILE_STREAMER] Failed to update file times for ${filename}:`,
          utimesErr,
        );
      }

      // Calculate remaining time until expiration
      // Since we just updated mtime, the file is now "fresh" for next access
      // But for this response, use the remaining time from current age
      const remainingTime = FILE_EXPIRY_MS - fileAge;
      const expiresAt = new Date(Date.now() + remainingTime);

      // Set appropriate headers for file streaming
      const ext = path.extname(filename).toLowerCase();
      let contentType = "application/octet-stream";

      // Set content type based on file extension
      switch (ext) {
        case ".docx":
          contentType =
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
          break;
        case ".xlsx":
          contentType =
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
          break;
      }

      // Set headers for streaming and expiration
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Disposition", `inline; filename="${filename}"`);
      res.setHeader(
        "Cache-Control",
        `public, max-age=${Math.floor(remainingTime / 1000)}`,
      );
      res.setHeader("Expires", expiresAt.toUTCString());
      res.setHeader("Last-Modified", stats.mtime.toUTCString());
      res.setHeader("Content-Length", stats.size);

      // Enable CORS for Office Online viewer
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Range");

      // Handle HEAD requests - send headers only, no body
      if (req.method === "HEAD") {
        return res.end();
      }

      // Handle Range requests for streaming (important for large files)
      const range = req.headers.range as string | undefined;
      let file: fs.ReadStream;

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0] || "0", 10);
        const end = parts[1] ? parseInt(parts[1], 10) : stats.size - 1;
        const chunksize = end - start + 1;

        res.status(206); // Partial Content
        res.setHeader("Content-Range", `bytes ${start}-${end}/${stats.size}`);
        res.setHeader("Accept-Ranges", "bytes");
        res.setHeader("Content-Length", chunksize);

        file = createReadStream(filePath, { start, end });
      } else {
        // Stream entire file
        file = createReadStream(filePath);
      }

      // Handle stream errors
      file.on("error", (err) => {
        console.error(`[FILE_STREAMER] Error streaming file ${filename}:`, err);
        if (!res.headersSent) {
          res.status(500).json({ error: "Error streaming file" });
        }
      });

      // Pipe file to response
      file.pipe(res);

      // Log when streaming completes
      file.on("end", () => {
        console.log(`[FILE_STREAMER] Successfully streamed file: ${filename}`);
      });
    } catch (err: any) {
      console.error(`[FILE_STREAMER] Error accessing file ${filename}:`, err);
      if (!res.headersSent) {
        res.status(500).json({ error: "Error accessing file" });
      }
    }
  };
}
