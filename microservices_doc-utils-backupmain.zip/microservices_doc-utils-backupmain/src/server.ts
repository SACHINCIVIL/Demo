import express, { Request, Response } from "express";
import cors from "cors";
import helmet from "helmet";
import dotenv from "dotenv";
import * as path from "path";
import * as fs from "fs";
import { handleDocxAttach, handleDocConversion } from "./handlers/docxHandler";
import {
  handleXlsxAttach,
  handleConvertAndAttachXlsx,
} from "./handlers/xlsxHandler";
import { handleViewDocx } from "./handlers/viewDocxHandler";
import { handleViewXlsx } from "./handlers/viewXlsxHandler";
import { uploadMemory, docToDocxHandler } from "./handlers/uploadDoc";
import { handleHtmlToDocx } from "./handlers/htmlToDocxHandler";
import csvXlsToXlsxHandler, { uploadCsvXls } from "./handlers/csvXlsToXlsx";
import { streamFilesWithExpiry } from "./middleware/fileStreamer";

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 4040;

// Create public/files directory if it doesn't exist
const publicFilesDir = path.join(process.cwd(), "public", "files");
if (!fs.existsSync(publicFilesDir)) {
  fs.mkdirSync(publicFilesDir, { recursive: true });
}

// Trust proxy for VM/cloud environments (handles X-Forwarded headers)
app.set("trust proxy", true);

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Serve files with streaming and 5-minute expiration (only for /files route)
app.use("/files", streamFilesWithExpiry(publicFilesDir));

// Explicit DOC -> DOCX endpoint
app.post("/api/doc-to-docx", uploadMemory.single("file"), docToDocxHandler);

// DOCX attachment endpoint
app.post("/api/attach-docx", handleDocxAttach);

// XLSX attachment endpoint (header/footer)
app.post("/api/attach-xlsx", handleXlsxAttach);

// CSV/XLS -> XLSX conversion endpoint
app.post(
  "/api/convert-to-xlsx",
  uploadCsvXls.single("file"),
  csvXlsToXlsxHandler,
);

// S3 CSV/XLS/XLSX -> attach header/footer and return XLSX
app.post("/api/convert-and-attach-xlsx", handleConvertAndAttachXlsx);

// DOC to DOCX conversion with header/footer endpoint
app.post("/api/convert-doc-with-headers", handleDocConversion);

// HTML to DOCX conversion with header/footer endpoint
app.post("/api/convert-html-to-docx", handleHtmlToDocx);

// Office Online viewing routes - save files and return Office Online URL
app.post("/api/view-docx", handleViewDocx);
app.post("/api/view-xlsx", handleViewXlsx);

// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: any) => {
  console.error("Error:", err);
  res.status(500).json({
    error: "Internal server error",
    message: err.message,
  });
});

// 404 handler
app.use("*", (req: Request, res: Response) => {
  res.status(404).json({
    error: "Not found",
    message: `Route ${req.originalUrl} not found`,
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 DOCX Attacher Server running on port ${PORT}`);
  console.log(
    `📄 DOC to DOCX upload endpoint: http://localhost:${PORT}/api/doc-to-docx`,
  );
  console.log(`📄 DOCX endpoint: http://localhost:${PORT}/api/attach-docx`);
  console.log(`📊 XLSX endpoint: http://localhost:${PORT}/api/attach-xlsx`);
  console.log(
    `📊 CSV/XLS to XLSX: http://localhost:${PORT}/api/convert-to-xlsx`,
  );
  console.log(
    `📊 Convert+Attach (S3): http://localhost:${PORT}/api/convert-and-attach-xlsx`,
  );
  console.log(
    `📄 DOC conversion endpoint: http://localhost:${PORT}/api/convert-doc-with-headers`,
  );
  console.log(
    `📄 HTML to DOCX endpoint: http://localhost:${PORT}/api/convert-html-to-docx`,
  );
  console.log(
    `📄 Office Online DOCX viewer: http://localhost:${PORT}/api/view-docx`,
  );
  console.log(
    `📊 Office Online XLSX viewer: http://localhost:${PORT}/api/view-xlsx`,
  );
});

export default app;
