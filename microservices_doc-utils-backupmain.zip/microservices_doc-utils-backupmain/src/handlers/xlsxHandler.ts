import type { RequestHandler } from "express";
import AWS from "aws-sdk";
import { execFile } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { promisify } from "util";
import { getTranslations } from "../utils/translations";
import {
  formatDatesInObject,
  formatDatesInDocumentSummary,
} from "../utils/dateFormat";
import { getExcelLxmlMasterScript } from "./excel-headers-footers";

const execFileAsync = promisify(execFile);

// ---------- S3 ----------
const s3 = new AWS.S3({
  region: process.env.AWS_REGION || "us-east-1",
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

async function downloadFromS3(
  bucketName: string,
  key: string,
  versionId?: string,
): Promise<Buffer> {
  const params: AWS.S3.GetObjectRequest = {
    Bucket: bucketName,
    Key: key,
    ...(versionId && { VersionId: versionId }),
  };
  const result = await s3.getObject(params).promise();
  return result.Body as Buffer;
}

// ---------- Small helpers ----------
function getExtFromPath(p: string): string {
  const m = /\.([^.?#/]+)(?:$|[?#])/i.exec(p || "");
  return (m?.[1] || "").toLowerCase();
}

function sanitizeHeaderFooterText(input: string): string {
  const s = String(input || "");
  const withoutIllegal = s.replace(
    /[\u0000-\u0008\u000B\u000C\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/g,
    " ",
  );
  const escapedAmp = withoutIllegal.replace(
    /&(?![A-Za-z#][A-Za-z0-9]*;)/g,
    "&&",
  );
  return escapedAmp.replace(/\r\n?|\u2028|\u2029/g, "\n");
}

function looksLikeHttpUrl(s?: string): string | undefined {
  if (!s) return undefined;
  try {
    const u = new URL(String(s));
    return u.protocol === "http:" || u.protocol === "https:"
      ? u.toString()
      : undefined;
  } catch {
    return undefined;
  }
}

function guessImageExtensionFromUrlOrType(
  contentType: string | null,
  url: string,
): "png" | "jpeg" | undefined {
  const lower = (url || "").toLowerCase();
  if (contentType?.includes("png") || lower.endsWith(".png")) return "png";
  if (
    contentType?.includes("jpeg") ||
    contentType?.includes("jpg") ||
    /\.jpe?g$/i.test(lower)
  )
    return "jpeg";
  return undefined; // openpyxl supports PNG/JPEG
}

// ---------- LibreOffice conversions ----------
async function convertToXlsxWithLibreOffice(
  inputBuffer: Buffer,
  sourceExt: string,
): Promise<Buffer> {
  const tempBaseDir = path.join(os.tmpdir(), "docs-attacher");
  try {
    fs.mkdirSync(tempBaseDir, { recursive: true });
  } catch {}
  const ts = Date.now();
  const inPath = path.join(tempBaseDir, `xlsx_in_${ts}.${sourceExt}`);
  const outDir = tempBaseDir;
  const outPath = path.join(tempBaseDir, `xlsx_out_${ts}.xlsx`);
  const pyPath = path.join(tempBaseDir, `xlsx_conv_${ts}.py`);

  fs.writeFileSync(inPath, inputBuffer);

  // Use LibreOffice (soffice) for real CSV/XLS -> XLSX conversion and print SUCCESS for your check
  const py = `
import os, sys, subprocess, time

def find_soffice():
    candidates = [
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ]
    for p in candidates:
        if os.path.exists(p):
            return p
        if p in ("soffice","libreoffice"):
            try:
                r = subprocess.run([p,"--version"], capture_output=True, text=True, timeout=5)
                if r.returncode == 0:
                    return p
            except:
                pass
    return None

def convert(in_path, out_dir, expected_out):
    exe = find_soffice()
    if not exe:
        raise RuntimeError("LibreOffice (soffice) not found")
    # clean possible stale processes
    try:
        if os.name == 'nt':
            subprocess.run(['taskkill','/f','/im','soffice.exe'], capture_output=True, check=False, timeout=5)
            subprocess.run(['taskkill','/f','/im','soffice.bin'], capture_output=True, check=False, timeout=5)
        else:
            subprocess.run(['pkill','-f','soffice'], capture_output=True, check=False, timeout=5)
    except: pass
    time.sleep(0.5)

    os.makedirs(out_dir, exist_ok=True)
    cmd = [exe, "--headless","--invisible","--nodefault","--nolockcheck","--nologo","--norestore","--safe-mode",
           "--convert-to","xlsx","--outdir", out_dir, in_path]
    env = os.environ.copy()
    env['SAL_USE_VCLPLUGIN'] = 'svp'
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=180, env=env)
    if r.returncode != 0:
        raise RuntimeError("LibreOffice conversion failed: " + (r.stderr.strip() or r.stdout.strip()))

    # guess the produced name (LibreOffice keeps base name)
    base = os.path.splitext(os.path.basename(in_path))[0] + ".xlsx"
    produced = os.path.join(out_dir, base)
    if os.path.exists(produced):
        os.replace(produced, expected_out)
    if not os.path.exists(expected_out):
        raise RuntimeError("Converted XLSX not found")
    print("SUCCESS")

if __name__ == "__main__":
    convert(sys.argv[1], sys.argv[2], sys.argv[3])
`;
  fs.writeFileSync(pyPath, py);

  try {
    const pythonCmd = process.platform === "win32" ? "python" : "python3";
    const { stdout, stderr } = await execFileAsync(
      pythonCmd,
      [pyPath, inPath, outDir, outPath],
      {
        env: {
          ...process.env,
          PYTHONUNBUFFERED: "1",
          PYTHONIOENCODING: "utf-8",
        },
        timeout: 240000,
        maxBuffer: 50 * 1024 * 1024,
      },
    );
    if (!String(stdout).includes("SUCCESS")) {
      throw new Error(`LibreOffice conversion failed: ${stderr || stdout}`);
    }
    return fs.readFileSync(outPath);
  } finally {
    try {
      fs.unlinkSync(pyPath);
    } catch {}
    try {
      fs.unlinkSync(inPath);
    } catch {}
    try {
      fs.unlinkSync(outPath);
    } catch {}
  }
}

async function convertXlsxBase64ToPdfBase64(
  xlsxBase64: string,
): Promise<string> {
  const tempDir = os.tmpdir();
  const tempXlsxPath = path.join(tempDir, `xlsx_${Date.now()}.xlsx`);
  const tempPdfPath = path.join(tempDir, `xlsx_${Date.now()}.pdf`);
  const buffer = Buffer.from(xlsxBase64, "base64");
  fs.writeFileSync(tempXlsxPath, buffer);

  const py = `
import os, sys, subprocess, time
def run(xlsx_path, output_path):
    try:
        paths = [
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ]
        exe = None
        for p in paths:
            if os.path.exists(p): exe=p; break
            elif p in ["soffice","libreoffice"]:
                try:
                    r = subprocess.run([p,"--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode==0: exe=p; break
                except: pass
        if not exe: raise Exception("LibreOffice not found")
        try:
            if os.name=='nt':
                subprocess.run(['taskkill','/f','/im','soffice.exe'], capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill','/f','/im','soffice.bin'], capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill','-f','soffice'], capture_output=True, check=False, timeout=5)
        except: pass
        time.sleep(0.5)
        outdir = os.path.dirname(output_path); os.makedirs(outdir, exist_ok=True)
        cmd = [exe,"--headless","--invisible","--nodefault","--nolockcheck","--nologo","--norestore","--safe-mode",
               "--convert-to","pdf","--outdir",outdir,xlsx_path]
        env = os.environ.copy(); env['SAL_USE_VCLPLUGIN']='svp'
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=180, env=env)
        if r.returncode != 0:
            msg = f"LibreOffice conversion failed (exit code {r.returncode})"
            if r.stderr.strip(): msg += f": {r.stderr.strip()}"
            raise Exception(msg)
        time.sleep(0.5)
        if not os.path.exists(output_path): raise Exception("Converted PDF file not found")
        print("SUCCESS")
    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    run("${tempXlsxPath.replace(/\\/g, "\\\\")}", "${tempPdfPath.replace(
      /\\/g,
      "\\\\",
    )}")
`;
  const pyPath = path.join(tempDir, `xlsx_pdf_${Date.now()}.py`);
  fs.writeFileSync(pyPath, py);

  try {
    const pythonCmd = process.platform === "win32" ? "python" : "python3";
    const { stdout, stderr } = await execFileAsync(pythonCmd, [pyPath], {
      env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONIOENCODING: "utf-8" },
      timeout: 240000,
      maxBuffer: 50 * 1024 * 1024,
    });
    if (!String(stdout).includes("SUCCESS"))
      throw new Error(`Python conversion failed: ${stderr || stdout}`);
    const pdfBuffer = fs.readFileSync(tempPdfPath);
    return pdfBuffer.toString("base64");
  } finally {
    try {
      fs.unlinkSync(pyPath);
    } catch {}
    try {
      fs.unlinkSync(tempXlsxPath);
    } catch {}
    try {
      fs.unlinkSync(tempPdfPath);
    } catch {}
  }
}

// ---------- Unified lxml processor (header/footer + optional summary sheet) ----------
async function runOpenpyxlProcessor(
  inputXlsx: Buffer,
  config: any,
): Promise<Buffer> {
  const ts = Date.now();
  const tempDir = path.join(os.tmpdir(), "docs-attacher", `xlsx_${ts}`);
  fs.mkdirSync(tempDir, { recursive: true });

  const inPath  = path.join(tempDir, `in_${ts}.xlsx`);
  const outPath = path.join(tempDir, `out_${ts}.xlsx`);
  const cfgPath = path.join(tempDir, `cfg_${ts}.json`);
  const pyPath  = path.join(tempDir, `xlsx_master_${ts}.py`);

  fs.writeFileSync(inPath, inputXlsx);
  fs.writeFileSync(cfgPath, JSON.stringify(config || {}, null, 2), "utf-8");

  const headerLayout =
    (config?.headerLayout as string) || (config?.layout as string) || "header1";
  const footerLayout = (config?.footerLayout as string) || "footer1";
  fs.writeFileSync(
    pyPath,
    getExcelLxmlMasterScript(headerLayout, footerLayout),
    "utf-8",
  );

  const pythonCmd = process.platform === "win32" ? "python" : "python3";
  try {
    await execFileAsync(pythonCmd, [pyPath, inPath, outPath, cfgPath], {
      cwd: tempDir,
      env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONIOENCODING: "utf-8" },
      timeout: 180000,
      maxBuffer: 50 * 1024 * 1024,
    });
    return fs.readFileSync(outPath);
  } finally {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
  }
}

// ---------- Handlers (no ExcelJS now) ----------
export const handleXlsxAttach: RequestHandler = async (req, res) => {
  console.log("[XLSXATTACH] Starting processing request");
  try {
    const {
      s3Path = "",
      s3Version = "",
      sourceBucketName = process.env.BUCKET_NAME,
      filename,
      includePageNumbers = true,
      layout = "simple",
      headerLayout,
      footerLayout,
      headerLayoutName,
      footerLayoutName,
      headerEnabled = true,
      footerEnabled = true,
      headerText = "",
      selections = [],
      fields = {},
      footer = [],
      shouldPrint = false,
      documentSummary,
    } = req.body as any;

    if (!s3Path || !sourceBucketName) {
      return res
        .status(400)
        .json({ error: "s3Path and sourceBucketName are required" });
    }

    const ext = getExtFromPath(s3Path);
    const sourceBuffer = await downloadFromS3(
      sourceBucketName,
      s3Path,
      s3Version,
    );

    // If not XLSX, convert to XLSX first
    let xlsxBuffer: Buffer = sourceBuffer;
    if (ext === "csv" || ext === "xls" || ext === "xlsm") {
      xlsxBuffer = await convertToXlsxWithLibreOffice(sourceBuffer, ext);
    } else if (ext !== "xlsx") {
      return res
        .status(400)
        .json({ error: "Unsupported source format. Use csv, xls, or xlsx." });
    }

    const language = (req.body as any)?.language || "en";
    const dateFormat = (req.body as any)?.dateFormat as string | undefined;
    const allTranslations = getTranslations(language);
    const translations = allTranslations.xlsx;

    const formattedFields = formatDatesInObject(
      (req.body as any)?.fields,
      dateFormat,
    );
    const formattedSummary = formatDatesInDocumentSummary(
      documentSummary,
      dateFormat,
    );

    const cfg = {
      layout,
      headerLayout: headerLayout ?? headerLayoutName ?? "header1",
      footerLayout: footerLayout ?? footerLayoutName ?? "footer1",
      headerEnabled,
      footerEnabled,
      headerText: sanitizeHeaderFooterText(headerText),
      selections,
      fields: Object.fromEntries(
        Object.entries((formattedFields || {}) as any).map(([k, v]) => [
          k,
          sanitizeHeaderFooterText(String(v ?? "")),
        ]),
      ),
      footer,
      includePageNumbers,
      shouldPrint,
      documentSummary: formattedSummary,
      translations,
      translationsSummary: allTranslations.documentSummary,
    };

    const processedXlsx = await runOpenpyxlProcessor(xlsxBuffer, cfg);
    const outB64 = processedXlsx.toString("base64");

    if (shouldPrint) {
      try {
        const pdfBase64 = await convertXlsxBase64ToPdfBase64(outB64);
        const baseName = filename
          ? filename.replace(/\.(csv|xls|xlsx|xlsm)$/i, "")
          : s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsx|xlsm)$/i, "") ||
            "converted_and_processed";
        return res.json({ fileBase64: pdfBase64, filename: baseName + ".pdf" });
      } catch (e) {
        console.error("[XLSX] PDF conversion failed, falling back to XLSX:", e);
        return res.json({
          fileBase64: outB64,
          filename:
            filename ||
            s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsm)$/i, "") +
              ".xlsx" ||
            "modified.xlsx",
        });
      }
    }

    return res.json({
      fileBase64: outB64,
      filename:
        filename ||
        s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsm)$/i, "") +
          ".xlsx" ||
        "modified.xlsx",
    });
  } catch (err: any) {
    console.error("[handleXlsxAttach] Error:", err);
    return res.status(500).json({ error: String(err.message || err) });
  }
};

export const handleConvertAndAttachXlsx: RequestHandler = async (req, res) => {
  console.log("[CONVERTANDATTACHXLSX] Starting processing request");
  try {
    const {
      s3Path = "",
      s3Version = "",
      sourceBucketName = process.env.BUCKET_NAME,
      filename,
      includePageNumbers = true,
      layout = "simple",
      headerLayout,
      footerLayout,
      headerLayoutName,
      footerLayoutName,
      headerEnabled = true,
      footerEnabled = true,
      headerText = "",
      selections = [],
      fields = {},
      footer = [],
      shouldPrint = false,
      documentSummary,
    } = req.body as any;

    if (!s3Path || !sourceBucketName) {
      return res
        .status(400)
        .json({ error: "s3Path and sourceBucketName are required" });
    }

    const ext = getExtFromPath(s3Path);
    const sourceBuffer = await downloadFromS3(
      sourceBucketName,
      s3Path,
      s3Version,
    );

    // Convert if needed
    let xlsxBuffer: Buffer = sourceBuffer;
    if (ext === "csv" || ext === "xls" || ext === "xlsm") {
      xlsxBuffer = await convertToXlsxWithLibreOffice(sourceBuffer, ext);
    } else if (ext !== "xlsx") {
      return res
        .status(400)
        .json({ error: "Unsupported source format. Use csv, xls, or xlsx." });
    }

    const language = (req.body as any)?.language || "en";
    const dateFormat = (req.body as any)?.dateFormat as string | undefined;
    const allTranslations = getTranslations(language);
    const translations = allTranslations.xlsx;

    const formattedFields = formatDatesInObject(
      (req.body as any)?.fields,
      dateFormat,
    );
    const formattedSummary = formatDatesInDocumentSummary(
      documentSummary,
      dateFormat,
    );

    const cfg = {
      layout,
      headerLayout: headerLayout ?? headerLayoutName ?? "header1",
      footerLayout: footerLayout ?? footerLayoutName ?? "footer1",
      headerEnabled,
      footerEnabled,
      headerText: sanitizeHeaderFooterText(headerText),
      selections,
      fields: Object.fromEntries(
        Object.entries((formattedFields || {}) as any).map(([k, v]) => [
          k,
          sanitizeHeaderFooterText(String(v ?? "")),
        ]),
      ),
      footer,
      includePageNumbers,
      shouldPrint,
      documentSummary: formattedSummary,
      translations,
      translationsSummary: allTranslations.documentSummary,
    };

    const processedXlsx = await runOpenpyxlProcessor(xlsxBuffer, cfg);
    const outB64 = processedXlsx.toString("base64");

    if (shouldPrint) {
      try {
        const pdfBase64 = await convertXlsxBase64ToPdfBase64(outB64);
        const baseName = filename
          ? filename.replace(/\.(csv|xls|xlsx|xlsm)$/i, "")
          : s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsx|xlsm)$/i, "") ||
            "converted_and_processed";
        return res.json({
          fileBase64: pdfBase64,
          filename: baseName + ".pdf",
          conversionInfo:
            ext === "xlsx"
              ? "XLSX processed with headers/footers and exported to PDF"
              : `${ext.toUpperCase()} converted to XLSX, processed with headers/footers, and exported to PDF`,
        });
      } catch (e) {
        console.error("[XLSX] PDF conversion failed, falling back to XLSX:", e);
        return res.json({
          fileBase64: outB64,
          filename:
            filename ||
            s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsm)$/i, "") +
              ".xlsx" ||
            "modified.xlsx",
          conversionInfo:
            ext === "xlsx"
              ? "XLSX processed with headers/footers (PDF export failed)"
              : `${ext.toUpperCase()} converted to XLSX and processed with headers/footers (PDF export failed)`,
        });
      }
    }

    return res.json({
      fileBase64: outB64,
      filename:
        filename ||
        s3Path.replace(/.*\//, "").replace(/\.(csv|xls|xlsm)$/i, "") +
          ".xlsx" ||
        "modified.xlsx",
      conversionInfo:
        ext === "xlsx"
          ? "XLSX processed with headers/footers"
          : `${ext.toUpperCase()} converted to XLSX and processed with headers/footers`,
    });
  } catch (err: any) {
    console.error("[handleConvertAndAttachXlsx] Error:", err);
    return res.status(500).json({ error: String(err.message || err) });
  }
};
