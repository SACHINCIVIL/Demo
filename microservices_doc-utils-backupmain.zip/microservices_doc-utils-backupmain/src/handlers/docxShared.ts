export type Align = "left" | "center" | "right";

export type WatermarkOptions = {
  text: string;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  opacity?: number;
  diagonal?: boolean;
  angleDegrees?: number;
  direction?: "up" | "down";
  position?: "horizontal" | "diagonal";
};

export type WatermarkImageOptions = {
  imageBuffer: Buffer;
  imageExtension: string;
  opacity?: number;
  position?: "horizontal" | "diagonal";
  widthInch?: number;
  heightInch?: number;
  aspectRatio?: number;
};

export function clampOpacity(opacity?: number) {
  if (typeof opacity !== "number" || Number.isNaN(opacity)) return 0.5;
  if (opacity < 0) return 0;
  if (opacity > 1) return 1;
  return Math.round(opacity * 100) / 100;
}

export const EMU_PER_INCH = 914400; // 1 inch = 914400 EMUs

export const DEFAULT_FONT_FAMILY = "Arial";

function computeWatermarkRotation(options: WatermarkOptions): number {
  // Prefer explicit position; fallback to legacy boolean and finally default diagonal
  if (options.position === "horizontal") return 0;
  if (options.position === "diagonal") return 45;
  if (options.diagonal === false) return 0; // legacy support if provided
  return 45;
}

export function xmlEscape(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export function jc(align: Align) {
  if (align === "left") return "left";
  if (align === "center") return "center";
  return "right";
}

export function buildWatermarkParagraph(options: WatermarkOptions) {
  const text = xmlEscape(options.text);
  const fontFamily = xmlEscape(
    options.fontFamily?.trim() || DEFAULT_FONT_FAMILY,
  );
  const fontSize =
    options.fontSize && !Number.isNaN(options.fontSize) ? options.fontSize : 48;
  const color = "#808080";
  const opacity = clampOpacity(options.opacity);
  const desired = computeWatermarkRotation(options);
  // VML rotation visual direction differs from our PDF rotation; map to match
  const rotation = (360 - desired) % 360;
  const opacityStr = opacity.toString().replace(/^0\./, ".");
  // Use page-relative positioning and fixed dimensions like Word's built-in watermark.
  // This avoids Word Online (WOPI) misinterpreting 100% width/height and warping the text.
  // Dimensions chosen to closely match the default watermark on Letter/A4.
  const widthPt = 468; // ~6.5in
  const heightPt = 100; // ~4.875in
  return `
      <w:p>
        <w:pPr><w:jc w:val="center"/></w:pPr>
        <w:r>
          <w:pict>
            <v:shapetype id="_x0000_t136" coordsize="1600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
              <v:formulas>
                <v:f eqn="sum #0 0 10800"/>
                <v:f eqn="prod #0 2 1"/>
                <v:f eqn="sum 21600 0 @1"/>
                <v:f eqn="sum 0 0 @2"/>
                <v:f eqn="sum 21600 0 @3"/>
                <v:f eqn="if @0 @3 0"/>
                <v:f eqn="if @0 21600 @1"/>
                <v:f eqn="if @0 0 @2"/>
                <v:f eqn="if @0 @4 21600"/>
                <v:f eqn="mid @5 @6"/>
                <v:f eqn="mid @8 @5"/>
                <v:f eqn="mid @7 @8"/>
                <v:f eqn="mid @6 @7"/>
                <v:f eqn="sum @6 0 @5"/>
              </v:formulas>
              <v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800" o:connectangles="270,180,90,0"/>
              <v:textpath on="t" fitshape="t" style="font-family:&quot;${fontFamily}&quot;;font-size:1pt" string="${text}"/>
              <v:handles>
                <v:h position="#0,bottomRight" xrange="0,10800"/>
              </v:handles>
              <o:lock v:ext="edit" text="t" shapetype="t"/>
            </v:shapetype>
            <v:shape id="PowerPlusWaterMarkObject" type="#_x0000_t136" style="position:absolute;left:0;top:0;width:${widthPt}pt;height:${heightPt}pt;z-index:-251659264;mso-position-horizontal:center;mso-position-horizontal-relative:page;mso-position-vertical:center;mso-position-vertical-relative:page;rotation:${rotation}" fillcolor="${color}" stroked="f">
              <v:fill opacity="${opacityStr}"/>
              <v:textpath on="t" style="font-family:&quot;${fontFamily}&quot;;font-size:${fontSize}pt" string="${text}"/>
              <o:lock v:ext="edit" text="t" shapetype="t"/>
            </v:shape>
          </w:pict>
        </w:r>
      </w:p>`;
}

export function buildWatermarkImageParagraph(
  imageRelId: string,
  options: WatermarkImageOptions,
) {
  // Reduce opacity for watermark logo (multiply by 0.6 to make it more transparent)
  const baseOpacity = clampOpacity(options.opacity);
  const opacity = baseOpacity * 0.6;
  // Default size for watermark logo (in EMUs)
  const widthInch = options.widthInch || 4;
  let heightInch = options.heightInch || 4;

  if (options.aspectRatio && options.aspectRatio > 0) {
    heightInch = widthInch / options.aspectRatio;
  }

  const widthEmu = Math.round(widthInch * EMU_PER_INCH);
  const heightEmu = Math.round(heightInch * EMU_PER_INCH);

  // Calculate rotation based on position
  const rotation = options.position === "diagonal" ? 315 : 0; // 315 degrees for diagonal (45 degrees counter-clockwise)

  // Use DrawingML for image watermark with behind-text positioning
  return `
      <w:p>
        <w:pPr><w:jc w:val="center"/></w:pPr>
        <w:r>
          <w:drawing>
            <wp:anchor xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
                       distT="0" distB="0" distL="0" distR="0"
                       simplePos="0" relativeHeight="251658240" behindDoc="1"
                       locked="0" layoutInCell="1" allowOverlap="1">
              <wp:simplePos x="0" y="0"/>
              <wp:positionH relativeFrom="page">
                <wp:align>center</wp:align>
              </wp:positionH>
              <wp:positionV relativeFrom="page">
                <wp:align>center</wp:align>
              </wp:positionV>
              <wp:extent cx="${widthEmu}" cy="${heightEmu}"/>
              <wp:effectExtent l="0" t="0" r="0" b="0"/>
              <wp:wrapNone/>
              <wp:docPr id="2" name="WatermarkLogo"/>
              <wp:cNvGraphicFramePr>
                <a:graphicFrameLocks xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1"/>
              </wp:cNvGraphicFramePr>
              <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
                <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
                  <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                    <pic:nvPicPr>
                      <pic:cNvPr id="0" name="watermark-logo"/>
                      <pic:cNvPicPr/>
                    </pic:nvPicPr>
                    <pic:blipFill>
                      <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                        <a:alphaModFix amt="${Math.round(opacity * 100000)}"/>
                      </a:blip>
                      <a:stretch><a:fillRect/></a:stretch>
                    </pic:blipFill>
                    <pic:spPr>
                      <a:xfrm${rotation ? ` rot="${rotation * 60000}"` : ""}>
                        <a:off x="0" y="0"/>
                        <a:ext cx="${widthEmu}" cy="${heightEmu}"/>
                      </a:xfrm>
                      <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                    </pic:spPr>
                  </pic:pic>
                </a:graphicData>
              </a:graphic>
            </wp:anchor>
          </w:drawing>
        </w:r>
      </w:p>`;
}
