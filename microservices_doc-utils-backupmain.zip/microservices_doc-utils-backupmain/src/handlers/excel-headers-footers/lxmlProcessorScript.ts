/**
 * Pure lxml + zipfile: patch only headerFooter on each sheet; rest of ZIP unchanged.
 * Injects same build_header / build_footer as openpyxl path (header1/header6 × footer1–5).
 */
const PH_H = "{{BUILD_HEADER_DEF}}";
const PH_F = "{{BUILD_FOOTER_DEF}}";

const PREFIX = String.raw`"""
xlsx_lxml_processor.py — surgical header/footer only (no openpyxl).
"""
import io
import json
import re
import sys
import zipfile
from lxml import etree

XLSX_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
SNS = "{" + XLSX_NS + "}"
SHEET_RE = re.compile(r"^xl/worksheets/sheet\d+\.xml$")

LABELS = {
    "createdBy": "Created By",
    "publishedOn": "Published On",
    "createdOn": "Created On",
    "publishedBy": "Published By",
    "modifiedBy": "Modified By",
    "modifiedOn": "Modified On",
    "approvedBy": "Approved By",
    "approvedOn": "Approved On",
    "reviewedBy": "Reviewed By",
    "reviewedOn": "Reviewed On",
    "version": "Version",
    "docNo": "Doc No",
    "docName": "Document Name",
    "userInitials": "User",
    "issuedDate": "Issued Date",
    "supersedesDate": "Supersedes Date",
    "company": "Company",
    "clientName": "Client Name",
}

def label(k, translations=None):
    if translations and k in translations:
        return translations[k]
    return LABELS.get(k, k.replace("_", " ").title())

def sanitize(s):
    if not s:
        return ""
    s = str(s)
    s = "".join(ch if (ord(ch) >= 32 or ch in "\n\t\r") else " " for ch in s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("&", "&&")
    return s

def safe_for_excel_header_footer(s):
    if s is None:
        return ""
    s = str(s)
    out = []
    for ch in s:
        o = ord(ch)
        if ch in "\n\t\r":
            out.append(ch)
        elif 32 <= o <= 0xD7FF:
            out.append(ch)
        elif 0xE000 <= o <= 0xFFFD:
            out.append(ch)
        else:
            out.append(" ")
    return "".join(out)

def _with_font_size(size, text):
    if not text:
        return ""
    return f"&{size} {text}"

`;

const SUFFIX = String.raw`

def _compose(left, center, right):
    parts = []
    if left:
        parts.append(f"&L{left}")
    if center:
        parts.append(f"&C{center}")
    if right:
        parts.append(f"&R{right}")
    return "".join(parts)


def _patch_sheet(xml_bytes, header_str, footer_str, header_enabled, footer_enabled):
    """
    Surgically replace only <headerFooter>…</headerFooter> in the sheet XML.
    Everything else is preserved byte-for-byte, avoiding lxml namespace reordering.
    """
    hf_parts = []
    if header_enabled and header_str:
        esc = header_str.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        hf_parts.append(f'<oddHeader xml:space="preserve">{esc}</oddHeader>')
    if footer_enabled and footer_str:
        esc = footer_str.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        hf_parts.append(f'<oddFooter xml:space="preserve">{esc}</oddFooter>')

    new_hf = ('<headerFooter>' + ''.join(hf_parts) + '</headerFooter>'
              if hf_parts else '<headerFooter/>').encode('utf-8')

    # Replace existing headerFooter (with or without child elements)
    hf_full = re.compile(rb'<headerFooter(?:\s[^>]*)?>.*?</headerFooter>', re.DOTALL)
    hf_self = re.compile(rb'<headerFooter[^>]*/>')

    if hf_full.search(xml_bytes):
        return hf_full.sub(new_hf, xml_bytes)
    elif hf_self.search(xml_bytes):
        return hf_self.sub(new_hf, xml_bytes)
    else:
        # No existing headerFooter — insert BEFORE elements that must follow it in
        # OOXML schema order: drawing, drawingHF, picture, oleObjects, controls,
        # webPublishItems, tableParts, extLst — otherwise Excel sees invalid schema.
        # ⚠️  Do NOT just insert before </worksheet>: if <drawing> is already there
        #     (e.g. sheet has embedded images), headerFooter would land after it → corruption.
        insert_before = re.compile(
            rb'<(?:drawing|drawingHF|picture|oleObjects|controls|webPublishItems|tableParts|extLst)[\s>/]'
        )
        m = insert_before.search(xml_bytes)
        if m:
            pos = m.start()
            return xml_bytes[:pos] + new_hf + xml_bytes[pos:]
        # No post-headerFooter elements exist — safe to insert before </worksheet>
        return xml_bytes.replace(b'</worksheet>', new_hf + b'</worksheet>', 1)


def process(input_path, output_path, config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    header_enabled = cfg.get("headerEnabled", True)
    footer_enabled = cfg.get("footerEnabled", True)
    if isinstance(header_enabled, str):
        header_enabled = header_enabled not in ("false", "0", "no", "")
    if isinstance(footer_enabled, str):
        footer_enabled = footer_enabled not in ("false", "0", "no", "")
    lh, ch, rh = build_header(cfg)
    lf, cf, rf = build_footer(cfg)
    lh = "" if not header_enabled else (str(lh) if lh else "")
    ch = "" if not header_enabled else (str(ch) if ch else "")
    rh = "" if not header_enabled else (str(rh) if rh else "")
    lf = "" if not footer_enabled else (str(lf) if lf else "")
    cf = "" if not footer_enabled else (str(cf) if cf else "")
    rf = "" if not footer_enabled else (str(rf) if rf else "")
    header_str = _compose(lh, ch, rh)
    footer_str = _compose(lf, cf, rf)
    with open(input_path, "rb") as f:
        input_bytes = f.read()
    out_buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(input_bytes)) as zin, \
         zipfile.ZipFile(out_buf, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if SHEET_RE.match(item.filename):
                try:
                    data = _patch_sheet(
                        data, header_str, footer_str, header_enabled, footer_enabled
                    )
                except Exception as e:
                    print(f"Warning: could not patch {item.filename}: {e}", file=sys.stderr)
            zout.writestr(item, data)
    with open(output_path, "wb") as f:
        f.write(out_buf.getvalue())


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: xlsx_lxml_processor.py <in.xlsx> <out.xlsx> <config.json>")
        sys.exit(1)
    process(sys.argv[1], sys.argv[2], sys.argv[3])
`;

export function buildLxmlScript(
  buildHeaderDef: string,
  buildFooterDef: string,
): string {
  return (
    PREFIX + "\n" + buildHeaderDef + "\n\n" + buildFooterDef + "\n" + SUFFIX
  );
}
