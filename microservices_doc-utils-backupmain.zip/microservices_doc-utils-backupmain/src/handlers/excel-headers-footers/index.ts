/**
 * Excel headers and footers – separate header and footer layouts that can be combined.
 * header1, header6 × 5 footers (e.g. header6+footer3).
 */
import { buildFullScript } from "./sharedScript";
import { buildLxmlScript } from "./lxmlProcessorScript";
import { buildLxmlMasterScript } from "./lxmlMasterScript";
import * as header1 from "./headers/header1";
import * as header6 from "./headers/header6";
import * as footer1 from "./footers/footer1";
import * as footer2 from "./footers/footer2";
import * as footer3 from "./footers/footer3";
import * as footer4 from "./footers/footer4";
import * as footer5 from "./footers/footer5";

export type ExcelHeaderModule = { BUILD_HEADER_PY: string };
export type ExcelFooterModule = { BUILD_FOOTER_PY: string };

export const EXCEL_HEADERS: Record<string, ExcelHeaderModule> = {
  header1,
  header6,
  simple: header1,
};

export const EXCEL_FOOTERS: Record<string, ExcelFooterModule> = {
  footer1,
  footer2,
  footer3,
  footer4,
  footer5,
};

/**
 * Returns the openpyxl script for the given header + footer combination.
 * @param headerLayout - e.g. "header1", "header6", "simple" (default "header1")
 * @param footerLayout - e.g. "footer1" .. "footer5" (default "footer1")
 */
export function getExcelHeaderFooterScript(
  headerLayout?: string,
  footerLayout?: string,
): string {
  const h = EXCEL_HEADERS[headerLayout || "header1"] ?? header1;
  const f = EXCEL_FOOTERS[footerLayout || "footer1"] ?? footer1;
  return buildFullScript(h.BUILD_HEADER_PY, f.BUILD_FOOTER_PY);
}

/** lxml ZIP processor — same layouts; no summary sheet (use openpyxl path if documentSummary needed). */
export function getExcelLxmlProcessorScript(
  headerLayout?: string,
  footerLayout?: string,
): string {
  const h = EXCEL_HEADERS[headerLayout || "header1"] ?? header1;
  const f = EXCEL_FOOTERS[footerLayout || "footer1"] ?? footer1;
  return buildLxmlScript(h.BUILD_HEADER_PY, f.BUILD_FOOTER_PY);
}

/**
 * Unified lxml processor: patches headerFooter on original sheets (zero corruption)
 * and — when documentSummary is present — injects a freshly-built summary sheet
 * via ZIP-level XML manipulation.  openpyxl is never run on original sheets.
 */
export function getExcelLxmlMasterScript(
  headerLayout?: string,
  footerLayout?: string,
): string {
  const h = EXCEL_HEADERS[headerLayout || "header1"] ?? header1;
  const f = EXCEL_FOOTERS[footerLayout || "footer1"] ?? footer1;
  return buildLxmlMasterScript(h.BUILD_HEADER_PY, f.BUILD_FOOTER_PY);
}
