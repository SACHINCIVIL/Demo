/**
 * Excel footer layout 1: left = comments + companyAddress, center = Printed/Downloaded by, right = date + Page &P of &N.
 */
export const BUILD_FOOTER_PY = String.raw`def build_footer(cfg):
    fields = cfg.get("fields", {}) or {}
    footerKeys = cfg.get("footer", []) or []
    includeNums = cfg.get("includePageNumbers", True)
    shouldPrint = cfg.get("shouldPrint", False)
    translations = cfg.get("translations", {})

    def get_val(k):
        if k == "pageNo":
            return "Page &P of &N"
        if k == "companyAddress":
            return sanitize(fields.get("companyAddress", ""))
        if k in ["comments", "footerComments"]:
            lbl = label("footerComments", translations)
            val = fields.get("comments", "")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "dateTime":
            lbl = label("downloadedPrintedOn", translations)
            val = fields.get("dateTime")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "userInitials":
            lbl = label("printedBy" if shouldPrint else "downloadedBy", translations)
            val = fields.get("userInitials") or fields.get("createdBy") or "User"
            return f"{lbl}: {sanitize(str(val))}"
        return ""

    # Filter keys
    keys = [str(k) for k in footerKeys if k]
    n = len(keys)
    
    # LEFT FOOTER: Item 1 (Row 1) + Item 3 (Row 2)
    lf_parts = []
    if n > 0:
        lf_parts.append(get_val(keys[0]))
    if n > 2:
        lf_parts.append(get_val(keys[2]))
    lf_text = "\n".join([v for v in lf_parts if v])
    lf = _with_font_size(9, lf_text) if lf_text else ""

    # RIGHT FOOTER: Item 2 (Row 1)
    rf_inner = ""
    if n > 1:
        rf_inner = get_val(keys[1])
    elif includeNums and "pageNo" not in keys:
        rf_inner = "Page &P of &N"
    rf = _with_font_size(9, rf_inner) if rf_inner else ""

    # CENTER FOOTER: Last item from the array (pushed to Row 2)
    cf_text = ""
    if n > 3:
        # If 4 or more items, the 4th (or last) goes to center
        # The user specifically said 3rd on left and last in center
        v = get_val(keys[-1])
        if v:
            cf_text = v
    elif n == 3:
        # If only 3 items, 3rd already went to left. Center is empty.
        pass
    
    # Prefix newline to push it to the second row
    cf = _with_font_size(9, "\n" + cf_text) if cf_text else ""

    return lf, cf, rf`;
