/**
 * Excel footer layout 3. Customize left/center/right as needed.
 */
export const BUILD_FOOTER_PY = String.raw`def build_footer(cfg):
    fields = cfg.get("fields", {}) or {}
    footerKeys = cfg.get("footer", []) or []
    includeNums = cfg.get("includePageNumbers", True)
    shouldPrint = cfg.get("shouldPrint", False)
    translations = cfg.get("translations", {})

    def get_val(k):
        if k == "pageNo":
            return "Page &P of &N"
        if k == "companyAddress":
            return sanitize(fields.get("companyAddress", ""))
        if k in ["comments", "footerComments"]:
            lbl = label("footerComments", translations)
            val = fields.get("comments", "")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "dateTime":
            lbl = label("downloadedPrintedOn", translations)
            val = fields.get("dateTime")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "userInitials":
            lbl = label("printedBy" if shouldPrint else "downloadedBy", translations)
            val = fields.get("userInitials") or fields.get("createdBy") or "User"
            return f"{lbl}: {sanitize(str(val))}"
        return ""

    # Filter keys
    keys = [str(k) for k in footerKeys if k]
    n = len(keys)
    
    # LEFT FOOTER: Item 1
    lf_text = get_val(keys[0]) if n > 0 else ""
    lf = _with_font_size(9, lf_text) if lf_text else ""

    # RIGHT FOOTER: Item 2
    rf_text = ""
    if n > 1:
        rf_text = get_val(keys[1])
    elif includeNums and "pageNo" not in keys:
        rf_text = "Page &P of &N"
    
    rf = _with_font_size(9, rf_text) if rf_text else ""

    return lf, "", rf`;
