/**
 * Excel footer layout 5. Customize left/center/right as needed.
 */
export const BUILD_FOOTER_PY = String.raw`def build_footer(cfg):
    fields = cfg.get("fields", {}) or {}
    footerKeys = cfg.get("footer", []) or []
    includeNums = cfg.get("includePageNumbers", True)
    shouldPrint = cfg.get("shouldPrint", False)
    translations = cfg.get("translations", {})

    def get_val(k):
        if k == "pageNo":
            return "Page &P of &N"
        if k == "companyAddress":
            return sanitize(fields.get("companyAddress", ""))
        if k in ["comments", "footerComments"]:
            lbl = label("footerComments", translations)
            val = fields.get("comments", "")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "dateTime":
            lbl = label("downloadedPrintedOn", translations)
            val = fields.get("dateTime")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "userInitials":
            lbl = label("printedBy" if shouldPrint else "downloadedBy", translations)
            val = fields.get("userInitials") or fields.get("createdBy") or "User"
            return f"{lbl}: {sanitize(str(val))}"
        return ""

    # Filter keys
    keys = [str(k) for k in footerKeys if k]
    n = len(keys)
    
    # LEFT FOOTER: Item 1 (Row 1), Item 2 (Row 2)
    lf_parts = []
    if n > 0: lf_parts.append(get_val(keys[0]))
    if n > 1: lf_parts.append(get_val(keys[1]))
    lf_text = "\n".join([v for v in lf_parts if v])
    lf = _with_font_size(9, lf_text) if lf_text else ""

    # RIGHT FOOTER: Static Page Number
    rf_text = "Page &P of &N" if includeNums else ""
    rf = _with_font_size(9, rf_text) if rf_text else ""

    return lf, "", rf`;
