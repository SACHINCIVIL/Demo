/**
 * Excel footer layout 2. Customize left/center/right as needed.
 */
export const BUILD_FOOTER_PY = String.raw`def build_footer(cfg):
    fields = cfg.get("fields", {}) or {}
    footerKeys = cfg.get("footer", []) or []
    includeNums = cfg.get("includePageNumbers", True)
    shouldPrint = cfg.get("shouldPrint", False)
    translations = cfg.get("translations", {})

    def get_val(k):
        if k == "pageNo":
            return "Page &P of &N"
        if k == "companyAddress":
            return sanitize(fields.get("companyAddress", ""))
        if k in ["comments", "footerComments"]:
            lbl = label("footerComments", translations)
            val = fields.get("comments", "")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "dateTime":
            lbl = label("downloadedPrintedOn", translations)
            val = fields.get("dateTime")
            return f"{lbl}: {sanitize(str(val))}" if val else ""
        if k == "userInitials":
            lbl = label("printedBy" if shouldPrint else "downloadedBy", translations)
            val = fields.get("userInitials") or fields.get("createdBy") or "User"
            return f"{lbl}: {sanitize(str(val))}"
        return ""

    # Filter keys
    keys = [str(k) for k in footerKeys if k]
    n = len(keys)
    
    # Mapping logic:
    # Row 1 Left:  keys[0]
    # Row 1 Right: keys[4]
    # Row 2 Left:  keys[2]
    # Row 2 Center:keys[3]
    # Row 2 Right: keys[1]

    # LEFT FOOTER: keys[0] (Row 1), keys[2] (Row 2)
    lf_parts = []
    if n > 0: lf_parts.append(get_val(keys[0]))
    if n > 2: lf_parts.append(get_val(keys[2]))
    lf_text = "\n".join([v for v in lf_parts if v])
    lf = _with_font_size(9, lf_text) if lf_text else ""

    # RIGHT FOOTER: keys[4] (Row 1), keys[1] (Row 2)
    # Special case: if n < 5 but includeNums is on, use PageNo on Row 1 Right if not in keys
    rf_r1 = ""
    if n > 4:
        rf_r1 = get_val(keys[4])
    elif includeNums and "pageNo" not in keys:
        rf_r1 = "Page &P of &N"
    
    rf_r2 = get_val(keys[1]) if n > 1 else ""
    
    rf_parts = [rf_r1, rf_r2]
    rf_text = "\n".join([v for v in rf_parts if v])
    rf = _with_font_size(9, rf_text) if rf_text else ""

    # CENTER FOOTER: keys[3] (Row 2)
    cf_text = ""
    if n > 3:
        v = get_val(keys[3])
        if v:
            cf_text = v
    
    # Prefix newline to push it to the second row
    cf = _with_font_size(9, "\n" + cf_text) if cf_text else ""

    return lf, cf, rf`;
