/**
 * Shared openpyxl script template. Placeholders {{BUILD_HEADER_DEF}} and {{BUILD_FOOTER_DEF}}
 * are replaced with the selected header and footer Python function definitions.
 */
const PLACEHOLDER_HEADER = "{{BUILD_HEADER_DEF}}";
const PLACEHOLDER_FOOTER = "{{BUILD_FOOTER_DEF}}";

export const SHARED_OPENPYXL_TEMPLATE =
  String.raw`
import json, sys, os, io, re
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.drawing.image import Image as XLImage

try:
    import requests
except:
    requests = None

GRAY = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
THIN = Side(style="thin")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

SIG_MAX_W_PX = 88
SIG_MAX_H_PX = 36

def _get_image_dimensions(data):
    if not data or len(data) < 10:
        return None
    if (len(data) > 24 and data[0] == 0x89 and data[1] == 0x50
            and data[2] == 0x4E and data[3] == 0x47):
        w = int.from_bytes(data[16:20], "big")
        h = int.from_bytes(data[20:24], "big")
        return (w, h) if w and h else None
    if len(data) > 10 and data[0:3] == b"GIF":
        w = int.from_bytes(data[6:8], "little")
        h = int.from_bytes(data[8:10], "little")
        return (w, h) if w and h else None
    if data[0:2] == b"\\xff\\xd8":
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            seg_len = int.from_bytes(data[i + 2:i + 4], "big")
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                          0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h = int.from_bytes(data[i + 5:i + 7], "big")
                w = int.from_bytes(data[i + 7:i + 9], "big")
                return (w, h) if w and h else None
            i += 2 + seg_len
    return None

def _fit_signature_pixels(data, max_w=SIG_MAX_W_PX, max_h=SIG_MAX_H_PX):
    dims = _get_image_dimensions(data)
    if not dims:
        return max_w, max_h
    w, h = dims
    if w <= 0 or h <= 0:
        return max_w, max_h
    scale = min(max_w / w, max_h / h, 1.0)
    return max(1, int(w * scale)), max(1, int(h * scale))

def _format_action_label(value):
    text = str(value or "").strip()
    if not text:
        return ""
    parts = re.split(r"(\\s+|_|-)", text)
    out = []
    for part in parts:
        if not part or re.match(r"^[\\s_\\-]+$", part):
            out.append(part)
            continue
        if part == part.upper() and re.search(r"[A-Z]", part):
            out.append(part[0] + part[1:].lower())
        else:
            out.append(part)
    return "".join(out)

def _normalize_summary_keys(keys):
    skip = {"Comments Detail", "Action Date", "Performed Date"}
    return [k for k in keys if k not in skip]

def _stack_two_lines(top, bottom):
    top = str(top or "").strip()
    bottom = str(bottom or "").strip()
    if top and bottom:
        return top + chr(10) + bottom
    return top or bottom

def _comments_cell_value(rec):
    label = _format_action_label(str((rec or {}).get("Comments") or "").strip())
    detail = str((rec or {}).get("Comments Detail") or "").strip()
    if label and detail:
        return label + " " + detail
    return label or detail

def _action_cell_value(rec, title_case=False):
    action = (rec or {}).get("Action")
    if title_case:
        action = _format_action_label(action)
    # Action column shows label only (no Action Date under it).
    return str(action or "").strip()

def _performed_by_cell_value(rec):
    return _stack_two_lines(
        (rec or {}).get("Performed By"),
        (rec or {}).get("Performed Date"),
    )

# Global configuration holder filled in main()
GLOBAL_CFG = {}

def _safe_sheet_name(name):
    try:
        s = str(name or "Document Control Summary")
    except:
        s = "Document Control Summary"
    invalid = set('\\/*?:[]')
    s = ''.join(ch for ch in s if ch not in invalid)
    s = s.strip()
    if not s:
        s = "Summary"
    return s[:31]

LABELS = {
    "createdBy": "Created By",
    "publishedOn": "Published On",
    "createdOn": "Created On",
    "publishedBy": "Published By",
    "modifiedBy": "Modified By",
    "modifiedOn": "Modified On",
    "version": "Version",
    "docNo": "Doc No",
    "docName": "Document Name",
    "userInitials": "User",
    "issuedDate": "Issued Date",
    "supersedesDate": "Supersedes Date",
    "company": "Company",
    "clientName": "Client Name"
}

def label(k, translations=None):
    if translations and k in translations:
        return translations[k]
    return LABELS.get(k, k.replace("_"," ").title())

def sanitize(s):
    """Sanitize user input for Excel headers/footers. Escapes & as && for literal display."""
    if not s: return ""
    s = str(s)
    # Keep newline, tab, carriage return; replace other control chars with space (avoids XML corruption)
    s = "".join(ch if (ord(ch) >= 32 or ch in "\n\t\r") else " " for ch in s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    # Escape ampersands so they display literally in Excel (not as Excel codes)
    s = s.replace("&", "&&")
    return s

def safe_for_excel_header_footer(s):
    """Strip any character that can corrupt xlsx/XML. Keep \\n \\t \\r and printable Unicode."""
    if s is None: return ""
    s = str(s)
    out = []
    for ch in s:
        o = ord(ch)
        if ch in "\n\t\r":
            out.append(ch)
        elif o >= 32 and o <= 0xD7FF:
            out.append(ch)
        elif 0xE000 <= o <= 0xFFFD:
            out.append(ch)
        else:
            out.append(" ")
    return "".join(out)

def _with_font_size(size, text):
    if not text:
        return ""
    return f"&{size} {text}"

` +
  PLACEHOLDER_HEADER +
  "\n\n" +
  PLACEHOLDER_FOOTER +
  String.raw`

def apply_page(ws):
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_setup.paperSize = 9
    ws.page_setup.orientation = "landscape"
    ws.print_title_rows = "1:1"

    ws.page_margins.top = 1.3
    ws.page_margins.header = 0.2
    ws.page_margins.bottom = 0.9
    ws.page_margins.footer = 0.6

def add_summary(wb, summary, headerValues):
    if not summary:
        return

    ts = GLOBAL_CFG.get("translationsSummary", {}) or {}
    ws = wb.create_sheet(_safe_sheet_name(ts.get("title", "Document Control Summary")))

    lh,ch,rh,lf,cf,rf = headerValues
    ws.oddHeader.left.text = lh
    ws.oddHeader.center.text = ch
    ws.oddHeader.right.text = rh
    ws.oddFooter.left.text = lf
    ws.oddFooter.center.text = cf
    ws.oddFooter.right.text = rf

    row = 1

    for section, items in summary.items():

        if not isinstance(items, list) or len(items) == 0:
            continue

        if not isinstance(items[0], dict):
            continue

        section_key_map = {
            "workflowHistory": ts.get("workflowHistory", "Documents Workflow :"),
            "versionLog": ts.get("versionLog", "Version Log :"),
            "documentReview": ts.get("documentReview", "Document Review :"),
            "versionSummary": ts.get("title", "Document Control Summary"),
            "Documents Workflow :": ts.get("workflowHistory", "Documents Workflow :"),
            "Version Log :": ts.get("versionLog", "Version Log :"),
            "Document Review :": ts.get("documentReview", "Document Review :"),
        }
        heading = section_key_map.get(section, section)
        ws.cell(row=row, column=1, value=heading).font = Font(bold=True, size=14, name="Arial")
        row += 1

        keys = _normalize_summary_keys(list(items[0].keys()))
        # Title-case Action/Action Type labels (DOCS i18n values are often ALL CAPS).
        title_case_action = True
        sig_col = keys.index("Signature")+1 if "Signature" in keys else None

        header_map = {
            "Action": ts.get("action", "Action"),
            "User": ts.get("user", "User"),
            "Date and time": ts.get("dateAndTime", "Date and time"),
            "Signature": ts.get("signature", "Signature"),
            "Version": ts.get("version", "Version"),
            "Change Log Description": ts.get("changeLogDescription", "Change Log Description"),
            "Created by": ts.get("createdBy", "Created by"),
            "Created On": ts.get("createdOn", "Created On"),
            "Review comments": ts.get("reviewComments", "Review comments"),
            "Date time periodic": ts.get("dateTimePeriodic", "Date time periodic"),
            "Reviewed by": ts.get("reviewedBy", "Reviewed by"),
            "Performed By": ts.get("performedBy", "Performed By"),
            "Comments": ts.get("comments", "Comments"),
            "Action Type": ts.get("actionType", "Action Type"),
        }
        for i,k in enumerate(keys,1):
            display = header_map.get(k, k)
            c = ws.cell(row=row, column=i, value=display)
            c.font = Font(bold=True, name="Arial")
            c.fill = GRAY
            c.alignment = CENTER
            c.border = BORDER
        row+=1

        for rec in items:
            ws.row_dimensions[row].height = 42
            for i,k in enumerate(keys,1):
                val = rec.get(k,"")
                c = ws.cell(row=row,column=i)
                c.alignment = CENTER
                c.border = BORDER

                if sig_col and i==sig_col and isinstance(val,str) and val.startswith("http"):
                    try:
                        data = requests.get(val,timeout=5).content
                        w, h = _fit_signature_pixels(data)
                        img = XLImage(io.BytesIO(data))
                        img.width = w
                        img.height = h
                        ws.add_image(img, c.coordinate)
                    except:
                        c.value = val
                else:
                    if k == "Comments":
                        val = _comments_cell_value(rec)
                    elif k == "Action":
                        val = _action_cell_value(rec, title_case=title_case_action)
                    elif k == "Action Type":
                        val = _format_action_label(val)
                    elif k == "Performed By":
                        val = _performed_by_cell_value(rec)
                    c.value = str(val)
                    c.font = Font(name="Arial")
                    if isinstance(val, str) and chr(10) in val:
                        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            row+=1

        row+=2

    for col in ws.columns:
        width = max(len(str(c.value)) if c.value else 0 for c in col) + 3
        ws.column_dimensions[col[0].column_letter].width = max(width,14)


def main():
    in_path,out_path,cfg_path = sys.argv[1],sys.argv[2],sys.argv[3]
    cfg = json.load(open(cfg_path,"r",encoding="utf-8"))
    global GLOBAL_CFG
    GLOBAL_CFG = cfg
    wb = load_workbook(in_path)

    header_enabled = cfg.get("headerEnabled", True)
    footer_enabled = cfg.get("footerEnabled", True)
    if isinstance(header_enabled, str):
        header_enabled = header_enabled not in ("false", "0", "no", "")
    if isinstance(footer_enabled, str):
        footer_enabled = footer_enabled not in ("false", "0", "no", "")

    header_vals = build_header(cfg)
    footer_vals = build_footer(cfg)
    # Values are already sanitized in get_val() and build functions
    # User data has & escaped as &&, Excel formulas like &P remain unchanged
    lh = "" if not header_enabled else (str(header_vals[0]) if header_vals[0] else "")
    ch = "" if not header_enabled else (str(header_vals[1]) if header_vals[1] else "")
    rh = "" if not header_enabled else (str(header_vals[2]) if header_vals[2] else "")
    lf = "" if not footer_enabled else (str(footer_vals[0]) if footer_vals[0] else "")
    cf = "" if not footer_enabled else (str(footer_vals[1]) if footer_vals[1] else "")
    rf = "" if not footer_enabled else (str(footer_vals[2]) if footer_vals[2] else "")
    header = (lh, ch, rh, lf, cf, rf)

    for ws in wb:
        ws.oddHeader.left.text = header[0]
        ws.oddHeader.center.text = header[1]
        ws.oddHeader.right.text = header[2]
        ws.oddFooter.left.text = header[3]
        ws.oddFooter.center.text = header[4]
        ws.oddFooter.right.text = header[5]
        apply_page(ws)

    add_summary(wb, cfg.get("documentSummary"), header)

    wb.save(out_path)

if __name__=="__main__":
    main()
`;

export function buildFullScript(
  buildHeaderDef: string,
  buildFooterDef: string,
): string {
  return SHARED_OPENPYXL_TEMPLATE.replace(
    PLACEHOLDER_HEADER,
    buildHeaderDef,
  ).replace(PLACEHOLDER_FOOTER, buildFooterDef);
}
