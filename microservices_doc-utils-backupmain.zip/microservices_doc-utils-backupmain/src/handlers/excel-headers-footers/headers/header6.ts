/**
 * Excel header layout 6 (supportable layout):
 * Left = client/company name,
 * Center = Document Name + "Document Number: docNo | Version: version",
 * Right = metadata in bullet-separated lines: "Created On: date • Created By: name" etc.
 */
export const BUILD_HEADER_PY = String.raw`def build_header(cfg):
    fields = cfg.get("fields", {}) or {}
    translations = cfg.get("translations", {})

    # LEFT HEADER: headerText or client name (company or clientName)
    header_text = cfg.get("headerText")
    client = fields.get("company") or fields.get("clientName") or ""
    display_text = sanitize(header_text if header_text else client)
    lh = _with_font_size(10, display_text)

    # CENTER HEADER: Document Name on first line, then "Document Number: docNo | Version: version"
    center_lines = []
    doc_name = sanitize(fields.get("docName") or "")
    if doc_name:
        center_lines.append(doc_name)
    doc_no = fields.get("docNo")
    version = fields.get("version")
    if doc_no or version:
        parts = []
        if doc_no:
            parts.append(f"Document Number: {sanitize(doc_no)}")
        if version:
            parts.append(f"Version: {sanitize(version)}")
        center_lines.append(" | ".join(parts))
    ch = _with_font_size(10, "\n".join(center_lines)) if center_lines else ""

    # RIGHT HEADER: one line per row, two "Label: Value" pairs per line separated by bullet (•)
    # The order and fields are determined by the 'selections' array in cfg
    selections = cfg.get("selections", [])
    if not selections:
        # Fallback to defaults if selections is empty
        selections = ["createdOn", "createdBy", "publishedOn", "publishedBy", "modifiedOn", "modifiedBy"]

    # Group selections into pairs
    right_pairs = []
    for i in range(0, len(selections), 2):
        pair = selections[i:i+2]
        right_pairs.append(pair)

    bullet = " • "
    right_lines = []
    for pair in right_pairs:
        parts = []
        for key in pair:
            val = fields.get(key)
            val_str = sanitize(str(val)) if val is not None else ""
            lbl = label(key, translations) + ":"
            
            if val_str:
                parts.append(f"{lbl} {val_str}")
            else:
                parts.append(lbl)
        
        if parts:
            line = bullet.join(parts)
            right_lines.append(line)
    rh = _with_font_size(10, "\n".join(right_lines)) if right_lines else ""

    return lh, ch, rh`;
