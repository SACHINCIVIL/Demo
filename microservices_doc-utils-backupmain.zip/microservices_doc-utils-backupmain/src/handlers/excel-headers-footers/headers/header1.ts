/**
 * Excel header layout 1: left = headerText, center = Doc No + Doc Name, right = dynamic selections.
 */
export const BUILD_HEADER_PY = String.raw`def build_header(cfg):
    fields = cfg.get("fields", {}) or {}
    selections = cfg.get("selections", []) or []
    translations = cfg.get("translations", {})

    # LEFT HEADER
    lh = _with_font_size(10, sanitize(cfg.get('headerText') or ''))

    # CENTER HEADER (Doc No, Doc Name)
    center = []
    if fields.get("docNo"):
        center.append(sanitize(fields["docNo"]))
    if fields.get("docName"):
        center.append(sanitize(fields["docName"]))
    ch = _with_font_size(10, "\n".join(center)) if center else ""

    # RIGHT HEADER (Dynamic selections)
    right = []
    for sel in selections:
        key = sel.get("key") if isinstance(sel, dict) else sel
        if fields.get(key):
            right.append(f"{label(key, translations)}: {sanitize(fields[key])}")
    rh = _with_font_size(10, "\n".join(right)) if right else ""

    return lh, ch, rh`;
