import type { RequestHandler } from "express";
import JSZip from "jszip";
import AWS from "aws-sdk";
import { execFile } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { promisify } from "util";
import {
  addDocumentSummaryToDocument,
  DocumentSummaryData,
  createNextRelId,
} from "./documentSummary";
import {
  formatDatesInObject,
  formatDatesInDocumentSummary,
} from "../utils/dateFormat";
import { logPaperSize } from "../utils/paperSize";
import * as header1 from "./headers/header1";
import * as header2 from "./headers/header2";
import * as header3 from "./headers/header3";
import * as header4 from "./headers/header4";
import * as header5 from "./headers/header5";
import * as header6 from "./headers/header6";
import * as emptyHeader from "./headers/emptyHeader";
import * as footer1 from "./footers/footer1";
import * as footer2 from "./footers/footer2";
import * as footer3 from "./footers/footer3";
import * as footer4 from "./footers/footer4";
import * as footer5 from "./footers/footer5";
import * as smallHeader from "./headers/small/header";
import * as smallFooter from "./footers/small/footer";
import { getPaperSizeFromDocumentXml } from "../utils/paperSize";

const HEADER_MIN_WIDTH_CM: Record<string, number> = {
  header1: 18.5,
  header2: 21.0,
  header3: 21.0,
  header4: 18.0,
  header5: 20.0,
  header6: 18, // header6: ~18cm
};

const HEADER_LAYOUTS: Record<string, any> = {
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
};
const FOOTER_LAYOUTS: Record<string, typeof footer1> = {
  footer1,
  footer2,
  footer3,
  footer4,
  footer5,
};
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "./docxShared";
import {
  EMU_PER_INCH,
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  clampOpacity,
} from "./docxShared";
export type { Align } from "./docxShared";

function normalizeHexColor(color?: string) {
  if (!color) return "#808080";
  const trimmed = color.trim();
  if (!trimmed) return "#808080";
  if (/^#?[0-9a-fA-F]{6}$/.test(trimmed)) {
    return trimmed.startsWith("#") ? trimmed : `#${trimmed}`;
  }
  return "#808080";
}

// Removed hexToRgb01 as PDF watermarking was eliminated

function parseBoolean(value: any): boolean | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const lower = value.trim().toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
  }
  return undefined;
}

function getWatermarkOptions(payload: any): WatermarkOptions | undefined {
  if (!payload) return undefined;
  const text =
    typeof payload.watermarkText === "string"
      ? payload.watermarkText.trim()
      : "";
  if (!text) return undefined;
  const maybeOpacity =
    payload.watermarkOpacity != null
      ? Number(payload.watermarkOpacity)
      : undefined;
  const maybeFontSize =
    payload.watermarkFontSize != null
      ? Number(payload.watermarkFontSize)
      : undefined;
  const diagonal = parseBoolean(payload.watermarkDiagonal);
  const angle =
    payload.watermarkAngle != null ? Number(payload.watermarkAngle) : undefined;
  const direction =
    typeof payload.watermarkDirection === "string"
      ? (payload.watermarkDirection.toLowerCase() as "up" | "down")
      : undefined;
  const positionRaw =
    typeof payload.watermarkPosition === "string"
      ? payload.watermarkPosition.toLowerCase()
      : undefined;
  const position: "horizontal" | "diagonal" | undefined =
    positionRaw === "horizontal"
      ? "horizontal"
      : positionRaw === "diagonal"
        ? "diagonal"
        : undefined;
  return {
    text,
    fontFamily:
      typeof payload.watermarkFontFamily === "string"
        ? payload.watermarkFontFamily
        : undefined,
    color:
      typeof payload.watermarkColor === "string"
        ? payload.watermarkColor
        : undefined,
    opacity: maybeOpacity,
    fontSize: maybeFontSize,
    diagonal,
    angleDegrees: Number.isFinite(angle) ? (angle as number) : undefined,
    direction:
      direction === "up" || direction === "down" ? direction : undefined,
    position,
  };
}

// Ensure DOCX targets a modern Word compatibility mode and that settings part exists
async function ensureModernCompatibility(zip: JSZip) {
  const settingsPath = "word/settings.xml";
  const relsPath = "word/_rels/document.xml.rels";
  const contentTypesPath = "[Content_Types].xml";

  // 1) Load or create settings.xml
  let settingsXml: string;
  const existing = zip.file(settingsPath);
  if (existing) {
    settingsXml = await existing.async("text");
  } else {
    settingsXml =
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
      `<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n` +
      `  <w:compat>\n` +
      `    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>\n` +
      `  </w:compat>\n` +
      `</w:settings>`;
    zip.file(settingsPath, settingsXml);
  }

  // 2) Upsert <w:compatSetting w:name="compatibilityMode" w:val="16"/>
  let updated = settingsXml;
  if (!/<w:compat[\s\S]*?<\/w:compat>/.test(updated)) {
    updated = updated.replace(
      /<\/w:settings>/,
      `  <w:compat>\n  </w:compat>\n</w:settings>`,
    );
  }
  if (/<w:compatSetting[^>]*w:name="compatibilityMode"/.test(updated)) {
    updated = updated.replace(
      /(<w:compatSetting[^>]*w:name="compatibilityMode"[^>]*w:val=")\d+("[^>]*\/>)/,
      "$116$2",
    );
  } else {
    updated = updated.replace(
      /<w:compat>/,
      `<w:compat>\n    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>`,
    );
  }
  zip.file(settingsPath, updated);

  // 3) Ensure Content Types has override for settings
  const ctFile = zip.file(contentTypesPath);
  if (ctFile) {
    let ctXml = await ctFile.async("text");
    ctXml = addOverrideIfMissing(
      ctXml,
      "/word/settings.xml",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml",
    );
    zip.file(contentTypesPath, ctXml);
  }

  // 4) Ensure _rels has relationship to settings
  const relsFile = zip.file(relsPath);
  if (relsFile) {
    let relsXml = await relsFile.async("text");
    const hasSettings =
      /Type="http:\/\/schemas.openxmlformats.org\/officeDocument\/2006\/relationships\/settings"/.test(
        relsXml,
      );
    if (!hasSettings) {
      const ids = nextRelId(relsXml);
      relsXml = upsertRelationship(
        relsXml,
        ids.settingsId,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings",
        "settings.xml",
      );
      zip.file(relsPath, relsXml);
    }
  }
}

function addOverrideIfMissing(
  contentTypesXml: string,
  partPath: string,
  contentType: string,
) {
  if (contentTypesXml.includes(`PartName="${partPath}"`))
    return contentTypesXml;
  const insertBefore = "</Types>";
  const override = `  <Override PartName="${partPath}" ContentType="${contentType}"/>\n`;
  if (contentTypesXml.includes(insertBefore)) {
    return contentTypesXml.replace(insertBefore, override + insertBefore);
  }
  return contentTypesXml + override;
}

/**
 * Determines if a document needs header/footer diversion based on paper width.
 * Returns the module to use and a scale multiplier for watermarks.
 */
async function getDocxDiversionInfo(
  zip: JSZip,
  headerLayoutName: string,
  footerLayoutName: string,
) {
  const name = headerLayoutName.toLowerCase().trim();
  let scaleMultiplier = 1.0;
  let useSmall = false;

  const documentXml = await zip.file("word/document.xml")?.async("text");
  if (documentXml) {
    const paperInfo = getPaperSizeFromDocumentXml(documentXml);
    const minWidth = HEADER_MIN_WIDTH_CM[name] || 0;
    if (paperInfo.widthCm && paperInfo.widthCm < minWidth) {
      console.log(
        `[docxHandler] Narrow paper detected (${paperInfo.widthCm}cm). Applying diversion and 30% scaling.`,
      );
      scaleMultiplier = 0.7;
      useSmall = true;
    }
  }

  const headerModule = (HEADER_LAYOUTS[name] ??
    HEADER_LAYOUTS.header1) as typeof header1;
  const footerModule = (FOOTER_LAYOUTS[footerLayoutName.toLowerCase().trim()] ??
    FOOTER_LAYOUTS.footer1) as typeof footer1;

  return {
    headerModule: useSmall ? (smallHeader as any) : headerModule,
    footerModule: useSmall ? (smallFooter as any) : footerModule,
    scaleMultiplier,
  };
}

function addDefaultIfMissing(
  contentTypesXml: string,
  extension: string,
  contentType: string,
) {
  if (contentTypesXml.includes(`Extension="${extension}"`))
    return contentTypesXml;
  const insertBefore = "</Types>";
  const def = `  <Default Extension="${extension}" ContentType="${contentType}"/>\n`;
  if (contentTypesXml.includes(insertBefore)) {
    return contentTypesXml.replace(insertBefore, def + insertBefore);
  }
  return contentTypesXml + def;
}

function nextRelId(relsXml: string) {
  const ids = Array.from(relsXml.matchAll(/Id="rId(\d+)"/g)).map((m) =>
    parseInt(m[1]!, 10),
  );
  const max = ids.length ? Math.max(...ids) : 0;
  return {
    headerId: `rId${max + 1}`,
    footerId: `rId${max + 2}`,
    settingsId: `rId${max + 3}`,
  } as const;
}

function upsertRelationship(
  relsXml: string,
  id: string,
  type: string,
  target: string,
) {
  if (relsXml.includes(`Id="${id}"`)) return relsXml;
  const insertBefore = "</Relationships>";
  const rel = `  <Relationship Id="${id}" Type="${type}" Target="${target}"/>\n`;
  if (relsXml.includes(insertBefore))
    return relsXml.replace(insertBefore, rel + insertBefore);
  return relsXml + rel;
}

/**
 * Strip any existing header/footer relationships from document.xml.rels so that
 * re-processing a previously processed document does not accumulate duplicate
 * or conflicting relationship entries (which WOPI edit mode rejects).
 */
function cleanStaleHeaderFooterRels(relsXml: string): string {
  return relsXml
    .replace(
      /\s*<Relationship[^>]*Type="[^"]*\/header"[^>]*\/>\r?\n?/g,
      "",
    )
    .replace(
      /\s*<Relationship[^>]*Type="[^"]*\/footer"[^>]*\/>\r?\n?/g,
      "",
    );
}

// UPDATED FUNCTION WITH DEFAULT MARGINS
function ensureSectPrWithRefs(
  documentXml: string,
  headerRelId: string | null | undefined,
  footerRelId: string | null | undefined,
  allPages: boolean,
  headerMarginTwips?: number,
  footerMarginTwips?: number,
) {
  let updated = documentXml;

  const headerRefDefault = headerRelId
    ? `<w:headerReference w:type="default" r:id="${headerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const footerRefDefault = footerRelId
    ? `<w:footerReference w:type="default" r:id="${footerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const headerRefFirst = headerRelId
    ? `<w:headerReference w:type="first" r:id="${headerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const footerRefFirst = footerRelId
    ? `<w:footerReference w:type="first" r:id="${footerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";

  const titlePg = allPages ? "" : `<w:titlePg/>`;
  const refs = allPages
    ? `${headerRefDefault}${footerRefDefault}`
    : `${headerRefFirst}${footerRefFirst}`;

  // Default margins: 1 inch = 1440 twips for left and right
  const DEFAULT_LEFT_MARGIN = 1440; // 1 inch
  const DEFAULT_RIGHT_MARGIN = 1440; // 1 inch

  const updatePgMarHeaderFooter = (pgMarXml: string) => {
    let out = pgMarXml;

    // Preserve left margin if present; otherwise, set to 1 inch default
    if (!/w:left="\d+"/.test(out)) {
      out = out.replace(
        /<w:pgMar([^>]*)\/>/, 
        `<w:pgMar$1 w:left="${DEFAULT_LEFT_MARGIN}"/>`,
      );
    }

    // Preserve right margin if present; otherwise, set to 1 inch default
    if (!/w:right="\d+"/.test(out)) {
      out = out.replace(
        /<w:pgMar([^>]*)\/>/, 
        `<w:pgMar$1 w:right="${DEFAULT_RIGHT_MARGIN}"/>`,
      );
    }

    // Update header margin if provided
    if (headerMarginTwips != null) {
      if (/w:header="\d+"/.test(out)) {
        out = out.replace(/w:header="\d+"/, `w:header="${headerMarginTwips}"`);
      } else {
        out = out.replace(
          /<w:pgMar([^>]*)\/>/, 
          `<w:pgMar$1 w:header="${headerMarginTwips}"/>`,
        );
      }
    }

    // Update footer margin if provided
    if (footerMarginTwips != null) {
      if (/w:footer="\d+"/.test(out)) {
        out = out.replace(/w:footer="\d+"/, `w:footer="${footerMarginTwips}"`);
      } else {
        out = out.replace(
          /<w:pgMar([^>]*)\/>/, 
          `<w:pgMar$1 w:footer="${footerMarginTwips}"/>`,
        );
      }
    }
    return out;
  };

  // No sectPr at all — create one from scratch
  if (!/<w:sectPr[\s\S]*?<\/w:sectPr>/.test(updated)) {
    const pgMar = `<w:pgMar w:left="${DEFAULT_LEFT_MARGIN}" w:right="${DEFAULT_RIGHT_MARGIN}"${
      headerMarginTwips != null ? ` w:header="${headerMarginTwips}"` : ""
    }${footerMarginTwips != null ? ` w:footer="${footerMarginTwips}"` : ""}/>`;
    const sectPr = `<w:sectPr>${titlePg}${refs}${pgMar}</w:sectPr>`;
    updated = updated.replace(/<\/w:body>/, sectPr + "</w:body>");
    return updated;
  }

  // Every w:sectPr that still mentions old header/footer r:id values will break
  // after cleanStaleHeaderFooterRels() removed those relationships — Word then
  // reports corruption. Intermediate section breaks must be repointed at the
  // new header/footer relationship ids (same target part, single r:id each).
  const sectPrRegex = /<w:sectPr[\s\S]*?<\/w:sectPr>/g;
  const allMatches = [...updated.matchAll(sectPrRegex)];
  if (allMatches.length === 0) return updated;

  // Earlier sections: only replace stale header/footer refs with valid default
  // refs (no pgMar surgery — preserves per-section page size/margins).
  const intermediateRefs = `${headerRefDefault}${footerRefDefault}`;

  const patchIntermediateSectPr = (original: string) => {
    let block = original.replace(/<w:headerReference[\s\S]*?\/>/g, "");
    block = block.replace(/<w:footerReference[\s\S]*?\/>/g, "");
    if (allPages) {
      block = block.replace(/<w:titlePg\/?>/g, "");
    }
    if (!intermediateRefs) return block;
    return block.replace(
      /<w:sectPr(?:[^>]*)>/,
      (m) => m + intermediateRefs,
    );
  };

  const lastIdx = allMatches.length - 1;
  const pieces: string[] = [];
  let cursor = 0;
  for (let i = 0; i < allMatches.length; i++) {
    const m = allMatches[i]!;
    const start = m.index!;
    pieces.push(updated.slice(cursor, start));
    if (i === lastIdx) {
      let block = m[0];
      block = block.replace(/<w:headerReference[\s\S]*?\/>/g, "");
      block = block.replace(/<w:footerReference[\s\S]*?\/>/g, "");
      if (allPages) {
        block = block.replace(/<w:titlePg\/?>/g, "");
      }
      if (/<w:pgMar[\s\S]*?\/>/.test(block)) {
        block = block.replace(/<w:pgMar[\s\S]*?\/>/, (pgMar) =>
          updatePgMarHeaderFooter(pgMar),
        );
        block = block.replace(/<w:sectPr(?:[^>]*)>/, (open) => open + titlePg + refs);
      } else {
        const pgMar = `<w:pgMar w:left="${DEFAULT_LEFT_MARGIN}" w:right="${DEFAULT_RIGHT_MARGIN}"${
          headerMarginTwips != null ? ` w:header="${headerMarginTwips}"` : ""
        }${
          footerMarginTwips != null ? ` w:footer="${footerMarginTwips}"` : ""
        }/>`;
        block = block.replace(
          /<w:sectPr(?:[^>]*)>/,
          (open) => open + titlePg + refs + pgMar,
        );
      }
      pieces.push(block);
    } else {
      pieces.push(patchIntermediateSectPr(m[0]));
    }
    cursor = start + m[0].length;
  }
  pieces.push(updated.slice(cursor));
  return pieces.join("");
}

function isWebP(contentType: string | null, url: string) {
  return !!(contentType?.includes("image/webp") || /\.webp$/i.test(url));
}

function guessImageExtension(contentType: string | null, url: string) {
  if (contentType?.includes("png") || url.toLowerCase().endsWith(".png"))
    return "png";
  if (
    contentType?.includes("jpeg") ||
    contentType?.includes("jpg") ||
    /\.jpe?g$/i.test(url)
  )
    return "jpg";
  if (contentType?.includes("gif") || /\.gif$/i.test(url)) return "gif";
  return "png";
}

// Read basic image dimensions for PNG/JPEG/GIF to preserve aspect ratio
function getImageDimensions(
  buf: Buffer,
): { width: number; height: number } | undefined {
  if (!buf || buf.length < 10) return undefined;
  // PNG
  if (
    buf.length > 24 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47
  ) {
    const width = buf.readUInt32BE(16);
    const height = buf.readUInt32BE(20);
    return width && height ? { width, height } : undefined;
  }
  // GIF
  if (
    buf.length > 10 &&
    buf[0] === 0x47 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x38 &&
    (buf[4] === 0x39 || buf[4] === 0x37) &&
    buf[5] === 0x61
  ) {
    const width = buf.readUInt16LE(6);
    const height = buf.readUInt16LE(8);
    return width && height ? { width, height } : undefined;
  }
  // JPEG (scan for SOF marker)
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) {
        i++;
        continue;
      }
      const marker = buf[i + 1];
      const len = buf.readUInt16BE(i + 2);
      if (
        marker === 0xc0 ||
        marker === 0xc1 ||
        marker === 0xc2 ||
        marker === 0xc3 ||
        marker === 0xc5 ||
        marker === 0xc6 ||
        marker === 0xc7 ||
        marker === 0xc9 ||
        marker === 0xca ||
        marker === 0xcb ||
        marker === 0xcd ||
        marker === 0xce ||
        marker === 0xcf
      ) {
        const height = buf.readUInt16BE(i + 5);
        const width = buf.readUInt16BE(i + 7);
        return width && height ? { width, height } : undefined;
      }
      i += 2 + len;
    }
  }
  return undefined;
}

const TWIPS_PER_INCH = 1440;
// Helper function to download file from S3
async function downloadFromS3(
  bucketName: string,
  key: string,
  versionId?: string,
): Promise<Buffer> {
  const params: AWS.S3.GetObjectRequest = {
    Bucket: bucketName,
    Key: key,
    ...(versionId && { VersionId: versionId }),
  };

  const result = await s3.getObject(params).promise();
  return result.Body as Buffer;
}

// Helper function to download watermark logo from FRAMEWORK_BUCKET (no versioning)
async function downloadWatermarkLogo(key: string): Promise<Buffer> {
  const bucketName = process.env.FRAMEWORK_BUCKET || "";
  if (!bucketName) {
    throw new Error("FRAMEWORK_BUCKET environment variable is not set");
  }
  const params: AWS.S3.GetObjectRequest = {
    Bucket: bucketName,
    Key: key,
  };
  const result = await s3.getObject(params).promise();
  return result.Body as Buffer;
}
const s3 = new AWS.S3({
  // Add your AWS configuration here
  region: process.env.AWS_REGION || "us-east-1",
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

// Removed addPdfWatermark as printing relies on DOCX VML watermark only

export const handleDocxAttach: RequestHandler = async (req, res) => {
  console.log("Processing handleDocxAttach");
  try {
    const {
      s3Path = "",
      s3Version = "",
      sourceBucketName = process.env.BUCKET_NAME,
      filename,
      headerText = "",
      footerText = "",
      includePageNumbers = true,
      allPages = true,
      headerAlign = "center",
      footerAlign = "right",
      headerImageUrl = "",
      headerImageWidthInch = 1.8,
      headerMarginInch,
      footerMarginInch,
      documentSummary,
    } = req.body as any;

    if (!s3Path || !sourceBucketName) {
      return res.status(400).json({
        error: "s3Path, sourceBucketName,  are required",
      });
    }
    const fileBuffer = await downloadFromS3(
      sourceBucketName,
      s3Path,
      s3Version,
    );
    const zip = await JSZip.loadAsync(fileBuffer);

    let imageRelId: string | null = null;
    let imagePath = "";
    let imageWidthEmu = Math.round(
      EMU_PER_INCH * (Number(headerImageWidthInch) || 1.8),
    );
    let imageHeightEmu = Math.round(imageWidthEmu * 0.35);

    const {
      headerModule,
      footerModule,
      scaleMultiplier,
    } = await getDocxDiversionInfo(
      zip,
      (req.body as any)?.headerLayoutName || "header1",
      (req.body as any)?.footerLayoutName || "footer1",
    );

    // Remove stale header/footer files injected by previous runs so we start
    // from a clean slate and avoid duplicate relationship/content-type entries.
    zip.remove("word/header1.xml");
    zip.remove("word/footer1.xml");
    zip.remove("word/_rels/header1.xml.rels");

    // Read the header rels file (may not exist yet) to assign safe, non-colliding IDs
    const existingHeaderRelsXml =
      (await zip.file("word/_rels/header1.xml.rels")?.async("text")) ?? "";
    const headerImageIds = nextRelId(existingHeaderRelsXml);

    let warning: string | undefined;
    if (headerImageUrl && typeof headerImageUrl === "string") {
      try {
        const response = await fetch(headerImageUrl);
        if (!response.ok)
          throw new Error(`Failed to fetch header image: ${response.status}`);
        const arrayBuf = await response.arrayBuffer();
        const contentType = response.headers.get("content-type");
        if (isWebP(contentType, headerImageUrl)) {
          warning =
            "Header image is WebP. Word doesn't support WebP; image skipped. Use PNG/JPG/GIF.";
        } else {
          const ext = guessImageExtension(contentType, headerImageUrl);
          imagePath = `word/media/header-image-1.${ext}`;
          imageRelId = headerImageIds.headerId; // dynamic, never collides
          const buf = Buffer.from(arrayBuf);
          const dims = getImageDimensions(buf);
          if (dims && dims.width > 0 && dims.height > 0) {
            const aspect = dims.height / dims.width;
            imageHeightEmu = Math.round(imageWidthEmu * aspect);
          }
          zip.file(imagePath, buf);
        }
      } catch (e) {
        imageRelId = null;
      }
    }

    const dateFormat = (req.body as any)?.dateFormat as string | undefined;
    const formattedFields = formatDatesInObject(
      (req.body as any)?.fields || (req.body as any),
      dateFormat,
    );
    const formattedSummary = formatDatesInDocumentSummary(
      documentSummary,
      dateFormat,
    );
    const watermarkOptions = getWatermarkOptions(req.body as any);
    if (watermarkOptions && scaleMultiplier < 1.0 && watermarkOptions.fontSize) {
      watermarkOptions.fontSize = Math.round(watermarkOptions.fontSize * scaleMultiplier);
    }

    // Handle watermark logo if enabled
    const watermarkLogoEnable = parseBoolean(
      (req.body as any)?.watermarkLogoEnable,
    );
    const watermarkPath = (req.body as any)?.watermarkPath as
      | string
      | undefined;
    let watermarkImageRelId: string | null = null;
    let watermarkImagePath = "";
    let watermarkImageOptions: WatermarkImageOptions | undefined;

    if (
      watermarkLogoEnable &&
      watermarkPath &&
      typeof watermarkPath === "string"
    ) {
      try {
        const watermarkBuffer = await downloadWatermarkLogo(watermarkPath);
        const ext = guessImageExtension(null, watermarkPath);
        watermarkImagePath = `word/media/watermark-logo.${ext}`;
        // Use a dynamic ID based on the header rels to avoid collision with imageRelId
        watermarkImageRelId = headerImageIds.footerId;

        // Get watermark logo size from request body, default to 4x4 inches
        const widthInch =
          ((req.body as any)?.watermarkLogoWidthInch != null
            ? Number((req.body as any).watermarkLogoWidthInch)
            : 4) * scaleMultiplier;
        const heightInch =
          ((req.body as any)?.watermarkLogoHeightInch != null
            ? Number((req.body as any).watermarkLogoHeightInch)
            : 4) * scaleMultiplier;

        let aspectRatio: number | undefined;
        const dims = getImageDimensions(watermarkBuffer);
        if (dims && dims.width > 0 && dims.height > 0) {
          aspectRatio = dims.width / dims.height;
        }

        watermarkImageOptions = {
          imageBuffer: watermarkBuffer,
          imageExtension: ext,
          opacity: watermarkOptions?.opacity,
          position: watermarkOptions?.position,
          widthInch,
          heightInch,
          aspectRatio,
        };

        zip.file(watermarkImagePath, watermarkBuffer);
      } catch (e: any) {
        console.error("Failed to load watermark logo:", e?.message || e);
        watermarkImageRelId = null;
      }
    }

    console.log("Watermark Added:", watermarkImageRelId ? "YES" : "NO");
    if (watermarkImageOptions) {
      console.log(
        "Watermark Dimensions:",
        watermarkImageOptions.widthInch +
          "x" +
          watermarkImageOptions.heightInch +
          " inch",
      );
    }

    const headerEnabled = !!(req.body as any)?.headerEnabled;
    const footerEnabled = !!(req.body as any)?.footerEnabled;
    const headerModuleToUse = headerEnabled ? headerModule : (emptyHeader as typeof header1);
    const headerXml = headerModuleToUse.buildHeaderXmlTable({
      withImage: !!imageRelId,
      imageRelId,
      imageWidthEmu,
      imageHeightEmu,
      docCode: (req.body as any)?.docCode,
      docTitle: (req.body as any)?.docTitle,
      company: (req.body as any)?.company,
      seriesLabel: (req.body as any)?.seriesLabel,
      docNo: (req.body as any)?.docNo,
      versionNo: (req.body as any)?.versionNo,
      centerKeys: (req.body as any)?.center,
      selectionKeys: (req.body as any)?.selections,
      fields: formattedFields,
      watermarkOptions: watermarkImageRelId ? undefined : watermarkOptions,
      watermarkImageRelId,
      watermarkImageOptions,
      language: (req.body as any)?.language || "en",
    });
    const footerXml = footerModule.buildFooterXmlTable({
      footerKeys: (req.body as any)?.footer,
      fields: formattedFields,
      language: (req.body as any)?.language || "en",
    });
    // Always write header (full layout or empty space when headerEnabled is false)
    zip.file("word/header1.xml", headerXml);
    if (footerEnabled) zip.file("word/footer1.xml", footerXml);

    // Build header rels with both header image and watermark image if present
    if (
      (imageRelId && imagePath) ||
      (watermarkImageRelId && watermarkImagePath)
    ) {
      let headerRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n`;
      if (imageRelId && imagePath) {
        headerRels += `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imagePath.replace(
          /^word\//,
          "",
        )}"/>\n`;
      }
      if (watermarkImageRelId && watermarkImagePath) {
        headerRels += `  <Relationship Id="${watermarkImageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${watermarkImagePath.replace(
          /^word\//,
          "",
        )}"/>\n`;
      }
      headerRels += `</Relationships>`;
      zip.file("word/_rels/header1.xml.rels", headerRels);
    }

    const ctPath = "[Content_Types].xml";
    let ctXml = await zip.file(ctPath)!.async("text");
    // Always register header (full or empty)
    ctXml = addOverrideIfMissing(
      ctXml,
      "/word/header1.xml",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml",
    );
    if (footerEnabled) {
      ctXml = addOverrideIfMissing(
        ctXml,
        "/word/footer1.xml",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml",
      );
    }
    ctXml = addDefaultIfMissing(ctXml, "png", "image/png");
    ctXml = addDefaultIfMissing(ctXml, "jpg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "jpeg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "gif", "image/gif");
    zip.file(ctPath, ctXml);

    const relsPath = "word/_rels/document.xml.rels";
    let relsXml = await zip.file(relsPath)!.async("text");
    // Strip stale header/footer rels from previous runs before computing new IDs
    relsXml = cleanStaleHeaderFooterRels(relsXml);
    const ids = nextRelId(relsXml);
    // Always add header relationship (full or empty)
    relsXml = upsertRelationship(
      relsXml,
      ids.headerId,
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header",
      "header1.xml",
    );
    if (footerEnabled) {
      relsXml = upsertRelationship(
        relsXml,
        ids.footerId,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer",
        "footer1.xml",
      );
    }
    zip.file(relsPath, relsXml);

    const docPath = "word/document.xml";
    let docXml = await zip.file(docPath)!.async("text");
    logPaperSize(docXml);
    const headerMarginTwips =
      headerMarginInch != null
        ? Math.round(Number(headerMarginInch) * TWIPS_PER_INCH)
        : undefined;
    const footerMarginTwips =
      footerMarginInch != null
        ? Math.round(Number(footerMarginInch) * TWIPS_PER_INCH)
        : undefined;
    docXml = ensureSectPrWithRefs(
      docXml,
      ids.headerId,
      footerEnabled ? ids.footerId : null,
      !!allPages,
      headerMarginTwips,
      footerMarginTwips,
    );

    // Add document summary if provided
    if (formattedSummary) {
      docXml = await addDocumentSummaryToDocument(
        docXml,
        formattedSummary,
        zip,
        createNextRelId(relsXml),
        (req.body as any)?.language || "en",
      );
    }

    zip.file(docPath, docXml);

    // Ensure modern compatibility to avoid legacy save warnings
    await ensureModernCompatibility(zip);

    const out = await zip.generateAsync({ type: "nodebuffer" });
    const outB64 = out.toString("base64");
    const shouldPrint = !!(req.body as any)?.shouldPrint;
    console.log("shouldPrint", shouldPrint);
    if (shouldPrint) {
      try {
        const pdfBase64 = await convertDocxBase64ToPdfBase64(outB64);
        return res.json({
          fileBase64: pdfBase64,
          filename:
            (filename ? filename.replace(/\.docx?$/i, "") : "modified") +
            ".pdf",
          warning,
        });
      } catch (e) {
        // Fallback to DOCX on conversion failure
        return res.json({
          fileBase64: outB64,
          filename: filename || "modified.docx",
          warning,
        });
      }
    }
    return res.json({
      fileBase64: outB64,
      filename: filename || "modified.docx",
      warning,
    });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: String(err) });
  }
};

// Helper function to execute Python code directly for DOC to DOCX conversion

const execFileAsync = promisify(execFile);

// Convert DOCX base64 to PDF base64 using LibreOffice
async function convertDocxBase64ToPdfBase64(
  docxBase64: string,
): Promise<string> {
  const tempDir = os.tmpdir();
  const tempDocxPath = path.join(tempDir, `docx_${Date.now()}.docx`);
  const tempPdfPath = path.join(tempDir, `docx_${Date.now()}.pdf`);

  try {
    const buffer = Buffer.from(docxBase64, "base64");
    fs.writeFileSync(tempDocxPath, buffer);

    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_docx_to_pdf_libreoffice(docx_path, output_path):
    try:
        libreoffice_paths = [
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ]

        libreoffice_exe = None
        for p in libreoffice_paths:
            if os.path.exists(p):
                libreoffice_exe = p
                break
            elif p in ["soffice", "libreoffice"]:
                try:
                    r = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        libreoffice_exe = p
                        break
                except:
                    continue

        if not libreoffice_exe:
            raise Exception("LibreOffice not found")

        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/f', '/im', 'soffice.exe'], capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill', '/f', '/im', 'soffice.bin'], capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill', '-f', 'soffice'], capture_output=True, check=False, timeout=5)
        except:
            pass

        time.sleep(1)

        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)

        cmd = [
            libreoffice_exe,
            "--headless",
            "--invisible",
            "--nodefault",
            "--nolockcheck",
            "--nologo",
            "--norestore",
            "--safe-mode",
            "--convert-to", "pdf",
            "--outdir", output_dir,
            docx_path
        ]

        env = os.environ.copy()
        env['SAL_USE_VCLPLUGIN'] = 'svp'
        env['DISPLAY'] = ':0.0'

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env)
        if result.returncode != 0:
            msg = f"LibreOffice conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                msg += f": {result.stderr.strip()}"
            raise Exception(msg)

        time.sleep(1.0)

        if not os.path.exists(output_path):
            raise Exception("Converted PDF file not found")

        print("SUCCESS")

    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    docx_path = "${tempDocxPath.replace(/\\/g, "\\\\")}"
    output_path = "${tempPdfPath.replace(/\\/g, "\\\\")}"
    convert_docx_to_pdf_libreoffice(docx_path, output_path)
`;

    const pythonScriptPath = path.join(
      tempDir,
      `convert_docx_pdf_${Date.now()}.py`,
    );
    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      const pythonCmd = process.platform === "win32" ? "python" : "python3";
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000,
          maxBuffer: 50 * 1024 * 1024,
        },
      );

      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}

      if (!stdout.includes("SUCCESS")) {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }

      if (!fs.existsSync(tempPdfPath)) {
        throw new Error("Converted PDF file not found");
      }

      const pdfBuffer = fs.readFileSync(tempPdfPath);
      const pdfBase64 = pdfBuffer.toString("base64");

      try {
        fs.unlinkSync(tempDocxPath);
        fs.unlinkSync(tempPdfPath);
      } catch {}

      return pdfBase64;
    } catch (err: any) {
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}
      throw err;
    }
  } finally {
    try {
      if (fs.existsSync(tempDocxPath)) fs.unlinkSync(tempDocxPath);
    } catch {}
  }
}

// Alternative implementation using execFile (simpler and more reliable)
async function convertDocToDocxFromS3(
  s3Path: string,
  s3Version: string,
  filename: string,
): Promise<string> {
  const tempDir = os.tmpdir();
  // Use a single, shared timestamp so input and expected output basenames match
  const ts = Date.now();
  const tempDocPath = path.join(tempDir, `temp_${ts}.doc`);
  const tempDocxPath = path.join(tempDir, `temp_${ts}.docx`);

  try {
    // Download the DOC file from S3
    const params: AWS.S3.GetObjectRequest = {
      Bucket: process.env.BUCKET_NAME || "",
      Key: s3Path,
    };

    if (s3Version && s3Version.trim() !== "") {
      params.VersionId = s3Version;
    }

    const result = await s3.getObject(params).promise();
    const docBuffer = result.Body as Buffer;

    // Write DOC file to temp location
    fs.writeFileSync(tempDocPath, docBuffer);

    // Create Python script for conversion
    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_doc_to_docx_libreoffice(doc_path, output_path):
    """Convert DOC to DOCX using LibreOffice"""
    try:
        # Find LibreOffice executable
        libreoffice_paths = [
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ]
        
        libreoffice_exe = None
        for path in libreoffice_paths:
            if os.path.exists(path):
                libreoffice_exe = path
                break
            elif path in ["soffice", "libreoffice"]:
                try:
                    result = subprocess.run([path, "--version"], 
                                          capture_output=True, text=True, timeout=5)
                    if result.returncode == 0:
                        libreoffice_exe = path
                        break
                except:
                    continue
        
        if not libreoffice_exe:
            raise Exception("LibreOffice not found")
        
        # Kill any existing LibreOffice processes
        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/f', '/im', 'soffice.exe'], 
                             capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill', '/f', '/im', 'soffice.bin'], 
                             capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill', '-f', 'soffice'], 
                             capture_output=True, check=False, timeout=5)
        except:
            pass
        
        time.sleep(1)
        
        # Create output directory
        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)
        
        # LibreOffice conversion command
        cmd = [
            libreoffice_exe,
            "--headless",
            "--invisible",
            "--nodefault",
            "--nolockcheck",
            "--nologo",
            "--norestore",
            "--safe-mode",
            "--convert-to", "docx",
            "--outdir", output_dir,
            doc_path
        ]
        
        # Set environment variables
        env = os.environ.copy()
        env['SAL_USE_VCLPLUGIN'] = 'svp'
        env['DISPLAY'] = ':0.0'
        
        # Execute conversion
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, env=env)
        
        if result.returncode != 0:
            error_msg = f"LibreOffice conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                error_msg += f": {result.stderr.strip()}"
            raise Exception(error_msg)
        
        time.sleep(0.5)
        
        if not os.path.exists(output_path):
            raise Exception("Converted DOCX file not found")
        
        print("SUCCESS")
        
    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

# Main execution
if __name__ == "__main__":
    doc_path = "${tempDocPath.replace(/\\/g, "\\\\")}"
    output_path = "${tempDocxPath.replace(/\\/g, "\\\\")}"
    convert_doc_to_docx_libreoffice(doc_path, output_path)
`;

    // Write Python script to temp file
    const pythonScriptPath = path.join(tempDir, `convert_${Date.now()}.py`);
    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      // Execute Python script using execFile (Windows uses "python", others use "python3")
      const pythonCmd = process.platform === "win32" ? "python" : "python3";
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000, // 2 minutes timeout
          maxBuffer: 50 * 1024 * 1024, // 50MB buffer
        },
      );

      // Clean up Python script
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch (e) {
        console.warn("Failed to clean up Python script:", e);
      }

      if (stdout.includes("SUCCESS")) {
        // Read the converted DOCX file
        if (fs.existsSync(tempDocxPath)) {
          const docxBuffer = fs.readFileSync(tempDocxPath);
          const base64Result = docxBuffer.toString("base64");

          // Clean up temp files
          try {
            fs.unlinkSync(tempDocPath);
            fs.unlinkSync(tempDocxPath);
          } catch (e) {
            console.warn("Failed to clean up temp files:", e);
          }

          return base64Result;
        } else {
          throw new Error("Converted DOCX file not found");
        }
      } else {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }
    } catch (error: any) {
      // Clean up Python script on error
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch (e) {
        console.warn("Failed to clean up Python script:", e);
      }

      if (error.code === "ETIMEDOUT") {
        throw new Error("Conversion process timed out");
      } else {
        throw new Error(`Python conversion failed: ${error.message}`);
      }
    }
  } catch (error: any) {
    // Clean up temp files on any error
    try {
      if (fs.existsSync(tempDocPath)) fs.unlinkSync(tempDocPath);
      if (fs.existsSync(tempDocxPath)) fs.unlinkSync(tempDocxPath);
    } catch (e) {
      console.warn("Failed to clean up temp files:", e);
    }

    throw new Error(`DOC to DOCX conversion failed: ${error.message}`);
  }
}

// New handler for DOC to DOCX conversion with header/footer
export const handleDocConversion: RequestHandler = async (req, res) => {
  try {
    const {
      s3Path = "",
      s3Version = "",
      sourceBucketName = process.env.BUCKET_NAME,
      filename,
      allPages = true,
      headerImageUrl = "",
      headerImageWidthInch = 1.8,
      headerMarginInch,
      footerMarginInch,
      documentSummary,
    } = req.body as any;

    if (!s3Path || !sourceBucketName) {
      return res.status(400).json({
        error: "s3Path and sourceBucketName are required",
      });
    }

    // Step 1: Convert DOC to DOCX using direct Python execution
    console.log("Converting DOC to DOCX...");
    const convertedDocxBase64 = await convertDocToDocxFromS3(
      s3Path,
      s3Version || "",
      filename || "document.doc",
    );

    // Step 2: Process the converted DOCX with headers/footers using existing logic
    console.log("Processing DOCX with headers and footers...");
    const fileBuffer = Buffer.from(convertedDocxBase64, "base64");
    const zip = await JSZip.loadAsync(fileBuffer);

    const {
      headerModule,
      footerModule,
      scaleMultiplier,
    } = await getDocxDiversionInfo(
      zip,
      (req.body as any)?.headerLayoutName || "header1",
      (req.body as any)?.footerLayoutName || "footer1",
    );

    let imageRelId: string | null = null;
    let imagePath = "";
    let imageWidthEmu = Math.round(
      EMU_PER_INCH * (Number(headerImageWidthInch) || 1.8),
    );
    let imageHeightEmu = Math.round(imageWidthEmu * 0.35);

    let warning: string | undefined;
    if (headerImageUrl && typeof headerImageUrl === "string") {
      try {
        const response = await fetch(headerImageUrl);
        if (!response.ok)
          throw new Error(`Failed to fetch header image: ${response.status}`);
        const arrayBuf = await response.arrayBuffer();
        const contentType = response.headers.get("content-type");
        if (isWebP(contentType, headerImageUrl)) {
          warning =
            "Header image is WebP. Word doesn't support WebP; image skipped. Use PNG/JPG/GIF.";
        } else {
          const ext = guessImageExtension(contentType, headerImageUrl);
          imagePath = `word/media/header-image-1.${ext}`;
          imageRelId = "rId1";
          const buf = Buffer.from(arrayBuf);
          const dims = getImageDimensions(buf);
          if (dims && dims.width > 0 && dims.height > 0) {
            const aspect = dims.height / dims.width;
            imageHeightEmu = Math.round(imageWidthEmu * aspect);
          }
          zip.file(imagePath, buf);
        }
      } catch (e) {
        imageRelId = null;
      }
    }

    const dateFormat = (req.body as any)?.dateFormat as string | undefined;
    const formattedFields = formatDatesInObject(
      (req.body as any)?.fields || (req.body as any),
      dateFormat,
    );
    const formattedSummary = formatDatesInDocumentSummary(
      documentSummary,
      dateFormat,
    );
    const watermarkOptions = getWatermarkOptions(req.body as any);
    if (watermarkOptions && scaleMultiplier < 1.0 && watermarkOptions.fontSize) {
      watermarkOptions.fontSize = Math.round(watermarkOptions.fontSize * scaleMultiplier);
    }

    // Handle watermark logo if enabled
    const watermarkLogoEnable = parseBoolean(
      (req.body as any)?.watermarkLogoEnable,
    );
    const watermarkPath = (req.body as any)?.watermarkPath as
      | string
      | undefined;
    let watermarkImageRelId: string | null = null;
    let watermarkImagePath = "";
    let watermarkImageOptions: WatermarkImageOptions | undefined;

    if (
      watermarkLogoEnable &&
      watermarkPath &&
      typeof watermarkPath === "string"
    ) {
      try {
        const watermarkBuffer = await downloadWatermarkLogo(watermarkPath);
        const ext = guessImageExtension(null, watermarkPath);
        watermarkImagePath = `word/media/watermark-logo.${ext}`;
        watermarkImageRelId = "rId99"; // Use a high ID to avoid conflicts

        // Get watermark logo size from request body, default to 4x4 inches
        const widthInch =
          ((req.body as any)?.watermarkLogoWidthInch != null
            ? Number((req.body as any).watermarkLogoWidthInch)
            : 4) * scaleMultiplier;
        const heightInch =
          ((req.body as any)?.watermarkLogoHeightInch != null
            ? Number((req.body as any).watermarkLogoHeightInch)
            : 4) * scaleMultiplier;

        let aspectRatio: number | undefined;
        const dims = getImageDimensions(watermarkBuffer);
        if (dims && dims.width > 0 && dims.height > 0) {
          aspectRatio = dims.width / dims.height;
        }

        watermarkImageOptions = {
          imageBuffer: watermarkBuffer,
          imageExtension: ext,
          opacity: watermarkOptions?.opacity,
          position: watermarkOptions?.position,
          widthInch,
          heightInch,
          aspectRatio,
        };

        zip.file(watermarkImagePath, watermarkBuffer);
      } catch (e) {
        console.error("Failed to load watermark logo:", e);
        watermarkImageRelId = null;
      }
    }

    const headerEnabled = !!(req.body as any)?.headerEnabled;
    const footerEnabled = !!(req.body as any)?.footerEnabled;
    const headerModuleToUse = headerEnabled ? headerModule : (emptyHeader as typeof header1);
    const headerXml = headerModuleToUse.buildHeaderXmlTable({
      withImage: !!imageRelId,
      imageRelId,
      imageWidthEmu,
      imageHeightEmu,
      docCode: (req.body as any)?.docCode,
      docTitle: (req.body as any)?.docTitle,
      company: (req.body as any)?.company,
      seriesLabel: (req.body as any)?.seriesLabel,
      docNo: (req.body as any)?.docNo,
      versionNo: (req.body as any)?.versionNo,
      centerKeys: (req.body as any)?.center,
      selectionKeys: (req.body as any)?.selections,
      fields: formattedFields,
      watermarkOptions: watermarkImageRelId ? undefined : watermarkOptions,
      watermarkImageRelId,
      watermarkImageOptions,
      language: (req.body as any)?.language || "en",
    });

    const footerXml = footerModule.buildFooterXmlTable({
      footerKeys: (req.body as any)?.footer,
      fields: formattedFields,
      language: (req.body as any)?.language || "en",
    });

    // Always write header (full layout or empty space when headerEnabled is false)
    zip.file("word/header1.xml", headerXml);
    if (footerEnabled) zip.file("word/footer1.xml", footerXml);

    // Build header rels
    if (
      (imageRelId && imagePath) ||
      (watermarkImageRelId && watermarkImagePath)
    ) {
      let headerRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n`;
      if (imageRelId && imagePath) {
        headerRels += `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imagePath.replace(
          /^word\//,
          "",
        )}"/>\n`;
      }
      if (watermarkImageRelId && watermarkImagePath) {
        headerRels += `  <Relationship Id="${watermarkImageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${watermarkImagePath.replace(
          /^word\//,
          "",
        )}"/>\n`;
      }
      headerRels += `</Relationships>`;
      zip.file("word/_rels/header1.xml.rels", headerRels);
    }

    const ctPath = "[Content_Types].xml";
    let ctXml = await zip.file(ctPath)!.async("text");
    ctXml = addOverrideIfMissing(ctXml, "/word/header1.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml");
    if (footerEnabled) {
      ctXml = addOverrideIfMissing(ctXml, "/word/footer1.xml", "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml");
    }
    ctXml = addDefaultIfMissing(ctXml, "png", "image/png");
    ctXml = addDefaultIfMissing(ctXml, "jpg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "jpeg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "gif", "image/gif");
    zip.file(ctPath, ctXml);

    const relsPath = "word/_rels/document.xml.rels";
    let relsXml = await zip.file(relsPath)!.async("text");
    const ids = nextRelId(relsXml);
    relsXml = upsertRelationship(relsXml, ids.headerId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header", "header1.xml");
    if (footerEnabled) {
      relsXml = upsertRelationship(relsXml, ids.footerId, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer", "footer1.xml");
    }
    zip.file(relsPath, relsXml);

    const docPath = "word/document.xml";
    let docXml = await zip.file(docPath)!.async("text");
    const headerMarginTwips = headerMarginInch != null ? Math.round(Number(headerMarginInch) * TWIPS_PER_INCH) : undefined;
    const footerMarginTwips = footerMarginInch != null ? Math.round(Number(footerMarginInch) * TWIPS_PER_INCH) : undefined;
    docXml = ensureSectPrWithRefs(docXml, ids.headerId, footerEnabled ? ids.footerId : null, !!allPages, headerMarginTwips, footerMarginTwips);

    if (formattedSummary) {
      docXml = await addDocumentSummaryToDocument(docXml, formattedSummary, zip, createNextRelId(relsXml), (req.body as any)?.language || "en");
    }

    zip.file(docPath, docXml);
    await ensureModernCompatibility(zip);

    const out = await zip.generateAsync({ type: "nodebuffer" });
    const outB64 = out.toString("base64");
    const shouldPrint = !!(req.body as any)?.shouldPrint;
    if (shouldPrint) {
      try {
        const pdfBase64 = await convertDocxBase64ToPdfBase64(outB64);
        return res.json({
          fileBase64: pdfBase64,
          filename: (filename ? filename.replace(/\.docx?$/i, "") : "converted_and_processed") + ".pdf",
          warning,
          conversionInfo: "DOC converted to DOCX, processed with headers/footers, and exported to PDF",
        });
      } catch (e) {
        return res.json({
          fileBase64: outB64,
          filename: filename || "converted_and_processed.docx",
          warning,
          conversionInfo: "DOC converted to DOCX and processed with headers/footers (PDF export failed)",
        });
      }
    }

    return res.json({
      fileBase64: outB64,
      filename: filename || "converted_and_processed.docx",
      warning,
      conversionInfo: "DOC converted to DOCX and processed with headers/footers",
    });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: String(err) });
  }
};

export default handleDocxAttach;
