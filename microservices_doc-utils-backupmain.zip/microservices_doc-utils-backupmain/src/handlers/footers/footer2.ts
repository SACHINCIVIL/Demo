import { getXlsxTranslation } from "../../utils/translations";
import { xmlEscape, DEFAULT_FONT_FAMILY } from "../docxShared";

// Footer font: Open Sans, 9pt (half-points = 18)
const SZ = "18";
const rFonts =
  `<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/>`;

// Page number field run: "Page No: 1 / 1" — label bold, value normal, 9pt
const pageNoRun = (sz: string, fonts: string) => `
  <w:r><w:rPr><w:b/>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve">Page No: </w:t></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> PAGE \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve"> / </w:t></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> NUMPAGES \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>`;

// 2x2 grid: order from footer array. Row 1: first key left, second key right. Row 2: middle keys left (joined by |), last key right. Labels bold, company address and footer comments value only, Open Sans 9pt.
export function buildFooterXmlTable(params: {
  footerKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const { footerKeys, fields, language } = params;

  const footerKeysNorm = Array.isArray(footerKeys)
    ? footerKeys.map((k) => String(k))
    : [];
  const fieldsObj: Record<string, any> =
    fields && typeof fields === "object" ? fields : {};

  const authorLabels = (() => {
    const a =
      typeof fieldsObj["authorLabel"] === "string"
        ? fieldsObj["authorLabel"]
        : "";
    const b =
      typeof fieldsObj["actionLabel"] === "string"
        ? fieldsObj["actionLabel"]
        : "";
    const c =
      typeof fieldsObj["action"] === "string" ? fieldsObj["action"] : "";
    const picked = a.trim() || b.trim() || c.trim() || "Author";
    const cleaned = picked.replace(/:\s*$/, "");
    const lower = cleaned.trim().toLowerCase();
    const isPrinted = lower === "printed by";
    const isDownloaded = lower === "downloaded by";

    return {
      authorLabel: isPrinted
        ? getXlsxTranslation("printedBy", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedBy", language)
          : cleaned,
      dateLabel: isPrinted
        ? getXlsxTranslation("printedOn", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedOn", language)
          : getXlsxTranslation("downloadedPrintedOn", language),
    };
  })();

  const { authorLabel, dateLabel } = authorLabels;
  const footerCommentsLabel = getXlsxTranslation("footerComments", language);

  const allowedFooterKeys = [
    "pageNo",
    "footerComments",
    "dateTime",
    "userInitials",
    "companyAddress",
    "comments",
  ];

  // Unique keys, filtered for allowed list and data presence; order follows footerKeys
  const keysToRender = Array.from(new Set(footerKeysNorm))
    .filter((k) => allowedFooterKeys.includes(k))
    .filter((k) => {
      if (k === "pageNo") return true;
      const v = fieldsObj[k === "footerComments" ? "comments" : k];
      return v != null && String(v).trim() !== "";
    });

  if (keysToRender.length === 0) return "";

  // Helper runs
  const p = (t: string) =>
    `<w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(String(t))}</w:t></w:r>`;
  const pLabel = (t: string) =>
    `<w:r><w:rPr><w:b/>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(String(t))}</w:t></w:r>`;
  const labelValueRuns = (label: string, value: string) =>
    value ? `${pLabel(label + ": ")}${p(value)}` : "";
  const pipeRun = `<w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve"> | </w:t></w:r>`;

  const runsForKey = (k: string): string => {
    switch (k) {
      case "pageNo":
        return pageNoRun(SZ, rFonts);
      case "footerComments": {
        const v =
          fieldsObj["comments"] != null ? String(fieldsObj["comments"]) : "";
        return v ? labelValueRuns("  " + footerCommentsLabel, v) : "";
      }
      case "dateTime": {
        const v =
          fieldsObj["dateTime"] != null ? String(fieldsObj["dateTime"]) : "";
        return v ? labelValueRuns(dateLabel, v) : "";
      }
      case "userInitials": {
        const v =
          fieldsObj["userInitials"] != null
            ? String(fieldsObj["userInitials"])
            : "";
        return v ? labelValueRuns(authorLabel, v) : "";
      }
      case "companyAddress": {
        const v =
          fieldsObj["companyAddress"] != null
            ? String(fieldsObj["companyAddress"])
            : "";
        return v ? p(v) : "";
      }
      case "comments": {
        const v =
          fieldsObj["comments"] != null ? String(fieldsObj["comments"]) : "";
        return v ? p(v) : "";
      }
      default:
        return "";
    }
  };

  // 2x2 Grid assignment
  const row1Left = keysToRender.length > 0 ? runsForKey(keysToRender[0]!) : "";
  const row1Right =
    keysToRender.length >= 2
      ? runsForKey(keysToRender[keysToRender.length - 1]!)
      : "";
  const row2Right =
    keysToRender.length >= 3 ? runsForKey(keysToRender[1]!) : "";
  const row2Left =
    keysToRender.length >= 4
      ? keysToRender.slice(2, -1).map(runsForKey).filter(Boolean).join(pipeRun)
      : "";

  const firstParagraph = `
    <w:p>
      <w:pPr>
        <w:tabs><w:tab w:val="right" w:pos="11000"/></w:tabs>
      </w:pPr>
      ${row1Left}<w:r><w:tab/></w:r>${row1Right}
    </w:p>`;

  const secondParagraph = `
    <w:p>
      <w:pPr>
        <w:tabs><w:tab w:val="right" w:pos="11000"/></w:tabs>
      </w:pPr>
      ${row2Left}<w:r><w:tab/></w:r>${row2Right}
    </w:p>`;

  const content: string[] = [];
  if (row1Left || row1Right) content.push(firstParagraph);
  if (row2Left || row2Right) content.push(secondParagraph);

  if (content.length === 0) return "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
  ${content.join("\n")}
</w:ftr>`;
}
