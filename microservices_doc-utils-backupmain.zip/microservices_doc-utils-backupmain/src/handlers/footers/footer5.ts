import { getXlsxTranslation } from "../../utils/translations";
import { xmlEscape, DEFAULT_FONT_FAMILY } from "../docxShared";

// Left column: Open Sans 9pt (half-points = 18), labels bold
const SZ = "18";
const rFonts =
  `<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/>`;

// Right column: current page number large and bold (~18pt = 36 half-points)
const SZ_PAGE = "36";

// Page run row 1: PAGE field only, large bold (e.g. "01")
const pageNumberLargeRun = (sz: string, fonts: string) => `
  <w:r><w:rPr><w:b/>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr><w:b/>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> PAGE \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr><w:b/>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>`;

// Page run row 2: "Of " + NUMPAGES (smaller, regular)
const pageOfRun = (sz: string, fonts: string) => `
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve">Of </w:t></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> NUMPAGES \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>`;

// Two rows: left = dynamic data only (first two keys from footer array, pageNo excluded). Right = always static page no layout: row1 large bold current page, row2 "Of XX". Open Sans; company address and footer comments value only.
export function buildFooterXmlTable(params: {
  footerKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const { footerKeys, fields, language } = params;

  const footerKeysNorm = Array.isArray(footerKeys)
    ? footerKeys.map((k) => String(k))
    : [];
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const authorLabels = (() => {
    const a =
      fieldsObj && typeof fieldsObj["authorLabel"] === "string"
        ? fieldsObj["authorLabel"]
        : undefined;
    const b =
      fieldsObj && typeof fieldsObj["actionLabel"] === "string"
        ? fieldsObj["actionLabel"]
        : undefined;
    const c =
      fieldsObj && typeof fieldsObj["action"] === "string"
        ? fieldsObj["action"]
        : undefined;
    const picked =
      (a && a.trim()) || (b && b.trim()) || (c && c.trim()) || "Author";
    const cleaned = picked.replace(/:\s*$/, "");
    const lower = cleaned.trim().toLowerCase();
    const isPrinted = lower === "printed by";
    const isDownloaded = lower === "downloaded by";

    return {
      authorLabel: isPrinted
        ? getXlsxTranslation("printedBy", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedBy", language)
          : cleaned,
      dateLabel: isPrinted
        ? getXlsxTranslation("printedOn", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedOn", language)
          : getXlsxTranslation("downloadedPrintedOn", language),
    };
  })();

  const { authorLabel, dateLabel } = authorLabels;
  const footerCommentsLabel = getXlsxTranslation("footerComments", language);

  const allowedFooterKeys = [
    "pageNo",
    "footerComments",
    "dateTime",
    "userInitials",
    "companyAddress",
    "comments",
  ];

  const keysToRender = footerKeysNorm
    .filter((k) => allowedFooterKeys.includes(k))
    .filter((k) => {
      if (k === "pageNo") return true;
      const v = fieldsObj
        ? fieldsObj[k === "footerComments" ? "comments" : k]
        : undefined;
      return v != null && String(v).trim() !== "";
    });

  // Left side: dynamic data only (keys from payload, pageNo excluded)
  const leftKeys = keysToRender.filter((k) => k !== "pageNo");

  const p = (t: string) =>
    `<w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      String(t),
    )}</w:t></w:r>`;

  const pLabel = (t: string) =>
    `<w:r><w:rPr><w:b/>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      String(t),
    )}</w:t></w:r>`;

  const labelValueRuns = (label: string, value: string) =>
    value ? `${pLabel(label + ": ")}${p(value)}` : "";

  const runsForKey = (k: string): string => {
    switch (k) {
      case "pageNo":
        return "";
      case "footerComments": {
        const v =
          fieldsObj && fieldsObj["comments"] != null
            ? String(fieldsObj["comments"])
            : "";
        return v ? labelValueRuns("  " + footerCommentsLabel, v) : "";
      }
      case "dateTime": {
        const v =
          fieldsObj && fieldsObj["dateTime"] != null
            ? String(fieldsObj["dateTime"])
            : "";
        if (!v) return "";
        return labelValueRuns(dateLabel, v);
      }
      case "userInitials": {
        const v =
          fieldsObj && fieldsObj["userInitials"] != null
            ? String(fieldsObj["userInitials"])
            : "";
        if (!v) return "";
        return labelValueRuns(authorLabel, v);
      }
      case "companyAddress": {
        const v =
          fieldsObj && fieldsObj["companyAddress"] != null
            ? String(fieldsObj["companyAddress"])
            : "";
        return v ? p(v) : "";
      }
      case "comments": {
        const v =
          fieldsObj && fieldsObj["comments"] != null
            ? String(fieldsObj["comments"])
            : "";
        return v ? p(v) : "";
      }
      default:
        return "";
    }
  };

  const row1Left = runsForKey(leftKeys[0] ?? "");
  const row2Left = leftKeys.length >= 2 ? runsForKey(leftKeys[1] ?? "") : "";

  // Right side: always static page number layout (large current page, then "Of XX")
  const row1Right = pageNumberLargeRun(SZ_PAGE, rFonts);
  const row2Right = pageOfRun(SZ, rFonts);

  const firstParagraph = `
    <w:p>
      <w:pPr>
        <w:tabs>
          <w:tab w:val="right" w:pos="11000"/>
        </w:tabs>
      </w:pPr>
      ${row1Left}
      <w:r><w:tab/></w:r>
      ${row1Right}
    </w:p>`;

  const secondParagraph = `
    <w:p>
      <w:pPr>
        <w:tabs>
          <w:tab w:val="right" w:pos="11000"/>
        </w:tabs>
      </w:pPr>
      ${row2Left}
      <w:r><w:tab/></w:r>
      ${row2Right}
    </w:p>`;

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:ftr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${firstParagraph}
    ${secondParagraph}
  </w:ftr>`;
}
