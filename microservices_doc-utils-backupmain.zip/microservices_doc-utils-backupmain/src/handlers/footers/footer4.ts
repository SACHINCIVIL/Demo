import { getXlsxTranslation } from "../../utils/translations";
import { xmlEscape, DEFAULT_FONT_FAMILY } from "../docxShared";

// Footer font: Open Sans, 9pt (half-points = 18)
const SZ = "18";
const rFonts =
  `<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/>`;

// Page run: "Page X of Y" (right-aligned) — 9pt
const pageOfRun = (sz: string, fonts: string) => `
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve">Page </w:t></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> PAGE \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve"> of </w:t></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:instrText xml:space="preserve"> NUMPAGES \\* MERGEFORMAT </w:instrText></w:r>
  <w:r><w:rPr>${fonts}<w:sz w:val="${sz}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>`;

// Single row: left = all keys (in footer array order) joined by " | ", right = Page X of Y. pageNo goes on right; other keys on left. Company address and footer comments value only. Open Sans 9pt, labels bold where present.
export function buildFooterXmlTable(params: {
  footerKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const { footerKeys, fields, language } = params;

  const normalizeKeys = (arr: any): string[] | undefined =>
    Array.isArray(arr) ? arr.map((k) => String(k)) : undefined;
  const footerKeysNorm = normalizeKeys(footerKeys);
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const authorLabels = (() => {
    const a =
      fieldsObj && typeof fieldsObj["authorLabel"] === "string"
        ? fieldsObj["authorLabel"]
        : undefined;
    const b =
      fieldsObj && typeof fieldsObj["actionLabel"] === "string"
        ? fieldsObj["actionLabel"]
        : undefined;
    const c =
      fieldsObj && typeof fieldsObj["action"] === "string"
        ? fieldsObj["action"]
        : undefined;
    const picked =
      (a && a.trim()) || (b && b.trim()) || (c && c.trim()) || "Author";
    const cleaned = picked.replace(/:\s*$/, "");
    const lower = cleaned.trim().toLowerCase();
    const isPrinted = lower === "printed by";
    const isDownloaded = lower === "downloaded by";

    return {
      authorLabel: isPrinted
        ? getXlsxTranslation("printedBy", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedBy", language)
          : cleaned,
      dateLabel: isPrinted
        ? getXlsxTranslation("printedOn", language)
        : isDownloaded
          ? getXlsxTranslation("downloadedOn", language)
          : getXlsxTranslation("downloadedPrintedOn", language),
    };
  })();

  const { authorLabel, dateLabel } = authorLabels;
  const footerCommentsLabel = getXlsxTranslation("footerComments", language);

  const allowedFooterKeys = [
    "pageNo",
    "footerComments",
    "dateTime",
    "userInitials",
    "companyAddress",
    "comments",
  ];

  const keysToRender = (
    footerKeysNorm && footerKeysNorm.length
      ? footerKeysNorm.filter((k) => allowedFooterKeys.includes(k))
      : allowedFooterKeys
  ).slice(0, allowedFooterKeys.length);

  // Value run: Open Sans, 9pt, normal
  const p = (t: string) =>
    `<w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      String(t),
    )}</w:t></w:r>`;

  // Label run: Open Sans, 9pt, bold
  const pLabel = (t: string) =>
    `<w:r><w:rPr><w:b/>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      String(t),
    )}</w:t></w:r>`;

  const labelValueRuns = (label: string, value: string) =>
    value ? `${pLabel(label + ": ")}${p(value)}` : "";

  const pipeRun = `<w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:t xml:space="preserve"> | </w:t></w:r>`;

  // Runs for one key. Company address and footer comments value only; others get labels (bold).
  const runsForKey = (k: string): string => {
    switch (k) {
      case "pageNo":
        return ""; // handled on right
      case "footerComments": {
        const v =
          fieldsObj && fieldsObj["comments"] != null
            ? String(fieldsObj["comments"])
            : "";
        if (!v) return "";
        return labelValueRuns("  " + footerCommentsLabel, v);
      }
      case "dateTime": {
        const v =
          fieldsObj && fieldsObj["dateTime"] != null
            ? String(fieldsObj["dateTime"])
            : "";
        if (!v) return "";
        return labelValueRuns(dateLabel, v);
      }
      case "userInitials": {
        const v =
          fieldsObj && fieldsObj["userInitials"] != null
            ? String(fieldsObj["userInitials"])
            : "";
        if (!v) return "";
        return labelValueRuns(authorLabel, v);
      }
      case "companyAddress": {
        const v =
          fieldsObj && fieldsObj["companyAddress"] != null
            ? String(fieldsObj["companyAddress"])
            : "";
        return v ? p(v) : "";
      }
      case "comments": {
        const v =
          fieldsObj && fieldsObj["comments"] != null
            ? String(fieldsObj["comments"])
            : "";
        return v ? p(v) : "";
      }
      default:
        return "";
    }
  };

  const leftKeys = keysToRender.filter((k) => k !== "pageNo");
  const leftParts = leftKeys.map((k) => runsForKey(k)).filter(Boolean);
  const left = leftParts.join(pipeRun);

  const right = keysToRender.includes("pageNo") ? pageOfRun(SZ, rFonts) : "";

  const singleParagraph = `
    <w:p>
      <w:pPr>
        <w:tabs>
          <w:tab w:val="right" w:pos="11000"/>
        </w:tabs>
      </w:pPr>
      ${left}
      <w:r><w:tab/></w:r>
      ${right}
    </w:p>`;

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:ftr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${singleParagraph}
  </w:ftr>`;
}
