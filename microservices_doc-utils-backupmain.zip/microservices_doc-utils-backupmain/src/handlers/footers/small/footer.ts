import { xmlEscape, DEFAULT_FONT_FAMILY } from "../../docxShared";

/**
 * Small footer: a single line footer optimized for narrow paper.
 * It displays just the page number.
 */
export function buildFooterXmlTable(params: {
  footerKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const SZ = "18";
  const rFonts = `<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/>`;

  // Requested: footer should show only the current page number.
  const pageNoRun = `
    <w:r><w:rPr><w:b/>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>
    <w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:instrText xml:space="preserve"> PAGE \\* MERGEFORMAT </w:instrText></w:r>
    <w:r><w:rPr>${rFonts}<w:sz w:val="${SZ}"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r>`;

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:ftr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
      </w:pPr>
      ${pageNoRun}
    </w:p>
  </w:ftr>`;
}
