import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docCode = "",
    docTitle = "",
    company = "",
    seriesLabel = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    centerKeys,
    selectionKeys,
    fields,
  } = params;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const p = (t: string, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pSized = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  const normalizeKeys = (arr: any): string[] | undefined =>
    Array.isArray(arr) ? arr.map((k) => String(k)) : undefined;
  const centerKeysNorm = normalizeKeys(centerKeys);
  const selectionKeysNorm = normalizeKeys(selectionKeys);

  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const centerKeysFiltered = centerKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const selectionKeysFiltered = selectionKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const labelValueRuns = (
    label: string,
    value: string,
    sizeVal = 18,
    bold = true,
  ) => pSized(`${label}: `, sizeVal, bold) + pSized(value, sizeVal, false);

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedBy":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  // Build Row 1 Right and Row 2 dynamically from filtered selections
  const effectiveSelectionKeys =
    selectionKeysFiltered?.filter((k) => k !== "docName") ?? [];

  const selectionFieldsAll = effectiveSelectionKeys
    .map((k) => {
      const v = getValue(k);
      return v ? { key: k, label: makeLabel(k), value: v } : null;
    })
    .filter(Boolean) as Array<{ key: string; label: string; value: string }>;

  // Last 2 fields go to Row 1 Right
  const row1RightFields = selectionFieldsAll.slice(-2);
  // All other fields go to Row 2
  const secondLineFields = selectionFieldsAll.slice(0, -2);

  // Build Row 1 Left content (always docName for now)
  const docNameValue = getValue("docName");
  let firstLineLeftContent = "";
  if (docNameValue) {
    firstLineLeftContent = pSized(docNameValue, 20, true);
  }

  // Build Row 1 Right content
  let firstLineRightContent = "";
  if (row1RightFields.length > 0) {
    firstLineRightContent = row1RightFields
      .map(({ label, value }) => labelValueRuns(label, value, 18, true))
      .join(`<w:r><w:t xml:space="preserve"> | </w:t></w:r>`);
  }

  const firstLineContent =
    firstLineLeftContent +
    (firstLineRightContent
      ? `<w:r><w:tab/></w:r>` + firstLineRightContent
      : "");

  // Build Row 2 content
  const bulletChar = "•";
  const secondLineContent = secondLineFields
    .map(({ label, value }, i) => {
      const field = labelValueRuns(label, value, 18, true);
      if (i === secondLineFields.length - 1) return field;

      // Alternate: dot for even index, pipe for odd index
      const separator = i % 2 === 0 ? bulletChar : "|";
      return (
        field + `<w:r><w:t xml:space="preserve"> ${separator} </w:t></w:r>`
      );
    })
    .join("");

  // Calculate widths - INCREASED for wider header
  const tblWidth = 11000;
  const imageWidthTwipsForCell =
    withImage && imageRelId ? imageWidthEmu / 635 : 0;
  const logoCellWidth =
    withImage && imageRelId ? Math.round(imageWidthTwipsForCell) + 400 : 400; // Reduced from 800 to 400 to move content left
  const contentCellWidth = tblWidth - logoCellWidth;

  const tblBordersNone = `<w:tblBorders>
    <w:top w:val="none"/>
    <w:left w:val="none"/>
    <w:bottom w:val="none"/>
    <w:right w:val="none"/>
    <w:insideH w:val="none"/>
    <w:insideV w:val="none"/>
  </w:tblBorders>`;

  const headerTable = `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${tblWidth}" w:type="dxa"/>
        <w:tblInd w:w="-1320" w:type="dxa"/>
        ${tblBordersNone}
        <w:tblCellMar>
          <w:left w:w="0" w:type="dxa"/>
          <w:right w:w="0" w:type="dxa"/>
          <w:top w:w="0" w:type="dxa"/>
          <w:bottom w:w="0" w:type="dxa"/>
        </w:tblCellMar>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${logoCellWidth}"/>
        <w:gridCol w:w="${contentCellWidth}"/>
      </w:tblGrid>
      <w:tr>
        <w:trPr><w:trHeight w:val="400" w:hRule="auto"/></w:trPr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${logoCellWidth}" w:type="dxa"/>
            <w:vAlign w:val="top"/>
            <w:tcMar>
              <w:left w:w="350" w:type="dxa"/>
              <w:right w:w="120" w:type="dxa"/>
              <w:top w:w="60" w:type="dxa"/>
              <w:bottom w:w="0" w:type="dxa"/>
            </w:tcMar>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:jc w:val="left"/>
              <w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>
            </w:pPr>
            ${logoRun}
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${contentCellWidth}" w:type="dxa"/>
            <w:vAlign w:val="top"/>
            <w:tcMar>
              <w:left w:w="-800" w:type="dxa"/>
              <w:right w:w="0" w:type="dxa"/>
              <w:top w:w="60" w:type="dxa"/>
              <w:bottom w:w="0" w:type="dxa"/>
            </w:tcMar>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:tabs>
                <w:tab w:val="right" w:pos="${contentCellWidth}"/>
              </w:tabs>
              <w:jc w:val="left"/>
              <w:spacing w:before="0" w:after="120" w:line="240" w:lineRule="auto"/>
            </w:pPr>
            ${firstLineContent}
          </w:p>
          <w:p>
            <w:pPr>
              <w:jc w:val="left"/>
              <w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>
            </w:pPr>
            ${secondLineContent}
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>`;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    ${headerTable}
    <w:p>
      <w:pPr>
        <w:ind w:left="-964" w:right="-964"/>
        <w:spacing w:before="0" w:after="60" w:line="2" w:lineRule="exact"/>
        <w:pBdr>
          <w:bottom w:val="single" w:sz="18" w:space="1" w:color="000000"/>
        </w:pBdr>
      </w:pPr>
    </w:p>
    <w:p>
      <w:pPr><w:spacing w:after="120"/></w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
