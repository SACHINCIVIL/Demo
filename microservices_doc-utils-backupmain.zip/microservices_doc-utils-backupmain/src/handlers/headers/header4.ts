import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docCode = "",
    docTitle = "",
    company = "",
    seriesLabel = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    centerKeys,
    selectionKeys,
    fields,
  } = params;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const p = (t: string, b = false, size = 18) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="Open Sans" w:hAnsi="Open Sans" w:cs="Open Sans"/><w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pWithSize = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  const labelValueRuns = (label: string, value: string, sizeVal = 18) =>
    pWithSize(`${label}: `, sizeVal, true) + pWithSize(value, sizeVal, false);

  const normalizeKeys = (arr: any): string[] | undefined =>
    Array.isArray(arr) ? arr.map((k) => String(k)) : undefined;
  const centerKeysNorm = normalizeKeys(centerKeys);
  const selectionKeysNorm = normalizeKeys(selectionKeys);

  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const centerKeysFiltered = centerKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const selectionKeysFiltered = selectionKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedBy":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  const centerKeysForTitle =
    centerKeysFiltered?.filter((k) => k === "docName") ?? [];
  const centerKeysForBadge =
    centerKeysFiltered?.filter((k) => k === "docNo" || k === "version") ?? [];

  const titleText =
    centerKeysForTitle.length > 0
      ? getValue(centerKeysForTitle[0] ?? "docName")
      : docTitle;

  const docNoText = getValue("docNo") || docNo;
  const versionText = getValue("version") || versionNo;

  const badgeText = [
    docNoText ? `Doc No: ${docNoText}` : "",
    versionText ? `Version: ${versionText}` : "",
  ]
    .filter(Boolean)
    .join(" | ");

  const selectionFields = (
    selectionKeysFiltered && selectionKeysFiltered.length
      ? selectionKeysFiltered
          .filter((k) => k !== "docName" && k !== "docNo" && k !== "version")
          .map((k) => {
            const v = getValue(k);
            return v ? { label: makeLabel(k), value: v } : null;
          })
          .filter(Boolean)
      : []
  ) as Array<{ label: string; value: string }>;

  const pipeRun = `<w:r><w:rPr><w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve"> | </w:t></w:r>`;

  const buildLines = (fields: Array<{ label: string; value: string }>) => {
    const lines: string[] = [];
    for (let i = 0; i < fields.length; i += 3) {
      const group = fields.slice(i, i + 3);
      const lineContent = group
        .map((f) => labelValueRuns(f.label, f.value, 18))
        .join(pipeRun);
      lines.push(`
          <w:p>
            <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="${
              i + 3 >= fields.length ? "0" : "60"
            }"/></w:pPr>
            ${lineContent}
          </w:p>`);
    }
    return lines.join("");
  };

  const borderedTableContent = buildLines(selectionFields);

  const tblWidth = 9500;
  const logoColWidth = 2200;
  const nameColWidth = tblWidth - logoColWidth;

  // Logo first (left), doc name + Doc No | Version after logo (right), all center-aligned; table centered on page
  const headerContent = `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${tblWidth}" w:type="dxa"/>
        <w:jc w:val="center"/>
        <w:tblBorders>
          <w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/>
          <w:insideH w:val="none"/><w:insideV w:val="none"/>
        </w:tblBorders>
        <w:tblCellMar><w:left w:w="480" w:type="dxa"/><w:right w:w="0" w:type="dxa"/><w:top w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tblCellMar>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${logoColWidth}"/>
        <w:gridCol w:w="${nameColWidth}"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="${logoColWidth}" w:type="dxa"/><w:vAlign w:val="center"/><w:tcMar><w:left w:w="780" w:type="dxa"/><w:right w:w="120" w:type="dxa"/><w:top w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tcMar></w:tcPr>
          <w:p>
            <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0" w:line="280" w:lineRule="atLeast"/></w:pPr>
            ${logoRun}
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="${nameColWidth}" w:type="dxa"/><w:vAlign w:val="center"/><w:tcMar><w:left w:w="480" w:type="dxa"/><w:right w:w="0" w:type="dxa"/><w:top w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tcMar></w:tcPr>
          <w:p>
            <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="60" w:line="280" w:lineRule="atLeast"/></w:pPr>
            ${titleText ? p(titleText, true, 24) : ""}
          </w:p>
          <w:p>
            <w:pPr>
              <w:jc w:val="center"/>
              <w:spacing w:before="0" w:after="0" w:line="180" w:lineRule="exact"/>
              <w:shd w:val="clear" w:fill="EDF1F8"/>
              <w:pBdr>
                <w:top w:val="single" w:sz="4" w:space="0" w:color="B4C7E7"/>
                <w:left w:val="single" w:sz="4" w:space="2" w:color="B4C7E7"/>
                <w:bottom w:val="single" w:sz="4" w:space="0" w:color="B4C7E7"/>
                <w:right w:val="single" w:sz="4" w:space="2" w:color="B4C7E7"/>
              </w:pBdr>
            </w:pPr>
            ${badgeText ? p(badgeText, false, 18) : ""}
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>`;

  // Single bordered box: fields separated by pipes, no inner table structure; outer border only (rounded corners not supported in Word OOXML)
  const borderW = 11520;
  const borderedTable = `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${borderW}" w:type="dxa"/>
        <w:jc w:val="center"/>
        <w:tblBorders>
          <w:top w:val="none"/><w:left w:val="none"/><w:bottom w:val="none"/><w:right w:val="none"/>
          <w:insideH w:val="none"/><w:insideV w:val="none"/>
        </w:tblBorders>
        <w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/><w:top w:w="0" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tblCellMar>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${borderW}"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${borderW}" w:type="dxa"/>
            <w:tcBorders>
              <w:top w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>
              <w:left w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>
              <w:bottom w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>
              <w:right w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>
            </w:tcBorders>
            <w:tcMar><w:left w:w="120" w:type="dxa"/><w:right w:w="120" w:type="dxa"/><w:top w:w="80" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/></w:tcMar>
          </w:tcPr>
          ${borderedTableContent}
        </w:tc>
      </w:tr>
    </w:tbl>`;

  const bottomSection = borderedTable;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    ${headerContent}
    ${bottomSection}
    <w:p>
      <w:pPr><w:spacing w:after="120"/></w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
