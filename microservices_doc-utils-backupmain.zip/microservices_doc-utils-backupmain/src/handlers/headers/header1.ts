import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  // New optional, dynamic controls
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docCode = "",
    docTitle = "",
    company = "",
    seriesLabel = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    centerKeys,
    selectionKeys,
    fields,
  } = params;

  const tblBorders = `<w:tblBorders>
    <w:top w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:left w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:bottom w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:right w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:insideH w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:insideV w:val="single" w:sz="6" w:space="0" w:color="000000"/>
  </w:tblBorders>`;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const cell = (content: string, widthTwips: number, align: Align = "left") => `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="120" w:type="dxa"/>
          <w:right w:w="120" w:type="dxa"/>
          <w:top w:w="0" w:type="dxa"/>
          <w:bottom w:w="0" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>
      <w:p>
        <w:pPr>
          <w:jc w:val="${jc(align)}"/>
          <w:spacing w:before="0" w:after="0"/>
        </w:pPr>
        ${content}
      </w:p>
    </w:tc>`;

  const p = (t: string, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pSized = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pWithSize = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  // Left cell: logo and series label
  const leftContent =
    logoRun + (seriesLabel ? `<w:r><w:br/></w:r>${p(seriesLabel, true)}` : "");

  // Helpers for dynamic fields rendering
  const normalizeKeys = (arr: any): string[] | undefined =>
    Array.isArray(arr) ? arr.map((k) => String(k)) : undefined;
  const centerKeysNorm = normalizeKeys(centerKeys);
  const selectionKeysNorm = normalizeKeys(selectionKeys);

  // Only allow the following keys to be rendered in headers
  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const centerKeysFiltered = centerKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const selectionKeysFiltered = selectionKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    // Use translation if available, otherwise fallback to formatted key
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const labelValueRuns = (label: string, value: string, sizeVal = 18) =>
    pWithSize(`${label}: `, sizeVal, true) + pWithSize(value, sizeVal, false);

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    // Only return dynamic field values for whitelisted keys
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedBy":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  // Center cell content (dynamic if centerKeys provided; otherwise fallback)
  // Requirement: center renders values only (no labels)
  const centerContent =
    centerKeysFiltered && centerKeysFiltered.length
      ? centerKeysFiltered
          .map((k, i) => {
            const v = getValue(k);
            if (!v) return "";
            const run =
              k === "docName"
                ? pSized(String(v), 24, true) // 12pt bold for doc name
                : k === "docNo"
                  ? pSized(String(v), 18) // 9pt for doc no
                  : p(String(v));
            return (i > 0 ? `<w:r><w:br/></w:r>` : "") + run;
          })
          .filter(Boolean)
          .join("")
      : (docCode ? p(docCode) : "") +
        (docTitle ? `<w:r><w:br/></w:r>${pSized(docTitle, 24, true)}` : "");

  // Right cell: dynamically ordered fields (fallback to prior static list)
  const rightFields = (
    selectionKeysFiltered && selectionKeysFiltered.length
      ? selectionKeysFiltered
          .map((k) => {
            const v = getValue(k);
            return v ? { label: makeLabel(k), value: v } : null;
          })
          .filter(Boolean)
      : [
          docNo ? { label: makeLabel("docNo"), value: docNo } : null,
          versionNo ? { label: makeLabel("version"), value: versionNo } : null,
        ].filter(Boolean as any)
  ) as Array<{ label: string; value: string }>;

  const rightParts = rightFields.slice();
  const rightContent = rightParts
    .map((field, i) => {
      const isDocNo = field.label.toLowerCase().includes("doc no");
      const textRun = isDocNo
        ? labelValueRuns(field.label, field.value, 18)
        : labelValueRuns(field.label, field.value, 18);
      const horizontalLine =
        i < rightParts.length - 1
          ? `<w:r><w:br/></w:r><w:r><w:pict><v:line from="0,0" to="144,0" strokecolor="black" strokeweight="0.75pt"/></w:pict></w:r><w:r><w:br/></w:r>`
          : "";
      return textRun + horizontalLine;
    })
    .join("");

  // First row with left, center, and first right field
  const row1 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="500" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="2400" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:vMerge w:val="restart"/>
        </w:tcPr>
        <w:p>
          <w:pPr><w:jc w:val="center"/></w:pPr>
          ${leftContent}
        </w:p>
      </w:tc>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="4800" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:vMerge w:val="restart"/>
        </w:tcPr>
        <w:p>
          <w:pPr><w:jc w:val="center"/></w:pPr>
          ${centerContent}
        </w:p>
      </w:tc>
      ${cell(
        rightFields[0]
          ? labelValueRuns(rightFields[0].label, rightFields[0].value, 18)
          : "",
        2800,
        "center",
      )}
    </w:tr>`;

  // Additional rows for remaining right fields
  const additionalRows = rightFields
    .slice(1)
    .map(
      (field) => `
    <w:tr>
      <w:trPr><w:trHeight w:val="500" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="2400" w:type="dxa"/>
          <w:vMerge/>
        </w:tcPr>
        <w:p/>
      </w:tc>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="4800" w:type="dxa"/>
          <w:vMerge/>
        </w:tcPr>
        <w:p/>
      </w:tc>
      ${cell(labelValueRuns(field.label, field.value, 18), 2800, "center")}
    </w:tr>`,
    )
    .join("");

  // Company row spanning all columns
  const companyRow = company
    ? `
    <w:tr>
      <w:trPr><w:trHeight w:val="500" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:gridSpan w:val="3"/>
          <w:tcW w:w="10000" w:type="dxa"/>
          <w:vAlign w:val="center"/>
        </w:tcPr>
        <w:p>
          <w:pPr><w:jc w:val="center"/></w:pPr>
          ${p(company, true)}
        </w:p>
      </w:tc>
    </w:tr>`
    : "";

  // Use image watermark if provided, otherwise use text watermark
  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="10000" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${tblBorders}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="2400"/>
        <w:gridCol w:w="4800"/>
        <w:gridCol w:w="2800"/>
      </w:tblGrid>
      ${row1}
      ${additionalRows}
      ${companyRow}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
