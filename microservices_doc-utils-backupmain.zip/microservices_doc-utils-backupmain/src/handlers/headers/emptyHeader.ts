import type {
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
} from "../docxShared";

/**
 * Empty header: when header is disabled (headerEnabled: false), this layout
 * still writes a valid header part with a single space character so that
 * watermark and footer behavior stay the same. The header content is just one space.
 */
export function buildHeaderXmlTable(params: {
  withImage?: boolean;
  imageRelId?: string | null;
  imageWidthEmu?: number;
  imageHeightEmu?: number;
  logoAlign?: string;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
  } = params;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  // Single space as the only header content (valid OOXML)
  const spaceRun = `<w:r><w:t xml:space="preserve"> </w:t></w:r>`;

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    <w:p>
      <w:pPr>
        <w:jc w:val="left"/>
        <w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/>
      </w:pPr>
      ${spaceRun}
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  _imageRelId: string | null,
  _imageTarget: string,
) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n</Relationships>`;
}
