import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docTitle = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    fields,
  } = params;

  const gray = "D3D3D3";
  const tblBorders = `<w:tblBorders>
    <w:top w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:left w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:bottom w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:right w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:insideH w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:insideV w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
  </w:tblBorders>`;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:effectExtent l="0" t="0" r="0" b="0"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const size9 = 18;
  const size12 = 24;
  const p = (t: string, b = false, sizeVal = size9) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "modifiedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  // Single table: logo, center, then 2 columns per row for metadata (key + value in same cell, center-aligned like header5)
  const totalW = 10200;
  const logoColW = 2400;
  const centerColW = 4000;
  const rightColW = totalW - logoColW - centerColW;
  const metaCellW = Math.floor(rightColW / 2);

  const docNameText = getValue("docName") || docTitle || "Document Name";
  const docNoText = getValue("docNo") || docNo;
  const versionText = getValue("version") || versionNo;
  const docNumberLine =
    docNoText || versionText
      ? `${docNoText ? `Document Number: ${docNoText}` : ""}${docNoText && versionText ? " | " : ""}${versionText ? `Version: ${versionText}` : ""}`.trim()
      : "";

  const logoCellContent = `
        <w:p>
          <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>
          ${logoRun || `<w:r><w:t xml:space="preserve"> </w:t></w:r>`}
        </w:p>`;

  const centerCellContent = `
        <w:p>
          <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="60"/></w:pPr>
          ${p(docNameText, true, size12)}
        </w:p>
        <w:p>
          <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/><w:shd w:val="clear" w:color="auto" w:fill="E8EEF4"/></w:pPr>
          ${docNumberLine ? p(docNumberLine, false, size9) : `<w:r><w:t xml:space="preserve"> </w:t></w:r>`}
        </w:p>`;

  // Key + value in same cell, center-aligned (same as header5 labelValueCell)
  const labelValueCell = (key: string) => {
    const label = makeLabel(key);
    const labelWithColon = label.endsWith(":") ? label : `${label}:`;
    const value = getValue(key) || "—";
    return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${metaCellW}" w:type="dxa"/>
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="60" w:type="dxa"/>
          <w:right w:w="60" w:type="dxa"/>
          <w:top w:w="40" w:type="dxa"/>
          <w:bottom w:w="40" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>
      <w:p>
        <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="40"/></w:pPr>
        ${p(labelWithColon, true, size9)}
      </w:p>
      <w:p>
        <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>
        ${p(value, false, size9)}
      </w:p>
    </w:tc>`;
  };

  const selectionFields = (
    params.selectionKeys && params.selectionKeys.length
      ? params.selectionKeys
          .filter((k) => k !== "docName" && k !== "docNo" && k !== "version")
          .map((k) => k)
      : []
  ) as string[];

  // Helper to render a cell or empty tc
  const renderCellOrEmpty = (key: string | undefined) => {
    if (!key) {
      return `
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${metaCellW}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
        </w:tcPr>
        <w:p/>
      </w:tc>`;
    }
    return labelValueCell(key);
  };

  const row1MetaCells =
    renderCellOrEmpty(selectionFields[0]) +
    renderCellOrEmpty(selectionFields[1]);
  const row2MetaCells =
    renderCellOrEmpty(selectionFields[2]) +
    renderCellOrEmpty(selectionFields[3]);
  const row3MetaCells =
    renderCellOrEmpty(selectionFields[4]) +
    renderCellOrEmpty(selectionFields[5]);

  const rowHeight = 400;
  const row1 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="${rowHeight}" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${logoColW}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:vMerge w:val="restart"/>
          <w:tcMar>
            <w:left w:w="80" w:type="dxa"/>
            <w:right w:w="60" w:type="dxa"/>
            <w:top w:w="80" w:type="dxa"/>
            <w:bottom w:w="80" w:type="dxa"/>
          </w:tcMar>
        </w:tcPr>
        ${logoCellContent}
      </w:tc>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${centerColW}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:vMerge w:val="restart"/>
          <w:tcMar>
            <w:left w:w="80" w:type="dxa"/>
            <w:right w:w="80" w:type="dxa"/>
            <w:top w:w="80" w:type="dxa"/>
            <w:bottom w:w="80" w:type="dxa"/>
          </w:tcMar>
        </w:tcPr>
        ${centerCellContent}
      </w:tc>
      ${row1MetaCells}
    </w:tr>`;

  const row2 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="${rowHeight}" w:hRule="atLeast"/></w:trPr>
      <w:tc><w:tcPr><w:tcW w:w="${logoColW}" w:type="dxa"/><w:vMerge/></w:tcPr><w:p/></w:tc>
      <w:tc><w:tcPr><w:tcW w:w="${centerColW}" w:type="dxa"/><w:vMerge/></w:tcPr><w:p/></w:tc>
      ${row2MetaCells}
    </w:tr>`;

  const row3 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="${rowHeight}" w:hRule="atLeast"/></w:trPr>
      <w:tc><w:tcPr><w:tcW w:w="${logoColW}" w:type="dxa"/><w:vMerge/></w:tcPr><w:p/></w:tc>
      <w:tc><w:tcPr><w:tcW w:w="${centerColW}" w:type="dxa"/><w:vMerge/></w:tcPr><w:p/></w:tc>
      ${row3MetaCells}
    </w:tr>`;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${totalW}" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${tblBorders}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${logoColW}"/>
        <w:gridCol w:w="${centerColW}"/>
        <w:gridCol w:w="${metaCellW}"/>
        <w:gridCol w:w="${metaCellW}"/>
      </w:tblGrid>
      ${row1}
      ${row2}
      ${row3}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
