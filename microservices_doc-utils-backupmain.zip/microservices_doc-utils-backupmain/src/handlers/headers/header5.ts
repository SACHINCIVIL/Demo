import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docCode = "",
    docTitle = "",
    company = "",
    seriesLabel = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    centerKeys,
    selectionKeys,
    fields,
  } = params;

  const gray = "D3D3D3";
  const tblBorders = `<w:tblBorders>
    <w:top w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:left w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:bottom w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:right w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:insideH w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
    <w:insideV w:val="single" w:sz="6" w:space="0" w:color="${gray}"/>
  </w:tblBorders>`;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const size9 = 18;
  const size12 = 24;
  const p = (t: string, b = false, sizeVal = size9) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pSized = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "modifiedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  const totalW = 11000;
  const logoW = 2600;
  const metaW = Math.floor((totalW - logoW) / 5);

  const labelValueCell = (key: string, widthTwips: number): string => {
    const label = makeLabel(key);
    const value = getValue(key);
    const labelWithColon = label.endsWith(":") ? label : `${label}:`;
    return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="80" w:type="dxa"/>
          <w:right w:w="80" w:type="dxa"/>
          <w:top w:w="80" w:type="dxa"/>
          <w:bottom w:w="80" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>
      <w:p>
        <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="60"/></w:pPr>
        ${p(labelWithColon, true, size9)}
      </w:p>
      <w:p>
        <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>
        ${p(value || "—", false, size9)}
      </w:p>
    </w:tc>`;
  };

  const selectionFields = (
    selectionKeys && selectionKeys.length
      ? selectionKeys.filter((k) => k !== "docName").map((k) => k)
      : []
  ) as string[];

  const docNameText = getValue("docName") || docTitle || "";

  // Dynamic cell generation helper
  const renderCell = (key: string | undefined, width: number) => {
    if (!key) {
      return `
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${width}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
        </w:tcPr>
        <w:p/>
      </w:tc>`;
    }
    return labelValueCell(key, width);
  };

  const row1 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="600" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${logoW}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:vMerge w:val="restart"/>
          <w:tcMar>
            <w:left w:w="100" w:type="dxa"/>
            <w:right w:w="100" w:type="dxa"/>
            <w:top w:w="100" w:type="dxa"/>
            <w:bottom w:w="100" w:type="dxa"/>
          </w:tcMar>
        </w:tcPr>
        <w:p>
          <w:pPr><w:jc w:val="center"/></w:pPr>
          ${logoRun}
        </w:p>
      </w:tc>
      ${[0, 1, 2, 3, 4].map((i) => renderCell(selectionFields[i], metaW)).join("")}
    </w:tr>`;

  const row2 = `
    <w:tr>
      <w:trPr><w:trHeight w:val="700" w:hRule="atLeast"/></w:trPr>
      <w:tc>
        <w:tcPr>
          <w:tcW w:w="${logoW}" w:type="dxa"/>
          <w:vMerge/>
        </w:tcPr>
        <w:p/>
      </w:tc>
      <w:tc>
        <w:tcPr>
          <w:gridSpan w:val="4"/>
          <w:tcW w:w="${4 * metaW}" w:type="dxa"/>
          <w:vAlign w:val="center"/>
          <w:tcMar>
            <w:left w:w="120" w:type="dxa"/>
            <w:right w:w="120" w:type="dxa"/>
            <w:top w:w="80" w:type="dxa"/>
            <w:bottom w:w="80" w:type="dxa"/>
          </w:tcMar>
        </w:tcPr>
        <w:p>
          <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="0"/></w:pPr>
          ${pSized(docNameText || "Document Name", size12, true)}
        </w:p>
      </w:tc>
      ${renderCell(selectionFields[5], metaW)}
    </w:tr>`;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${totalW}" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${tblBorders}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${logoW}"/>
        <w:gridCol w:w="${metaW}"/>
        <w:gridCol w:w="${metaW}"/>
        <w:gridCol w:w="${metaW}"/>
        <w:gridCol w:w="${metaW}"/>
        <w:gridCol w:w="${metaW}"/>
      </w:tblGrid>
      ${row1}
      ${row2}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
