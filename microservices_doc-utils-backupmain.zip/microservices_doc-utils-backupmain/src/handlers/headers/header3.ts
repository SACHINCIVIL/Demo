import { getHeaderTranslation } from "../../utils/translations";
import type {
  Align,
  WatermarkImageOptions,
  WatermarkOptions,
} from "../docxShared";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
  jc,
  xmlEscape,
  DEFAULT_FONT_FAMILY,
} from "../docxShared";

export function buildHeaderXmlTable(params: {
  withImage: boolean;
  imageRelId: string | null;
  imageWidthEmu: number;
  imageHeightEmu: number;
  logoAlign?: Align;
  docCode?: string;
  docTitle?: string;
  company?: string;
  seriesLabel?: string;
  docNo?: string;
  versionNo?: string;
  watermarkOptions?: WatermarkOptions;
  watermarkImageRelId?: string | null;
  watermarkImageOptions?: WatermarkImageOptions;
  centerKeys?: string[];
  selectionKeys?: string[];
  fields?: Record<string, any>;
  language?: string;
}) {
  const {
    withImage,
    imageRelId,
    imageWidthEmu,
    imageHeightEmu,
    docCode = "",
    docTitle = "",
    company = "",
    seriesLabel = "",
    docNo = "",
    versionNo = "",
    watermarkOptions,
    watermarkImageRelId,
    watermarkImageOptions,
    centerKeys,
    selectionKeys,
    fields,
  } = params;

  const logoRun =
    withImage && imageRelId
      ? `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="10" name="Logo"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr><pic:cNvPr id="0" name="logo"/><pic:cNvPicPr/></pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`
      : "";

  const p = (t: string, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pSized = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;
  const pWithSize = (t: string, sizeVal: number, b = false) =>
    `<w:r><w:rPr>${
      b ? "<w:b/>" : ""
    }<w:rFonts w:ascii="${DEFAULT_FONT_FAMILY}" w:hAnsi="${DEFAULT_FONT_FAMILY}" w:cs="${DEFAULT_FONT_FAMILY}"/><w:sz w:val="${sizeVal}"/></w:rPr><w:t xml:space="preserve">${xmlEscape(
      t,
    )}</w:t></w:r>`;

  const leftContent = logoRun;

  const normalizeKeys = (arr: any): string[] | undefined =>
    Array.isArray(arr) ? arr.map((k) => String(k)) : undefined;
  const centerKeysNorm = normalizeKeys(centerKeys);
  const selectionKeysNorm = normalizeKeys(selectionKeys);

  const allowedHeaderKeys = new Set([
    "publishedBy",
    "docNo",
    "docName",
    "version",
    "createdBy",
    "publishedOn",
    "createdOn",
    "modifiedBy",
    "modifiedOn",
    "approvedBy",
    "approvedOn",
    "reviewedBy",
    "reviewedOn",
  ]);

  const centerKeysFiltered = centerKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const selectionKeysFiltered = selectionKeysNorm?.filter((k) =>
    allowedHeaderKeys.has(k),
  );
  const fieldsObj: Record<string, any> | undefined =
    fields && typeof fields === "object" ? fields : undefined;

  const makeLabel = (k: string) => {
    const translated = getHeaderTranslation(k, params.language);
    if (translated !== k) {
      return translated;
    }
    return String(k)
      .replace(/([A-Z])/g, " $1")
      .replace(/[_\-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  };

  const labelValueRuns = (label: string, value: string, sizeVal = 18) =>
    pWithSize(`${label}: `, sizeVal, true) + pWithSize(value, sizeVal, false);

  const getValue = (key: string): string => {
    const k = String(key);
    const fromFields = fieldsObj != null ? fieldsObj[k] : undefined;
    if (
      allowedHeaderKeys.has(k) &&
      fromFields != null &&
      `${fromFields}` !== ""
    ) {
      return String(fromFields);
    }
    switch (k) {
      case "docNo":
        return docNo;
      case "version":
        return versionNo;
      case "docName":
        return (
          docTitle || (fieldsObj ? String(fieldsObj["docName"] || "") : "")
        );
      case "createdBy":
      case "publishedBy":
      case "createdOn":
      case "publishedOn":
      case "modifiedBy":
      case "modifiedOn":
      case "approvedBy":
      case "approvedOn":
      case "reviewedBy":
      case "reviewedOn":
        return fieldsObj && fieldsObj[k] != null ? String(fieldsObj[k]) : "";
      default:
        return "";
    }
  };

  const centerKeysForTitle =
    centerKeysFiltered?.filter((k) => k === "docName") ?? [];
  const centerKeysForBadge =
    centerKeysFiltered?.filter((k) => k === "docNo" || k === "version") ?? [];

  const centerContent =
    centerKeysForTitle.length > 0
      ? centerKeysForTitle
          .map((k) => {
            const v = getValue(k);
            return v ? pSized(String(v), 24, true) : "";
          })
          .filter(Boolean)
          .join("")
      : docTitle
        ? pSized(docTitle, 24, true)
        : "";

  const badgeParts = centerKeysForBadge
    .map((k) => {
      const v = getValue(k);
      return v ? { label: makeLabel(k), value: v } : null;
    })
    .filter(Boolean) as Array<{ label: string; value: string }>;

  const topRightContent = badgeParts
    .map(({ label, value }) => labelValueRuns(label, value, 18))
    .join(`<w:r><w:t xml:space="preserve"> | </w:t></w:r>`);

  const selectionFields = (
    selectionKeysFiltered && selectionKeysFiltered.length
      ? selectionKeysFiltered
          .filter((k) => k !== "docName" && k !== "docNo" && k !== "version")
          .map((k) => {
            const v = getValue(k);
            return v ? { label: makeLabel(k), value: v } : null;
          })
          .filter(Boolean)
      : []
  ) as Array<{ label: string; value: string }>;

  const bulletChar = "•";

  const joinPair = (
    a?: { label: string; value: string },
    b?: { label: string; value: string },
  ) => {
    const left = a ? labelValueRuns(a.label, a.value, 18) : "";
    const right = b ? labelValueRuns(b.label, b.value, 18) : "";
    if (left && right) {
      return (
        left +
        `<w:r><w:t xml:space="preserve"> ${bulletChar} </w:t></w:r>` +
        right
      );
    }
    return left + right;
  };

  const leftRow1 = joinPair(selectionFields[0], selectionFields[1]);
  const rightRow1 = joinPair(selectionFields[2], selectionFields[3]);
  const rightRow2 = joinPair(selectionFields[4], selectionFields[5]);

  const tblWidth = 11540;
  const imageWidthTwipsForCell =
    withImage && imageRelId ? imageWidthEmu / 635 : 0;
  const logoCellWidth =
    withImage && imageRelId ? Math.round(imageWidthTwipsForCell) + 120 : 800;
  const badgeCellWidth = 5500;
  const centerCellWidth = tblWidth - logoCellWidth - badgeCellWidth;

  // NEW APPROACH: Single table with border on the cell, no separate paragraph for line
  const headerTable = `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="${tblWidth}" w:type="dxa"/>
        <w:tblInd w:w="-1200" w:type="dxa"/>
        <w:tblBorders>
          <w:top w:val="none"/>
          <w:left w:val="none"/>
          <w:bottom w:val="none"/>
          <w:right w:val="none"/>
          <w:insideH w:val="none"/>
          <w:insideV w:val="none"/>
        </w:tblBorders>
        <w:tblCellMar>
          <w:left w:w="0" w:type="dxa"/>
          <w:right w:w="0" w:type="dxa"/>
          <w:top w:w="0" w:type="dxa"/>
          <w:bottom w:w="0" w:type="dxa"/>
        </w:tblCellMar>
        <w:tblCellSpacing w:w="0" w:type="dxa"/>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="${logoCellWidth}"/>
        <w:gridCol w:w="${centerCellWidth}"/>
        <w:gridCol w:w="${badgeCellWidth}"/>
      </w:tblGrid>
      <w:tr>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${logoCellWidth}" w:type="dxa"/>
            <w:vAlign w:val="top"/>
            <w:tcMar><w:left w:w="350" w:type="dxa"/><w:right w:w="120" w:type="dxa"/><w:top w:w="60" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tcMar>
          </w:tcPr>
          <w:p>
            <w:pPr><w:jc w:val="left"/><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>
            ${leftContent}
          </w:p>
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${centerCellWidth}" w:type="dxa"/>
            <w:vAlign w:val="top"/>
            <w:tcMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/><w:top w:w="60" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tcMar>
          </w:tcPr>
          <w:p>
            <w:pPr><w:jc w:val="left"/><w:spacing w:before="0" w:after="120" w:line="240" w:lineRule="auto"/></w:pPr>
            ${centerContent}
          </w:p>
          ${leftRow1 ? `\u003cw:p\u003e\u003cw:pPr\u003e\u003cw:jc w:val="left"/\u003e\u003cw:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/\u003e\u003c/w:pPr\u003e${leftRow1}\u003c/w:p\u003e` : ""}
        </w:tc>
        <w:tc>
          <w:tcPr>
            <w:tcW w:w="${badgeCellWidth}" w:type="dxa"/>
            <w:vAlign w:val="top"/>
            <w:tcMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/><w:top w:w="60" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/></w:tcMar>
          </w:tcPr>
          <w:p>
            <w:pPr><w:jc w:val="right"/><w:spacing w:before="0" w:after="120" w:line="240" w:lineRule="auto"/></w:pPr>
            ${topRightContent}
          </w:p>
          ${rightRow1 ? `\u003cw:p\u003e\u003cw:pPr\u003e\u003cw:jc w:val="right"/\u003e\u003cw:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/\u003e\u003c/w:pPr\u003e${rightRow1}\u003c/w:p\u003e` : ""}
          ${rightRow2 ? `\u003cw:p\u003e\u003cw:pPr\u003e\u003cw:jc w:val="right"/\u003e\u003cw:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/\u003e\u003c/w:pPr\u003e${rightRow2}\u003c/w:p\u003e` : ""}
        </w:tc>
      </w:tr>
    </w:tbl>`;

  const watermark =
    watermarkImageRelId && watermarkImageOptions
      ? buildWatermarkImageParagraph(watermarkImageRelId, watermarkImageOptions)
      : watermarkOptions
        ? buildWatermarkParagraph(watermarkOptions)
        : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
  <w:hdr xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:w10="urn:schemas-microsoft-com:office:word" xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk" xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 wp14">
    ${watermark}
    ${headerTable}
    <w:p>
      <w:pPr><w:spacing w:after="120"/></w:pPr>
    </w:p>
  </w:hdr>`;
}

export function buildHeaderRelsXml(
  imageRelId: string | null,
  imageTarget: string,
) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}
