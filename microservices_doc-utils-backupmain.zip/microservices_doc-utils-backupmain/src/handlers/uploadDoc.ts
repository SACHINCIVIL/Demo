/// <reference path="../types/express-multer.d.ts" />
import { Request, Response } from "express";
import multer from "multer";
import JSZip from "jszip";
import { execFile } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

const multerAny: any = multer as any;
export const uploadMemory: { single: (field: string) => any } = multerAny({
  storage: multerAny.memoryStorage(),
});

async function ensureModernCompatibilityZip(zip: JSZip) {
  const settingsPath = "word/settings.xml";
  const contentTypesPath = "[Content_Types].xml";

  let settingsXml: string;
  const existing = zip.file(settingsPath);
  if (existing) {
    settingsXml = await existing.async("text");
  } else {
    settingsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n  <w:compat>\n    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>\n  </w:compat>\n</w:settings>`;
    zip.file(settingsPath, settingsXml);
  }

  let updated = settingsXml;
  if (!/<w:compat[\s\S]*?<\/w:compat>/.test(updated)) {
    updated = updated.replace(
      /<\/w:settings>/,
      `  <w:compat>\n  </w:compat>\n</w:settings>`,
    );
  }
  if (/<w:compatSetting[^>]*w:name="compatibilityMode"/.test(updated)) {
    updated = updated.replace(
      /(<w:compatSetting[^>]*w:name="compatibilityMode"[^>]*w:val=")\d+("[^>]*\/>)/,
      "$116$2",
    );
  } else {
    updated = updated.replace(
      /<w:compat>/,
      `<w:compat>\n    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>`,
    );
  }
  zip.file(settingsPath, updated);

  const ctFile = zip.file(contentTypesPath);
  if (ctFile) {
    let ctXml = await ctFile.async("text");
    if (!/PartName="\/word\/settings.xml"/.test(ctXml)) {
      ctXml = ctXml.replace(
        /<\/Types>/,
        `  <Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>\n</Types>`,
      );
      zip.file(contentTypesPath, ctXml);
    }
  }
}

export const docToDocxHandler = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ error: "No file uploaded (field name 'file')" });
    }

    const originalName = req.file.originalname || "document.doc";
    const isDoc =
      /\.doc$/i.test(originalName) ||
      req.file.mimetype === "application/msword";
    if (!isDoc) {
      return res.status(400).json({ error: "Only .doc files are supported" });
    }

    const tempBaseDir = path.join(os.tmpdir(), "docs-attacher");
    try {
      fs.mkdirSync(tempBaseDir, { recursive: true });
    } catch {}

    const ts = Date.now();
    const tempDocPath = path.join(tempBaseDir, `upload_${ts}.doc`);
    const tempDocxPath = path.join(tempBaseDir, `upload_${ts}.docx`);
    const pythonScriptPath = path.join(tempBaseDir, `convert_${ts}.py`);

    fs.writeFileSync(tempDocPath, req.file.buffer);

    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_doc_to_docx_libreoffice(doc_path, output_path):
    try:
        paths = []
        override = os.environ.get("LIBREOFFICE_PATH")
        if override:
            paths.append(override)
        paths.extend([
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ])

        libreoffice_exe = None
        for p in paths:
            if os.path.exists(p):
                libreoffice_exe = p
                break
            elif p in ["soffice", "libreoffice"]:
                try:
                    r = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        libreoffice_exe = p
                        break
                except:
                    continue

        if not libreoffice_exe:
            raise Exception("LibreOffice not found")

        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/f', '/im', 'soffice.exe'], capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill', '/f', '/im', 'soffice.bin'], capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill', '-f', 'soffice'], capture_output=True, check=False, timeout=5)
        except:
            pass

        time.sleep(1)

        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)

        cmd = [
            libreoffice_exe,
            "--headless",
            "--invisible",
            "--nodefault",
            "--nolockcheck",
            "--nologo",
            "--norestore",
            "--safe-mode",
            "--convert-to", "docx",
            "--outdir", output_dir,
            doc_path
        ]

        env = os.environ.copy()
        env['SAL_USE_VCLPLUGIN'] = 'svp'
        env['DISPLAY'] = ':0.0'

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env)
        if result.returncode != 0:
            msg = f"LibreOffice conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                msg += f": {result.stderr.strip()}"
            raise Exception(msg)

        time.sleep(0.5)

        if not os.path.exists(output_path):
            raise Exception("Converted DOCX file not found")

        print("SUCCESS")

    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    doc_path = "${tempDocPath.replace(/\\/g, "\\\\")}"
    output_path = "${tempDocxPath.replace(/\\/g, "\\\\")}"
    convert_doc_to_docx_libreoffice(doc_path, output_path)
`;

    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      const pythonCmd = process.platform === "win32" ? "python" : "python3";
      console.log(
        `[DOC2DOCX] Invoking ${pythonCmd} for LibreOffice conversion...`,
      );
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000,
          maxBuffer: 50 * 1024 * 1024,
        },
      );

      if (stdout?.trim())
        console.log(`[DOC2DOCX] python stdout: ${stdout.substring(0, 500)}`);
      if (stderr?.trim())
        console.warn(`[DOC2DOCX] python stderr: ${stderr.substring(0, 500)}`);

      if (!stdout.includes("SUCCESS")) {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }

      if (!fs.existsSync(tempDocxPath)) {
        throw new Error("Converted DOCX file not found");
      }

      const docxBuffer = fs.readFileSync(tempDocxPath);
      const downloadName = originalName.replace(/\.doc$/i, "") + ".docx";
      let outBuffer: Buffer = docxBuffer;
      try {
        const zip = await JSZip.loadAsync(docxBuffer);
        await ensureModernCompatibilityZip(zip as unknown as JSZip);
        const normalized = await zip.generateAsync({ type: "uint8array" });
        outBuffer = Buffer.from(normalized);
        console.log("[DOC2DOCX] Applied modern compatibility mode");
      } catch (e) {
        console.warn("[DOC2DOCX] Compatibility normalization skipped:", e);
      }
      res.setHeader(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      );
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${downloadName}"`,
      );
      return res.status(200).send(outBuffer);
    } finally {
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}
      try {
        fs.unlinkSync(tempDocPath);
      } catch {}
      try {
        fs.unlinkSync(tempDocxPath);
      } catch {}
    }
  } catch (err: any) {
    console.error("/upload-doc-convert error", err);
    return res.status(500).json({ error: String(err?.message || err) });
  }
};
