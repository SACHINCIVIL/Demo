import { getDocumentSummaryTranslation } from "../utils/translations";

// Helper function to escape XML special characters
function xmlEscape(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

const SUMMARY_TABLE_FONT = "Arial";

function summaryRunPr(options: {
  sz?: string;
  bold?: boolean;
  color?: string;
} = {}): string {
  const { sz = "20", bold = false, color } = options;
  const boldTag = bold ? "<w:b/>" : "";
  const colorTag = color ? `<w:color w:val="${color}"/>` : "";
  return `<w:rPr><w:rFonts w:ascii="${SUMMARY_TABLE_FONT}" w:hAnsi="${SUMMARY_TABLE_FONT}" w:cs="${SUMMARY_TABLE_FONT}"/><w:sz w:val="${sz}"/>${boldTag}${colorTag}</w:rPr>`;
}

function formatSummaryAction(action: string): string {
  const trimmed = String(action || "").trim();
  if (!trimmed) return "";

  return trimmed
    .split(/(\s+|_|-)/)
    .map((part) => {
      if (!part || /^[\s_\-]+$/.test(part)) return part;
      if (part === part.toUpperCase() && /[A-Z]/.test(part)) {
        return part.charAt(0) + part.slice(1).toLowerCase();
      }
      return part;
    })
    .join("");
}

// Types for the table data
export interface WorkflowHistoryRow {
  Action: string;
  User: string;
  "Date and time": string;
  Signature: string;
  imageUrl?: string; // Optional image URL for this row
}

export interface VersionLogRow {
  Version: string;
  "Change Log Description": string;
  "Created by": string;
  "Created On": string;
  imageUrl?: string; // Optional image URL for this row
}

export interface DocumentReviewRow {
  Action: string;
  "Review comments": string;
  "Date time periodic": string;
  "Reviewed by": string;
  Signature: string;
  imageUrl?: string; // Optional image URL for this row
}

// Single, version-grouped summary row (Version / Action / Performed By / Signature / Comments).
// A single version can span multiple rows (one per audit-log action); the Version cell is
// visually merged across those rows in the rendered table.
export interface VersionSummaryRow {
  Version: string;
  "Action Type"?: string;
  Action: string;
  "Action Date"?: string;
  "Performed By": string;
  "Performed Date"?: string;
  Signature: string;
  Comments: string;
  "Comments Detail"?: string;
  imageUrl?: string; // Optional image URL for this row's signature
}

export interface DocumentSummaryData {
  workflowHistory?: WorkflowHistoryRow[];
  versionLog?: VersionLogRow[];
  documentReview?: DocumentReviewRow[];
  versionSummary?: VersionSummaryRow[];
  // Global image settings for document summary
  imageWidthInch?: number;
  imageHeightInch?: number;
}

// Helper function to create table borders
function getTableBorders() {
  return `<w:tblBorders>
    <w:top w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:left w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:bottom w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:right w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:insideH w:val="single" w:sz="6" w:space="0" w:color="000000"/>
    <w:insideV w:val="single" w:sz="6" w:space="0" w:color="000000"/>
  </w:tblBorders>`;
}

// Helper function to create table cell
function createTableCell(
  content: string,
  widthTwips: number,
  align: "left" | "center" | "right" = "left",
  isHeader: boolean = false,
  imageXml?: string
) {
  const jc =
    align === "left" ? "left" : align === "center" ? "center" : "right";

  // Add light gray background for headers
  const shading = isHeader
    ? `
        <w:shd w:val="clear" w:color="auto" w:fill="F2F2F2"/>`
    : "";

  // Create content - either text or image
  const cellContent = imageXml
    ? imageXml
    : `<w:r>${summaryRunPr({ bold: isHeader })}<w:t xml:space="preserve">${xmlEscape(content)}</w:t></w:r>`;

  return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="120" w:type="dxa"/>
          <w:right w:w="120" w:type="dxa"/>
        </w:tcMar>${shading}
      </w:tcPr>
      <w:p>
        <w:pPr><w:jc w:val="${jc}"/></w:pPr>
        ${cellContent}
      </w:p>
    </w:tc>`;
}

// Helper function to create table row
function createTableRow(cells: string[]) {
  return `
    <w:tr>
      <w:trPr><w:trHeight w:val="400" w:hRule="atLeast"/></w:trPr>
      ${cells.join("")}
    </w:tr>`;
}

// Cell that stacks a primary line over a smaller secondary line (dates).
function createStackedCell(
  primary: string,
  secondary: string,
  widthTwips: number,
  align: "left" | "center" | "right" = "left"
) {
  const jc = align === "right" ? "right" : align === "center" ? "center" : "left";

  const primaryPara = `
      <w:p>
        <w:pPr><w:jc w:val="${jc}"/><w:spacing w:after="0"/></w:pPr>
        <w:r>${summaryRunPr()}<w:t xml:space="preserve">${xmlEscape(
          primary || ""
        )}</w:t></w:r>
      </w:p>`;

  const secondaryPara = secondary
    ? `
      <w:p>
        <w:pPr><w:jc w:val="${jc}"/><w:spacing w:before="0"/></w:pPr>
        <w:r>${summaryRunPr({ sz: "16", color: "000000" })}<w:t xml:space="preserve">${xmlEscape(
          secondary
        )}</w:t></w:r>
      </w:p>`
    : "";

  return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="120" w:type="dxa"/>
          <w:right w:w="120" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>${primaryPara}${secondaryPara}
    </w:tc>`;
}

// Comments cell: label + detail flow together in regular body text.
// Labels already include the colon (e.g. "Modification Log :", "Change Log:").
function createCommentsCell(label: string, detail: string, widthTwips: number) {
  const trimmedLabel = formatSummaryAction(String(label || "").trim());
  const trimmedDetail = String(detail || "").trim();
  const text = trimmedLabel && trimmedDetail
    ? `${trimmedLabel} ${trimmedDetail}`
    : trimmedLabel || trimmedDetail;

  return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        <w:vAlign w:val="top"/>
        <w:tcMar>
          <w:left w:w="120" w:type="dxa"/>
          <w:right w:w="120" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>
      <w:p>
        <w:pPr><w:jc w:val="left"/></w:pPr>
        <w:r>${summaryRunPr()}<w:t xml:space="preserve">${xmlEscape(
          text
        )}</w:t></w:r>
      </w:p>
    </w:tc>`;
}

// region (and carries the content); otherwise the cell continues the region above it.
function createVMergeCell(
  content: string,
  widthTwips: number,
  restart: boolean,
  align: "left" | "center" | "right" = "center"
) {
  const jc = align === "right" ? "right" : align === "center" ? "center" : "left";
  const vMerge = restart
    ? `<w:vMerge w:val="restart"/>`
    : `<w:vMerge/>`;

  const body = restart
    ? `<w:r>${summaryRunPr()}<w:t xml:space="preserve">${xmlEscape(
        content || ""
      )}</w:t></w:r>`
    : "";

  return `
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="${widthTwips}" w:type="dxa"/>
        ${vMerge}
        <w:vAlign w:val="center"/>
        <w:tcMar>
          <w:left w:w="120" w:type="dxa"/>
          <w:right w:w="120" w:type="dxa"/>
        </w:tcMar>
      </w:tcPr>
      <w:p>
        <w:pPr><w:jc w:val="${jc}"/></w:pPr>
        ${body}
      </w:p>
    </w:tc>`;
}

// Image handling functions for document summary tables
const EMU_PER_INCH = 914400; // 1 inch = 914400 EMUs
const SIGNATURE_MAX_WIDTH_INCH = 0.9;
const SIGNATURE_MAX_HEIGHT_INCH = 0.35;

function fitSignatureDimensionsEmu(
  dims: { width: number; height: number } | undefined,
  maxWidthInch: number = SIGNATURE_MAX_WIDTH_INCH,
  maxHeightInch: number = SIGNATURE_MAX_HEIGHT_INCH
): { widthEmu: number; heightEmu: number } {
  const maxWidthEmu = Math.round(EMU_PER_INCH * maxWidthInch);
  const maxHeightEmu = Math.round(EMU_PER_INCH * maxHeightInch);

  if (!dims || dims.width <= 0 || dims.height <= 0) {
    return { widthEmu: maxWidthEmu, heightEmu: maxHeightEmu };
  }

  const aspect = dims.width / dims.height;
  let widthInch = maxWidthInch;
  let heightInch = widthInch / aspect;

  if (heightInch > maxHeightInch) {
    heightInch = maxHeightInch;
    widthInch = heightInch * aspect;
  }

  return {
    widthEmu: Math.round(EMU_PER_INCH * widthInch),
    heightEmu: Math.round(EMU_PER_INCH * heightInch),
  };
}

function looksLikeHttpUrl(value: string | undefined): string | null {
  if (!value) return null;
  const v = String(value).trim();
  return /^https?:\/\//i.test(v) ? v : null;
}

function isWebP(contentType: string | null, url: string) {
  return !!(contentType?.includes("image/webp") || /\.webp$/i.test(url));
}

function guessImageExtension(contentType: string | null, url: string) {
  if (contentType?.includes("png") || url.toLowerCase().endsWith(".png"))
    return "png";
  if (
    contentType?.includes("jpeg") ||
    contentType?.includes("jpg") ||
    /\.jpe?g$/i.test(url)
  )
    return "jpg";
  if (contentType?.includes("gif") || /\.gif$/i.test(url)) return "gif";
  return "png";
}

// Read basic image dimensions for PNG/JPEG/GIF to preserve aspect ratio
function getImageDimensions(
  buf: Buffer
): { width: number; height: number } | undefined {
  if (!buf || buf.length < 10) return undefined;
  // PNG
  if (
    buf.length > 24 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47
  ) {
    const width = buf.readUInt32BE(16);
    const height = buf.readUInt32BE(20);
    return width && height ? { width, height } : undefined;
  }
  // GIF
  if (
    buf.length > 10 &&
    buf[0] === 0x47 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x38 &&
    (buf[4] === 0x39 || buf[4] === 0x37) &&
    buf[5] === 0x61
  ) {
    const width = buf.readUInt16LE(6);
    const height = buf.readUInt16LE(8);
    return width && height ? { width, height } : undefined;
  }
  // JPEG (scan for SOF marker)
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) {
        i++;
        continue;
      }
      const marker = buf[i + 1];
      const len = buf.readUInt16BE(i + 2);
      if (
        marker === 0xc0 ||
        marker === 0xc1 ||
        marker === 0xc2 ||
        marker === 0xc3 ||
        marker === 0xc5 ||
        marker === 0xc6 ||
        marker === 0xc7 ||
        marker === 0xc9 ||
        marker === 0xca ||
        marker === 0xcb ||
        marker === 0xcd ||
        marker === 0xce ||
        marker === 0xcf
      ) {
        const height = buf.readUInt16BE(i + 5);
        const width = buf.readUInt16BE(i + 7);
        return width && height ? { width, height } : undefined;
      }
      i += 2 + len;
    }
  }
  return undefined;
}

// Download image from URL
async function downloadImage(
  url: string
): Promise<{ buffer: Buffer; contentType: string; extension: string } | null> {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      console.warn(`Failed to fetch image from ${url}: ${response.status}`);
      return null;
    }

    const arrayBuf = await response.arrayBuffer();
    const contentType = response.headers.get("content-type");

    if (isWebP(contentType, url)) {
      console.warn(`WebP image not supported: ${url}`);
      return null;
    }

    const extension = guessImageExtension(contentType, url);
    const buffer = Buffer.from(arrayBuf);

    return { buffer, contentType: contentType || "", extension };
  } catch (error) {
    console.warn(`Error downloading image from ${url}:`, error);
    return null;
  }
}

// Create image XML for table cell
function createImageXml(
  imageRelId: string,
  imageWidthEmu: number,
  imageHeightEmu: number,
  imageName: string = "table-image"
): string {
  return `
    <w:r>
      <w:drawing>
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
          <wp:docPr id="1" name="${imageName}"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr>
                  <pic:cNvPr id="0" name="${imageName}"/>
                  <pic:cNvPicPr/>
                </pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="${imageRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm>
                    <a:off x="0" y="0"/>
                    <a:ext cx="${imageWidthEmu}" cy="${imageHeightEmu}"/>
                  </a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>
      </w:drawing>
    </w:r>`;
}

// Build Workflow History Table
export function buildWorkflowHistoryTable(
  data: WorkflowHistoryRow[],
  imageData?: Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >,
  language?: string
): string {
  if (!data || data.length === 0) return "";

  const headers = [
    getDocumentSummaryTranslation("action", language),
    getDocumentSummaryTranslation("user", language),
    getDocumentSummaryTranslation("dateAndTime", language),
    getDocumentSummaryTranslation("signature", language),
  ];
  const columnWidths = [2500, 2500, 2500, 1500]; // Total: 9000 twips

  const headerRow = createTableRow(
    headers.map((header, index) =>
      createTableCell(header, columnWidths[index]!, "center", true)
    )
  );

  const dataRows = data
    .map((row, rowIndex) => {
      const cells = [
        createTableCell(formatSummaryAction(row.Action || ""), columnWidths[0]!),
        createTableCell(row.User || "", columnWidths[1]!),
        createTableCell(row["Date and time"] || "", columnWidths[2]!),
      ];

      // Handle signature cell - either text or image
      const sigUrl =
        row.imageUrl || looksLikeHttpUrl(row.Signature) || undefined;
      if (sigUrl && imageData?.has(sigUrl)) {
        const imgData = imageData.get(sigUrl)!;
        const imageXml = createImageXml(
          imgData.relId,
          imgData.widthEmu,
          imgData.heightEmu,
          `workflow-signature-${rowIndex}`
        );
        cells.push(
          createTableCell("", columnWidths[3]!, "center", false, imageXml)
        );
      } else {
        cells.push(createTableCell(row.Signature || "", columnWidths[3]!));
      }

      return createTableRow(cells);
    })
    .join("");

  return `
    <w:p>
      <w:pPr><w:jc w:val="left"/></w:pPr>
      <w:r>${summaryRunPr({ sz: "24", bold: true })}<w:t xml:space="preserve">${getDocumentSummaryTranslation(
        "workflowHistory",
        language
      )}</w:t></w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9000" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${getTableBorders()}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="2500"/>
        <w:gridCol w:w="2500"/>
        <w:gridCol w:w="2500"/>
        <w:gridCol w:w="1500"/>
      </w:tblGrid>
      ${headerRow}
      ${dataRows}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="240"/>
      </w:pPr>
    </w:p>`;
}

// Build Version Log Table
export function buildVersionLogTable(
  data: VersionLogRow[],
  imageData?: Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >,
  language?: string
): string {
  if (!data || data.length === 0) return "";

  const headers = [
    getDocumentSummaryTranslation("version", language),
    getDocumentSummaryTranslation("changeLogDescription", language),
    getDocumentSummaryTranslation("createdBy", language),
    getDocumentSummaryTranslation("createdOn", language),
  ];
  const columnWidths = [1500, 3500, 2500, 1500]; // Total: 9000 twips

  const headerRow = createTableRow(
    headers.map((header, index) =>
      createTableCell(header, columnWidths[index]!, "center", true)
    )
  );

  const dataRows = data
    .map((row, rowIndex) => {
      const cells = [
        createTableCell(row.Version || "", columnWidths[0]!),
        createTableCell(row["Change Log Description"] || "", columnWidths[1]!),
        createTableCell(row["Created by"] || "", columnWidths[2]!),
      ];

      // Handle "Created On" cell - either text or image
      const createdUrl =
        row.imageUrl || looksLikeHttpUrl(row["Created On"]) || undefined;
      if (createdUrl && imageData?.has(createdUrl)) {
        const imgData = imageData.get(createdUrl)!;
        const imageXml = createImageXml(
          imgData.relId,
          imgData.widthEmu,
          imgData.heightEmu,
          `version-created-${rowIndex}`
        );
        cells.push(
          createTableCell("", columnWidths[3]!, "center", false, imageXml)
        );
      } else {
        cells.push(createTableCell(row["Created On"] || "", columnWidths[3]!));
      }

      return createTableRow(cells);
    })
    .join("");

  return `
    <w:p>
      <w:pPr><w:jc w:val="left"/></w:pPr>
      <w:r>${summaryRunPr({ sz: "24", bold: true })}<w:t xml:space="preserve">${getDocumentSummaryTranslation(
        "versionLog",
        language
      )}</w:t></w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9000" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${getTableBorders()}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="1500"/>
        <w:gridCol w:w="3500"/>
        <w:gridCol w:w="2500"/>
        <w:gridCol w:w="1500"/>
      </w:tblGrid>
      ${headerRow}
      ${dataRows}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="240"/>
      </w:pPr>
    </w:p>`;
}

// Build Document Review Table
export function buildDocumentReviewTable(
  data: DocumentReviewRow[],
  imageData?: Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >,
  language?: string
): string {
  if (!data || data.length === 0) return "";

  const headers = [
    getDocumentSummaryTranslation("action", language),
    getDocumentSummaryTranslation("reviewComments", language),
    getDocumentSummaryTranslation("dateTimePeriodic", language),
    getDocumentSummaryTranslation("reviewedBy", language),
    getDocumentSummaryTranslation("signature", language),
  ];
  const columnWidths = [1800, 3000, 1800, 1800, 1200]; // Total: 9600 twips

  const headerRow = createTableRow(
    headers.map((header, index) =>
      createTableCell(header, columnWidths[index]!, "center", true)
    )
  );

  const dataRows = data
    .map((row, rowIndex) => {
      const cells = [
        createTableCell(formatSummaryAction(row.Action || ""), columnWidths[0]!),
        createTableCell(row["Review comments"] || "", columnWidths[1]!),
        createTableCell(row["Date time periodic"] || "", columnWidths[2]!),
        createTableCell(row["Reviewed by"] || "", columnWidths[3]!),
      ];

      // Handle signature cell - either text or image
      const sigUrl =
        row.imageUrl || looksLikeHttpUrl(row.Signature) || undefined;
      if (sigUrl && imageData?.has(sigUrl)) {
        const imgData = imageData.get(sigUrl)!;
        const imageXml = createImageXml(
          imgData.relId,
          imgData.widthEmu,
          imgData.heightEmu,
          `review-signature-${rowIndex}`
        );
        cells.push(
          createTableCell("", columnWidths[4]!, "center", false, imageXml)
        );
      } else {
        cells.push(createTableCell(row.Signature || "", columnWidths[4]!));
      }

      return createTableRow(cells);
    })
    .join("");

  return `
    <w:p>
      <w:pPr><w:jc w:val="left"/></w:pPr>
      <w:r>${summaryRunPr({ sz: "24", bold: true })}<w:t xml:space="preserve">${getDocumentSummaryTranslation(
        "documentReview",
        language
      )}</w:t></w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:spacing w:after="120"/>
      </w:pPr>
    </w:p>
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9600" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${getTableBorders()}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="1800"/>
        <w:gridCol w:w="3000"/>
        <w:gridCol w:w="1800"/>
        <w:gridCol w:w="1800"/>
        <w:gridCol w:w="1200"/>
      </w:tblGrid>
      ${headerRow}
      ${dataRows}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="240"/>
      </w:pPr>
    </w:p>`;
}

// Build the single, version-grouped summary table (Version / Action Type / Action /
// Performed By / Signature / Comments). Version and Action Type columns are vertically
// merged across consecutive rows that share the same value (within a version block for
// Action Type).
function isVersionMergeStart(
  data: VersionSummaryRow[],
  rowIndex: number
): boolean {
  const prev = rowIndex > 0 ? data[rowIndex - 1] : undefined;
  return !prev || prev.Version !== data[rowIndex]!.Version;
}

function isActionTypeMergeStart(
  data: VersionSummaryRow[],
  rowIndex: number
): boolean {
  const row = data[rowIndex]!;
  const prev = rowIndex > 0 ? data[rowIndex - 1] : undefined;
  if (!prev) return true;
  if (prev.Version !== row.Version) return true;
  return (prev["Action Type"] || "") !== (row["Action Type"] || "");
}

export function buildVersionSummaryTable(
  data: VersionSummaryRow[],
  imageData?: Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >,
  language?: string
): string {
  if (!data || data.length === 0) return "";

  const headers = [
    getDocumentSummaryTranslation("version", language),
    getDocumentSummaryTranslation("actionType", language),
    getDocumentSummaryTranslation("action", language),
    getDocumentSummaryTranslation("performedBy", language),
    getDocumentSummaryTranslation("signature", language),
    getDocumentSummaryTranslation("comments", language),
  ];
  const columnWidths = [700, 1300, 1700, 2100, 1200, 2600]; // Total: 9600 twips

  const headerRow = createTableRow(
    headers.map((header, index) =>
      createTableCell(header, columnWidths[index]!, "center", true)
    )
  );

  const dataRows = data
    .map((row, rowIndex) => {
      const isVersionStart = isVersionMergeStart(data, rowIndex);
      const isActionTypeStart = isActionTypeMergeStart(data, rowIndex);

      const cells: string[] = [
        createVMergeCell(row.Version || "", columnWidths[0]!, isVersionStart),
        createVMergeCell(
          formatSummaryAction(row["Action Type"] || ""),
          columnWidths[1]!,
          isActionTypeStart
        ),
        createTableCell(
          formatSummaryAction(row.Action || ""),
          columnWidths[2]!,
          "center"
        ),
        createStackedCell(
          row["Performed By"] || "",
          row["Performed Date"] || "",
          columnWidths[3]!
        ),
      ];

      const sigUrl =
        row.imageUrl || looksLikeHttpUrl(row.Signature) || undefined;
      if (sigUrl && imageData?.has(sigUrl)) {
        const imgData = imageData.get(sigUrl)!;
        const imageXml = createImageXml(
          imgData.relId,
          imgData.widthEmu,
          imgData.heightEmu,
          `version-summary-signature-${rowIndex}`
        );
        cells.push(
          createTableCell("", columnWidths[4]!, "center", false, imageXml)
        );
      } else {
        cells.push(createTableCell(row.Signature || "", columnWidths[4]!, "center"));
      }

      const commentsDetail = row["Comments Detail"] || "";
      if (commentsDetail) {
        cells.push(
          createCommentsCell(row.Comments || "", commentsDetail, columnWidths[5]!)
        );
      } else {
        cells.push(createCommentsCell(row.Comments || "", "", columnWidths[5]!));
      }

      return createTableRow(cells);
    })
    .join("");

  return `
    <w:tbl>
      <w:tblPr>
        <w:tblW w:w="9600" w:type="dxa"/>
        <w:jc w:val="center"/>
        ${getTableBorders()}
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="700"/>
        <w:gridCol w:w="1300"/>
        <w:gridCol w:w="1700"/>
        <w:gridCol w:w="2100"/>
        <w:gridCol w:w="1200"/>
        <w:gridCol w:w="2600"/>
      </w:tblGrid>
      ${headerRow}
      ${dataRows}
    </w:tbl>
    <w:p>
      <w:pPr>
        <w:spacing w:after="240"/>
      </w:pPr>
    </w:p>`;
}

// Main function to build all document summary tables
export function buildDocumentSummaryTables(
  data: DocumentSummaryData,
  imageData?: Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >,
  language?: string
): string {
  const tables = [];

  // New single, version-grouped summary table. When present it fully replaces the
  // legacy Workflow History / Version Log / Document Review tables.
  if (data.versionSummary && data.versionSummary.length > 0) {
    tables.push(
      buildVersionSummaryTable(data.versionSummary, imageData, language)
    );
    return tables.join("");
  }

  if (data.workflowHistory && data.workflowHistory.length > 0) {
    tables.push(
      buildWorkflowHistoryTable(data.workflowHistory, imageData, language)
    );
  }

  if (data.versionLog && data.versionLog.length > 0) {
    tables.push(buildVersionLogTable(data.versionLog, imageData, language));
  }

  if (data.documentReview && data.documentReview.length > 0) {
    tables.push(
      buildDocumentReviewTable(data.documentReview, imageData, language)
    );
  }

  // Add spacing between tables
  const spacing = `
    <w:p>
      <w:pPr>
        <w:spacing w:after="240" w:before="120"/>
      </w:pPr>
    </w:p>`;

  return tables.join(spacing);
}

// Function to add document summary pages to existing document
export async function addDocumentSummaryToDocument(
  documentXml: string,
  summaryData: DocumentSummaryData,
  zip: any, // JSZip instance
  nextRelId: () => string,
  language?: string
): Promise<string> {
  // Collect all unique image URLs from the data
  const imageUrls = new Set<string>();

  if (summaryData.workflowHistory) {
    summaryData.workflowHistory.forEach((row) => {
      if (row.imageUrl) imageUrls.add(row.imageUrl);
      const sigUrl = looksLikeHttpUrl(row.Signature);
      if (sigUrl) imageUrls.add(sigUrl);
    });
  }

  if (summaryData.versionLog) {
    summaryData.versionLog.forEach((row) => {
      if (row.imageUrl) imageUrls.add(row.imageUrl);
      const createdUrl = looksLikeHttpUrl(row["Created On"]);
      if (createdUrl) imageUrls.add(createdUrl);
    });
  }

  if (summaryData.documentReview) {
    summaryData.documentReview.forEach((row) => {
      if (row.imageUrl) imageUrls.add(row.imageUrl);
      const sigUrl = looksLikeHttpUrl(row.Signature);
      if (sigUrl) imageUrls.add(sigUrl);
    });
  }

  if (summaryData.versionSummary) {
    summaryData.versionSummary.forEach((row) => {
      if (row.imageUrl) imageUrls.add(row.imageUrl);
      const sigUrl = looksLikeHttpUrl(row.Signature);
      if (sigUrl) imageUrls.add(sigUrl);
    });
  }

  // Process images and create image data map
  const imageData = new Map<
    string,
    { relId: string; widthEmu: number; heightEmu: number }
  >();
  const defaultImageWidthInch =
    summaryData.imageWidthInch || SIGNATURE_MAX_WIDTH_INCH;
  const defaultImageHeightInch =
    summaryData.imageHeightInch || SIGNATURE_MAX_HEIGHT_INCH;

  for (const imageUrl of imageUrls) {
    try {
      const imageResult = await downloadImage(imageUrl);
      if (imageResult) {
        const { buffer, extension } = imageResult;

        const dims = getImageDimensions(buffer);
        const { widthEmu, heightEmu } = fitSignatureDimensionsEmu(
          dims,
          defaultImageWidthInch,
          defaultImageHeightInch
        );

        // Generate unique filename and relationship ID
        const imageFileName = `summary-image-${Date.now()}-${Math.random()
          .toString(36)
          .substr(2, 9)}.${extension}`;
        const imagePath = `word/media/${imageFileName}`;
        const relId = nextRelId();

        // Add image to ZIP
        zip.file(imagePath, buffer);

        // Store image data
        imageData.set(imageUrl, {
          relId,
          widthEmu,
          heightEmu,
        });

        // Add relationship to document.xml.rels
        const relsPath = "word/_rels/document.xml.rels";
        let relsXml = await zip.file(relsPath)!.async("text");
        const relationship = `  <Relationship Id="${relId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${imageFileName}"/>\n`;
        relsXml = relsXml.replace(
          "</Relationships>",
          relationship + "</Relationships>"
        );
        zip.file(relsPath, relsXml);

        // Add content type for image
        const ctPath = "[Content_Types].xml";
        let ctXml = await zip.file(ctPath)!.async("text");
        const contentType =
          extension === "jpg" || extension === "jpeg"
            ? "image/jpeg"
            : extension === "png"
            ? "image/png"
            : extension === "gif"
            ? "image/gif"
            : "image/png";

        if (!ctXml.includes(`PartName="/word/media/${imageFileName}"`)) {
          const override = `  <Override PartName="/word/media/${imageFileName}" ContentType="${contentType}"/>\n`;
          ctXml = ctXml.replace("</Types>", override + "</Types>");
          zip.file(ctPath, ctXml);
        }
      }
    } catch (error) {
      console.warn(`Failed to process image ${imageUrl}:`, error);
    }
  }

  // Build tables with image data
  const summaryTables = buildDocumentSummaryTables(
    summaryData,
    imageData,
    language
  );

  if (!summaryTables) {
    return documentXml;
  }

  // Add page break before summary
  const pageBreak = `
    <w:p>
      <w:pPr>
        <w:pageBreakBefore/>
      </w:pPr>
    </w:p>`;

  // Add summary content
  const summaryContent = `
    <w:p>
      <w:pPr><w:jc w:val="center"/></w:pPr>
      <w:r>${summaryRunPr({ sz: "32", bold: true })}<w:t xml:space="preserve">${getDocumentSummaryTranslation(
        "title",
        language
      )}</w:t></w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
        <w:spacing w:after="360"/>
      </w:pPr>
    </w:p>
    ${summaryTables}`;

  // Insert before the closing </w:body> tag
  return documentXml.replace(
    /<\/w:body>/,
    pageBreak + summaryContent + "\n  </w:body>"
  );
}

// Helper function to create a simple nextRelId function
export function createNextRelId(relsXml: string) {
  const ids = Array.from(relsXml.matchAll(/Id="rId(\d+)"/g)).map((m) =>
    parseInt(m[1]!, 10)
  );
  const max = ids.length ? Math.max(...ids) : 0;
  let currentId = max;

  return () => {
    currentId++;
    return `rId${currentId}`;
  };
}
