import type { RequestHandler } from "express";
import { uploadMemory } from "./uploadDoc";
import { execFile } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

function isCsv(filename: string, mimetype?: string): boolean {
  return (
    /\.csv$/i.test(filename) || (mimetype ? /text\/csv/i.test(mimetype) : false)
  );
}

function isXls(filename: string, mimetype?: string): boolean {
  return (
    /\.xls$/i.test(filename) ||
    (mimetype ? /application\/(vnd\.ms-excel|excel)/i.test(mimetype) : false)
  );
}

function isXlsm(filename: string, mimetype?: string): boolean {
  return (
    /\.xlsm$/i.test(filename) ||
    (mimetype
      ? /application\/vnd\.ms-excel\.sheet\.macroEnabled\.12/i.test(mimetype)
      : false)
  );
}

export const csvXlsToXlsxHandler: RequestHandler = async (req, res) => {
  try {
    console.log("[CSVXLS2XLSX] Starting processing request");
    if (!req.file) {
      return res
        .status(400)
        .json({ error: "No file uploaded (field name 'file')" });
    }

    const originalName = req.file.originalname || "input";
    const mimetype = req.file.mimetype;

    if (
      !isCsv(originalName, mimetype) &&
      !isXls(originalName, mimetype) &&
      !isXlsm(originalName, mimetype)
    ) {
      return res
        .status(400)
        .json({ error: "Only .csv, .xls or .xlsm files are supported" });
    }

    const tempBaseDir = path.join(os.tmpdir(), "docs-attacher");
    try {
      fs.mkdirSync(tempBaseDir, { recursive: true });
    } catch {}

    const ts = Date.now();
    const sourceExt = (
      /\.(csv|xls|xlsm)$/i.exec(originalName)?.[1] || "csv"
    ).toLowerCase();
    const tempInPath = path.join(tempBaseDir, `upload_${ts}.${sourceExt}`);
    const tempOutPath = path.join(tempBaseDir, `upload_${ts}.xlsx`);
    const pythonScriptPath = path.join(tempBaseDir, `convert_${ts}.py`);

    fs.writeFileSync(tempInPath, req.file.buffer);

    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_to_xlsx_libreoffice(in_path, out_path):
    try:
        paths = []
        override = os.environ.get("LIBREOFFICE_PATH")
        if override:
            paths.append(override)
        paths.extend([
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ])

        libreoffice_exe = None
        for p in paths:
            if os.path.exists(p):
                libreoffice_exe = p
                break
            elif p in ["soffice", "libreoffice"]:
                try:
                    r = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        libreoffice_exe = p
                        break
                except:
                    continue

        if not libreoffice_exe:
            raise Exception("LibreOffice not found")

        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/f', '/im', 'soffice.exe'], capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill', '/f', '/im', 'soffice.bin'], capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill', '-f', 'soffice'], capture_output=True, check=False, timeout=5)
        except:
            pass

        time.sleep(1)

        output_dir = os.path.dirname(out_path)
        os.makedirs(output_dir, exist_ok=True)

        cmd = [
            libreoffice_exe,
            "--headless",
            "--invisible",
            "--nodefault",
            "--nolockcheck",
            "--nologo",
            "--norestore",
            "--safe-mode",
            "--convert-to", "xlsx",
            "--outdir", output_dir,
            in_path
        ]

        env = os.environ.copy()
        env['SAL_USE_VCLPLUGIN'] = 'svp'
        env['DISPLAY'] = ':0.0'

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env)
        if result.returncode != 0:
            msg = f"LibreOffice conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                msg += f": {result.stderr.strip()}"
            raise Exception(msg)

        time.sleep(0.5)

        # LibreOffice writes file with same base name and .xlsx into outdir
        base = os.path.splitext(os.path.basename(in_path))[0]
        produced = os.path.join(output_dir, base + ".xlsx")
        if not os.path.exists(produced):
            # fallback to expected out_path if directly created
            if not os.path.exists(out_path):
                raise Exception("Converted XLSX file not found")
            produced = out_path

        # Move/rename to desired out_path
        try:
            if produced != out_path:
                if os.path.exists(out_path):
                    os.remove(out_path)
                os.replace(produced, out_path)
        except Exception as e:
            if not os.path.exists(out_path):
                raise e

        print("SUCCESS")

    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    in_path = "${tempInPath.replace(/\\/g, "\\\\")}"
    out_path = "${tempOutPath.replace(/\\/g, "\\\\")}"
    convert_to_xlsx_libreoffice(in_path, out_path)
`;

    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      const pythonCmd = process.platform === "win32" ? "python" : "python3";
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000,
          maxBuffer: 50 * 1024 * 1024,
        },
      );

      if (stdout?.trim())
        console.log(`[CSVXLS2XLSX] python stdout: ${stdout.substring(0, 500)}`);
      if (stderr?.trim())
        console.warn(
          `[CSVXLS2XLSX] python stderr: ${stderr.substring(0, 500)}`,
        );

      if (!stdout.includes("SUCCESS")) {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }

      if (!fs.existsSync(tempOutPath)) {
        throw new Error("Converted XLSX file not found");
      }

      const outBuffer = fs.readFileSync(tempOutPath);
      const downloadName =
        originalName.replace(/\.(csv|xls|xlsm)$/i, "") + ".xlsx";
      res.setHeader(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      );
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${downloadName}"`,
      );
      return res.status(200).send(outBuffer);
    } finally {
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}
      try {
        fs.unlinkSync(tempInPath);
      } catch {}
      try {
        fs.unlinkSync(tempOutPath);
      } catch {}
    }
  } catch (err: any) {
    console.error("/convert-to-xlsx error", err);
    return res.status(500).json({ error: String(err?.message || err) });
  }
};

export const uploadCsvXls = uploadMemory;

export default csvXlsToXlsxHandler;
