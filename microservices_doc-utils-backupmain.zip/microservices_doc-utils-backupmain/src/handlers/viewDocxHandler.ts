import type { RequestHandler } from "express";
import * as path from "path";
import * as fs from "fs";
import { utimesSync } from "fs";
import { handleDocxAttach, handleDocConversion } from "./docxHandler";
import { createPayloadHash } from "../utils/payloadHash";

// Helper function to get file extension
function getFileExtension(filePath: string): string {
  const match = /\.([^.?#/]+)(?:$|[?#])/i.exec(filePath || "");
  return (match?.[1] || "").toLowerCase();
}

export const handleViewDocx: RequestHandler = async (req, res) => {
  console.log("[VIEWDOCX] Starting processing request");
  try {
    // Get file extension from s3Path or filename
    const s3Path = (req.body as any)?.s3Path || "";
    const requestFilename = (req.body as any)?.filename || "";
    const fileExt = getFileExtension(s3Path || requestFilename);

    // Create output directory if it doesn't exist
    const outputDir = path.join(process.cwd(), "public", "files");
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    // Generate hash from payload (excluding time fields)
    const payloadHash = createPayloadHash(
      req.body,
      fileExt === "doc" ? "docx" : "docx",
    );
    // Always derive baseFilename from the last segment of s3Path (e.g. UUID)
    // to avoid issues with frontend-provided names like "# document"
    const s3LastSegment = s3Path
      .split("/")
      .pop()
      ?.replace(/\.docx?$/i, "") || "";
    const baseFilename =
      s3LastSegment ||
      requestFilename?.replace(/\.docx?$/i, "") ||
      "document";
    const finalFilename = `${baseFilename}_${payloadHash}.docx`;
    const filePath = path.join(outputDir, finalFilename);

    // Check if file already exists (cached)
    if (fs.existsSync(filePath)) {
      console.log(`[VIEWDOCX] Using cached file: ${finalFilename}`);

      // Reset expiration timer by updating file modification time
      // This ensures the file won't be deleted by the streamer when accessed
      try {
        const now = new Date();
        utimesSync(filePath, now, now);
      } catch (utimesErr) {
        console.warn(
          `[VIEWDOCX] Failed to update file times for ${finalFilename}:`,
          utimesErr,
        );
      }

      const protocol = req.get("x-forwarded-proto") || req.protocol || "http";
      const host =
        req.get("x-forwarded-host") ||
        req.get("host") ||
        `${req.socket.remoteAddress}:${process.env.PORT || 4040}`;
      const publicPath = `/files/${finalFilename}`;
      const fullUrl = `${protocol}://${host}${publicPath}`;

      return res.json({
        filePath: publicPath,
        fullUrl: fullUrl,
        filename: finalFilename,
        cached: true,
      });
    }

    // Ensure shouldPrint is false for file saving
    const modifiedReq = {
      ...req,
      body: {
        ...req.body,
        shouldPrint: false,
      },
    } as any;

    // Create a mock response object to capture the result
    let capturedResult: any = null;
    const mockRes = {
      json: (data: any) => {
        capturedResult = data;
        return mockRes;
      },
      status: (code: number) => {
        return {
          json: (data: any) => {
            capturedResult = { error: data.error || data };
            return mockRes;
          },
        };
      },
    } as any;

    // Route to appropriate handler based on file extension
    // If DOC file, use handleDocConversion (converts DOC to DOCX)
    // Otherwise, use handleDocxAttach (for DOCX files)
    if (fileExt === "doc") {
      console.log(
        "[VIEWDOCX] Detected DOC file, routing to handleDocConversion",
      );
      await handleDocConversion(modifiedReq, mockRes, () => {});
    } else {
      console.log("[VIEWDOCX] Detected DOCX file, routing to handleDocxAttach");
      await handleDocxAttach(modifiedReq, mockRes, () => {});
    }

    if (capturedResult?.error) {
      return res.status(500).json(capturedResult);
    }

    // Extract base64 from the result
    const fileBase64 = capturedResult?.fileBase64;
    if (!fileBase64) {
      return res.status(500).json({ error: "Failed to generate file" });
    }

    // Decode base64 and write to file (using hash-based filename)
    console.log(`[VIEWDOCX] Saving new file: ${finalFilename}`);
    const fileBuffer = Buffer.from(fileBase64, "base64");
    fs.writeFileSync(filePath, fileBuffer);

    // Build the full URL for Office Online
    // Support VM/proxy environments with X-Forwarded headers
    const protocol = req.get("x-forwarded-proto") || req.protocol || "http";
    const host =
      req.get("x-forwarded-host") ||
      req.get("host") ||
      `${req.socket.remoteAddress}:${process.env.PORT || 4040}`;
    const publicPath = `/files/${finalFilename}`;
    const fullUrl = `${protocol}://${host}${publicPath}`;

    return res.json({
      filePath: publicPath,
      fullUrl: fullUrl,
      filename: finalFilename,
      warning: capturedResult?.warning,
      cached: false,
    });
  } catch (err: any) {
    console.error("[handleViewDocx] Error:", err);
    return res.status(500).json({ error: String(err.message || err) });
  }
};
