// Minimal ambient types to satisfy TS when @types/multer cannot be installed
declare module "multer" {
  import { RequestHandler } from "express";
  type StorageEngine = any;
  interface MulterOptions {
    storage?: StorageEngine;
  }
  interface MulterInstance {
    single(field: string): RequestHandler;
  }
  interface MulterExport {
    (options?: MulterOptions): MulterInstance;
    memoryStorage(): StorageEngine;
  }
  const multer: MulterExport;
  export = multer;
}

declare namespace Express {
  interface Request {
    file?: {
      buffer: Buffer;
      originalname?: string;
      mimetype?: string;
    };
  }
}
