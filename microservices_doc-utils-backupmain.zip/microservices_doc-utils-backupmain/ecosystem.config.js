require("dotenv").config();

module.exports = {
  apps: [
    {
      name: process.env.APP_NAME || "attacher-service",
      script: "npm",
      args: "run dev",
      // Main server starts once and keeps running

      env: {
        NODE_ENV: process.env.NODE_ENV || "development",
      },
    },
    {
      name: (process.env.APP_NAME || "attacher-service") + "-cron",
      script: "node",
      args: "./cleanupFiles.js",
      /**
       * =========================
       * Cleanup Cron Job
       * =========================
       * Runs cleanupFiles.js DAILY at 2 AM
       * This is a separate process that only runs the cleanup script
       * Main server continues running without interruption
       */
      cron_restart: "0 2 * * *",
      autorestart: false, // Don't restart if script exits successfully
      watch: false, // Don't watch for file changes

      env: {
        CLEANUP_DURATION_HOURS: process.env.CLEANUP_DURATION_HOURS || "24",
        NODE_ENV: process.env.NODE_ENV || "development",
      },
    },
  ],
};
