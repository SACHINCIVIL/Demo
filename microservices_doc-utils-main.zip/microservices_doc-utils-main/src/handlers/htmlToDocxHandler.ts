import type { RequestHandler } from "express";
import JSZip from "jszip";
import AWS from "aws-sdk";
import { execFile } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { promisify } from "util";
import {
  addDocumentSummaryToDocument,
  DocumentSummaryData,
  createNextRelId,
} from "./documentSummary";
import {
  formatDatesInDocumentSummary,
  formatDatesInObject,
} from "../utils/dateFormat";
import {
  buildWatermarkImageParagraph,
  buildWatermarkParagraph,
} from "./docxShared";
import {
  extractWatermarkFromHeaderXml,
  findAllPartsFromRels,
  findPartFromRels,
  findPreservedWatermarkSnapshot,
  headerHasWatermark,
  headerRelsPartPath,
  injectWatermarkIntoHeaderXml,
  isWatermarkOverrideRequested,
  listHeaderPartPaths,
  mergeHeaderRelationshipsXml,
  nextHeaderPartRelId,
  removeDocumentBackgroundWatermark,
  removeWatermarkFromHeaderXml,
  shouldPreserveWatermark,
  type HeaderPartSnapshot,
  watermarkUsesImageRelationships,
} from "./docxPreserve";

import * as header1 from "./headers/header1";
import * as header2 from "./headers/header2";
import * as header3 from "./headers/header3";
import * as header4 from "./headers/header4";
import * as header5 from "./headers/header5";
import * as header6 from "./headers/header6";
import * as footer1 from "./footers/footer1";
import * as footer2 from "./footers/footer2";
import * as footer3 from "./footers/footer3";
import * as footer4 from "./footers/footer4";
import * as footer5 from "./footers/footer5";

const HEADER_LAYOUTS: Record<string, typeof header1> = {
  header1,
  header2,
  header3,
  header4,
  header5,
  header6,
};
const FOOTER_LAYOUTS: Record<string, typeof footer1> = {
  footer1,
  footer2,
  footer3,
  footer4,
  footer5,
};

const execFileAsync = promisify(execFile);
const EMU_PER_INCH = 914400; // 1 inch = 914400 EMUs
const TWIPS_PER_INCH = 1440;

// Copy necessary functions from docxHandler.ts
type WatermarkOptions = {
  text: string;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  opacity?: number;
  diagonal?: boolean;
  angleDegrees?: number;
  direction?: "up" | "down";
  position?: "horizontal" | "diagonal";
};

type WatermarkImageOptions = {
  imageBuffer: Buffer;
  imageExtension: string;
  opacity?: number;
  position?: "horizontal" | "diagonal";
  widthInch?: number;
  heightInch?: number;
  aspectRatio?: number;
};

function clampOpacity(opacity?: number) {
  if (typeof opacity !== "number" || Number.isNaN(opacity)) return 0.5;
  if (opacity < 0) return 0;
  if (opacity > 1) return 1;
  return Math.round(opacity * 100) / 100;
}

function parseBoolean(value: any): boolean | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const lower = value.trim().toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
  }
  return undefined;
}

function getWatermarkOptions(payload: any): WatermarkOptions | undefined {
  if (!payload) return undefined;
  if (parseBoolean((payload as any)?.watermarkEnabled) === false) {
    return undefined;
  }
  const text =
    typeof payload.watermarkText === "string"
      ? payload.watermarkText.trim()
      : "";
  if (!text) return undefined;
  const maybeOpacity =
    payload.watermarkOpacity != null
      ? Number(payload.watermarkOpacity)
      : undefined;
  const maybeFontSize =
    payload.watermarkFontSize != null
      ? Number(payload.watermarkFontSize)
      : undefined;
  const diagonal = parseBoolean(payload.watermarkDiagonal);
  const angle =
    payload.watermarkAngle != null ? Number(payload.watermarkAngle) : undefined;
  const direction =
    typeof payload.watermarkDirection === "string"
      ? (payload.watermarkDirection.toLowerCase() as "up" | "down")
      : undefined;
  const positionRaw =
    typeof payload.watermarkPosition === "string"
      ? payload.watermarkPosition.toLowerCase()
      : undefined;
  const position: "horizontal" | "diagonal" | undefined =
    positionRaw === "horizontal"
      ? "horizontal"
      : positionRaw === "diagonal"
        ? "diagonal"
        : undefined;
  return {
    text,
    fontFamily:
      typeof payload.watermarkFontFamily === "string"
        ? payload.watermarkFontFamily
        : undefined,
    color:
      typeof payload.watermarkColor === "string"
        ? payload.watermarkColor
        : undefined,
    opacity: maybeOpacity,
    fontSize: maybeFontSize,
    diagonal,
    angleDegrees: Number.isFinite(angle) ? (angle as number) : undefined,
    direction:
      direction === "up" || direction === "down" ? direction : undefined,
    position,
  };
}

function isWebP(contentType: string | null, url: string) {
  return !!(contentType?.includes("image/webp") || /\.webp$/i.test(url));
}

function guessImageExtension(contentType: string | null, url: string) {
  if (contentType?.includes("png") || url.toLowerCase().endsWith(".png"))
    return "png";
  if (
    contentType?.includes("jpeg") ||
    contentType?.includes("jpg") ||
    /\.jpe?g$/i.test(url)
  )
    return "jpg";
  if (contentType?.includes("gif") || /\.gif$/i.test(url)) return "gif";
  return "png";
}

function getImageDimensions(
  buf: Buffer,
): { width: number; height: number } | undefined {
  if (!buf || buf.length < 10) return undefined;
  // PNG
  if (
    buf.length > 24 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47
  ) {
    const width = buf.readUInt32BE(16);
    const height = buf.readUInt32BE(20);
    return width && height ? { width, height } : undefined;
  }
  // GIF
  if (
    buf.length > 10 &&
    buf[0] === 0x47 &&
    buf[1] === 0x49 &&
    buf[2] === 0x46 &&
    buf[3] === 0x38 &&
    (buf[4] === 0x39 || buf[4] === 0x37) &&
    buf[5] === 0x61
  ) {
    const width = buf.readUInt16LE(6);
    const height = buf.readUInt16LE(8);
    return width && height ? { width, height } : undefined;
  }
  // JPEG (scan for SOF marker)
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i + 9 < buf.length) {
      if (buf[i] !== 0xff) {
        i++;
        continue;
      }
      const marker = buf[i + 1];
      const len = buf.readUInt16BE(i + 2);
      if (
        marker === 0xc0 ||
        marker === 0xc1 ||
        marker === 0xc2 ||
        marker === 0xc3 ||
        marker === 0xc5 ||
        marker === 0xc6 ||
        marker === 0xc7 ||
        marker === 0xc9 ||
        marker === 0xca ||
        marker === 0xcb ||
        marker === 0xcd ||
        marker === 0xce ||
        marker === 0xcf
      ) {
        const height = buf.readUInt16BE(i + 5);
        const width = buf.readUInt16BE(i + 7);
        return width && height ? { width, height } : undefined;
      }
      i += 2 + len;
    }
  }
  return undefined;
}

// Convert DOCX base64 to PDF base64 using LibreOffice
async function convertDocxBase64ToPdfBase64(
  docxBase64: string,
): Promise<string> {
  const tempDir = os.tmpdir();
  const tempDocxPath = path.join(tempDir, `docx_${Date.now()}.docx`);
  const tempPdfPath = path.join(tempDir, `docx_${Date.now()}.pdf`);

  try {
    const buffer = Buffer.from(docxBase64, "base64");
    fs.writeFileSync(tempDocxPath, buffer);

    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_docx_to_pdf_libreoffice(docx_path, output_path):
    try:
        libreoffice_paths = [
            r"C:\\Program Files\\LibreOffice\\program\\soffice.exe",
            r"C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe",
            "/usr/bin/libreoffice",
            "/usr/bin/soffice",
            "soffice",
            "libreoffice"
        ]

        libreoffice_exe = None
        for p in libreoffice_paths:
            if os.path.exists(p):
                libreoffice_exe = p
                break
            elif p in ["soffice", "libreoffice"]:
                try:
                    r = subprocess.run([p, "--version"], capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        libreoffice_exe = p
                        break
                except:
                    continue

        if not libreoffice_exe:
            raise Exception("LibreOffice not found")

        try:
            if os.name == 'nt':
                subprocess.run(['taskkill', '/f', '/im', 'soffice.exe'], capture_output=True, check=False, timeout=5)
                subprocess.run(['taskkill', '/f', '/im', 'soffice.bin'], capture_output=True, check=False, timeout=5)
            else:
                subprocess.run(['pkill', '-f', 'soffice'], capture_output=True, check=False, timeout=5)
        except:
            pass

        time.sleep(1)

        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)

        cmd = [
            libreoffice_exe,
            "--headless",
            "--invisible",
            "--nodefault",
            "--nolockcheck",
            "--nologo",
            "--norestore",
            "--safe-mode",
            "--convert-to", "pdf",
            "--outdir", output_dir,
            docx_path
        ]

        env = os.environ.copy()
        env['SAL_USE_VCLPLUGIN'] = 'svp'
        env['DISPLAY'] = ':0.0'

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=90, env=env)
        if result.returncode != 0:
            msg = f"LibreOffice conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                msg += f": {result.stderr.strip()}"
            raise Exception(msg)

        time.sleep(1.0)

        if not os.path.exists(output_path):
            raise Exception("Converted PDF file not found")

        print("SUCCESS")

    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    docx_path = "${tempDocxPath.replace(/\\/g, "\\\\")}"
    output_path = "${tempPdfPath.replace(/\\/g, "\\\\")}"
    convert_docx_to_pdf_libreoffice(docx_path, output_path)
`;

    const pythonScriptPath = path.join(
      tempDir,
      `convert_docx_pdf_${Date.now()}.py`,
    );
    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      const pythonCmd = process.platform === "win32" ? "python" : "python3";
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000,
          maxBuffer: 50 * 1024 * 1024,
        },
      );

      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}

      if (!stdout.includes("SUCCESS")) {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }

      if (!fs.existsSync(tempPdfPath)) {
        throw new Error("Converted PDF file not found");
      }

      const pdfBuffer = fs.readFileSync(tempPdfPath);
      const pdfBase64 = pdfBuffer.toString("base64");

      try {
        fs.unlinkSync(tempDocxPath);
        fs.unlinkSync(tempPdfPath);
      } catch {}

      return pdfBase64;
    } catch (err: any) {
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch {}
      throw err;
    }
  } finally {
    try {
      if (fs.existsSync(tempDocxPath)) fs.unlinkSync(tempDocxPath);
    } catch {}
  }
}

// Additional helper functions needed
function addOverrideIfMissing(
  contentTypesXml: string,
  partPath: string,
  contentType: string,
) {
  if (contentTypesXml.includes(`PartName="${partPath}"`))
    return contentTypesXml;
  const insertBefore = "</Types>";
  const override = `  <Override PartName="${partPath}" ContentType="${contentType}"/>\n`;
  if (contentTypesXml.includes(insertBefore)) {
    return contentTypesXml.replace(insertBefore, override + insertBefore);
  }
  return contentTypesXml + override;
}

function addDefaultIfMissing(
  contentTypesXml: string,
  extension: string,
  contentType: string,
) {
  if (contentTypesXml.includes(`Extension="${extension}"`))
    return contentTypesXml;
  const insertBefore = "</Types>";
  const def = `  <Default Extension="${extension}" ContentType="${contentType}"/>\n`;
  if (contentTypesXml.includes(insertBefore)) {
    return contentTypesXml.replace(insertBefore, def + insertBefore);
  }
  return contentTypesXml + def;
}

function nextRelId(relsXml: string) {
  const ids = Array.from(relsXml.matchAll(/Id="rId(\d+)"/g)).map((m) =>
    parseInt(m[1]!, 10),
  );
  const max = ids.length ? Math.max(...ids) : 0;
  return {
    headerId: `rId${max + 1}`,
    footerId: `rId${max + 2}`,
    settingsId: `rId${max + 3}`,
  } as const;
}

function upsertRelationship(
  relsXml: string,
  id: string,
  type: string,
  target: string,
) {
  if (relsXml.includes(`Id="${id}"`)) return relsXml;
  const insertBefore = "</Relationships>";
  const rel = `  <Relationship Id="${id}" Type="${type}" Target="${target}"/>\n`;
  if (relsXml.includes(insertBefore))
    return relsXml.replace(insertBefore, rel + insertBefore);
  return relsXml + rel;
}

async function snapshotHeaderParts(
  zip: JSZip,
  relsXml: string,
  fallbackHeaderPart: string,
): Promise<HeaderPartSnapshot[]> {
  const paths = listHeaderPartPaths(
    relsXml,
    Object.keys(zip.files),
    fallbackHeaderPart,
  );
  const snapshots: HeaderPartSnapshot[] = [];
  for (const part of paths) {
    const xml = (await zip.file(part)?.async("text")) ?? "";
    if (!xml) continue;
    const relsPart = headerRelsPartPath(part);
    snapshots.push({
      part,
      xml,
      relsXml:
        (await zip.file(relsPart)?.async("text")) ??
        `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n</Relationships>`,
    });
  }
  return snapshots;
}

/**
 * Strip any existing header/footer relationships from document.xml.rels so that
 * re-processing a previously processed document does not accumulate duplicate
 * or conflicting relationship entries (which WOPI edit mode rejects).
 */
function cleanStaleHeaderFooterRels(
  relsXml: string,
  opts?: { stripHeader?: boolean; stripFooter?: boolean },
) {
  let result = relsXml;
  if (opts?.stripHeader !== false) {
    result = result.replace(
      /\s*<Relationship[^>]*Type="[^"]*\/header"[^>]*\/>\r?\n?/g,
      "",
    );
  }
  if (opts?.stripFooter !== false) {
    result = result.replace(
      /\s*<Relationship[^>]*Type="[^"]*\/footer"[^>]*\/>\r?\n?/g,
      "",
    );
  }
  return result;
}

function ensureSectPrWithRefs(
  documentXml: string,
  headerRelId: string | null | undefined,
  footerRelId: string | null | undefined,
  allPages: boolean,
  headerMarginTwips?: number,
  footerMarginTwips?: number,
) {
  let updated = documentXml;
  const preserveHeader = headerRelId === undefined;
  const preserveFooter = footerRelId === undefined;

  const headerRefDefault = headerRelId
    ? `<w:headerReference w:type="default" r:id="${headerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const footerRefDefault = footerRelId
    ? `<w:footerReference w:type="default" r:id="${footerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const headerRefFirst = headerRelId
    ? `<w:headerReference w:type="first" r:id="${headerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";
  const footerRefFirst = footerRelId
    ? `<w:footerReference w:type="first" r:id="${footerRelId}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>`
    : "";

  const titlePg = allPages ? "" : `<w:titlePg/>`;
  const refs = allPages
    ? `${headerRefDefault}${footerRefDefault}`
    : `${headerRefFirst}${footerRefFirst}`;

  // Default margins for WOPI compatibility (1 inch = 1440 twips)
  const defaultLeftMargin = 1440; // 1 inch
  const defaultRightMargin = 1440; // 1 inch
  const defaultTopMargin = 1440; // 1 inch
  const defaultBottomMargin = 1440; // 1 inch

  const updatePgMarHeaderFooter = (pgMarXml: string) => {
    let out = pgMarXml;
    if (headerMarginTwips != null) {
      if (/w:header="\d+"/.test(out)) {
        out = out.replace(/w:header="\d+"/, `w:header="${headerMarginTwips}"`);
      } else {
        out = out.replace(
          /<w:pgMar([^>]*)\/>/, 
          `<w:pgMar$1 w:header="${headerMarginTwips}"/>`,
        );
      }
    }
    if (footerMarginTwips != null) {
      if (/w:footer="\d+"/.test(out)) {
        out = out.replace(/w:footer="\d+"/, `w:footer="${footerMarginTwips}"`);
      } else {
        out = out.replace(
          /<w:pgMar([^>]*)\/>/, 
          `<w:pgMar$1 w:footer="${footerMarginTwips}"/>`,
        );
      }
    }
    return out;
  };

  // No sectPr at all — create one from scratch
  if (!/<w:sectPr[\s\S]*?<\/w:sectPr>/.test(updated)) {
    const pgMar = `<w:pgMar w:left="${defaultLeftMargin}" w:right="${defaultRightMargin}" w:top="${defaultTopMargin}" w:bottom="${defaultBottomMargin}"${
      headerMarginTwips != null ? ` w:header="${headerMarginTwips}"` : ""
    }${footerMarginTwips != null ? ` w:footer="${footerMarginTwips}"` : ""}/>`;
    const sectPr = `<w:sectPr>${titlePg}${refs}${pgMar}</w:sectPr>`;
    updated = updated.replace(/<\/w:body>/, sectPr + "</w:body>");
    return updated;
  }

  // Collect all sectPr matches — only modify the LAST one (body-level).
  // Intermediate sectPr elements belong to section breaks and must not receive
  // header/footer references, otherwise WOPI edit mode rejects the document.
  const sectPrRegex = /<w:sectPr[\s\S]*?<\/w:sectPr>/g;
  const allMatches = [...updated.matchAll(sectPrRegex)];
  if (allMatches.length === 0) return updated;

  const lastMatch = allMatches[allMatches.length - 1]!;
  const lastIndex = lastMatch.index!;
  const lastOriginal = lastMatch[0];

  // Process only the last sectPr
  let block = lastOriginal;

  if (!preserveHeader) {
    block = block.replace(/<w:headerReference[\s\S]*?\/>/g, "");
  }
  if (!preserveFooter) {
    block = block.replace(/<w:footerReference[\s\S]*?\/>/g, "");
  }

  // 2. Remove <w:titlePg/> when allPages is true (headers show on every page)
  if (allPages) {
    block = block.replace(/<w:titlePg\/?>/g, "");
  }

  // 3. Update or insert <w:pgMar> — exactly once
  if (/<w:pgMar[\s\S]*?\/>/.test(block)) {
    block = block.replace(/<w:pgMar[\s\S]*?\/>/, (pgMar) =>
      updatePgMarHeaderFooter(pgMar),
    );
    if (refs) {
      block = block.replace(/<w:sectPr(?:[^>]*)>/, (m) => m + titlePg + refs);
    } else if (!allPages && !preserveHeader && !preserveFooter) {
      block = block.replace(/<w:sectPr(?:[^>]*)>/, (m) => m + titlePg);
    }
  } else {
    // No pgMar — build one and insert refs + pgMar together after the opening tag
    const pgMar = `<w:pgMar w:left="${defaultLeftMargin}" w:right="${defaultRightMargin}" w:top="${defaultTopMargin}" w:bottom="${defaultBottomMargin}"${
      headerMarginTwips != null ? ` w:header="${headerMarginTwips}"` : ""
    }${
      footerMarginTwips != null ? ` w:footer="${footerMarginTwips}"` : ""
    }/>`;
    block = block.replace(
      /<w:sectPr(?:[^>]*)>/,
      (m) => m + titlePg + refs + pgMar,
    );
  }

  // Splice the modified last sectPr back into the document
  updated =
    updated.slice(0, lastIndex) +
    block +
    updated.slice(lastIndex + lastOriginal.length);

  return updated;
}

function buildHeaderRelsXml(imageRelId: string | null, imageTarget: string) {
  const imgRel = imageRelId
    ? `  <Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imageTarget}"/>\n`
    : "";
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${imgRel}</Relationships>`;
}

// Ensure DOCX targets a modern Word compatibility mode and that settings part exists
async function ensureModernCompatibility(zip: JSZip) {
  const settingsPath = "word/settings.xml";
  const relsPath = "word/_rels/document.xml.rels";
  const contentTypesPath = "[Content_Types].xml";

  // 1) Load or create settings.xml
  let settingsXml: string;
  const existing = zip.file(settingsPath);
  if (existing) {
    settingsXml = await existing.async("text");
  } else {
    settingsXml =
      `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n` +
      `<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">\n` +
      `  <w:compat>\n` +
      `    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>\n` +
      `  </w:compat>\n` +
      `</w:settings>`;
    zip.file(settingsPath, settingsXml);
  }

  // 2) Upsert <w:compatSetting w:name="compatibilityMode" w:val="16"/>
  let updated = settingsXml;
  if (!/<w:compat[\s\S]*?<\/w:compat>/.test(updated)) {
    updated = updated.replace(
      /<\/w:settings>/,
      `  <w:compat>\n  </w:compat>\n</w:settings>`,
    );
  }
  if (/<w:compatSetting[^>]*w:name="compatibilityMode"/.test(updated)) {
    updated = updated.replace(
      /(<w:compatSetting[^>]*w:name="compatibilityMode"[^>]*w:val=")\d+("[^>]*\/>)/,
      "$116$2",
    );
  } else {
    updated = updated.replace(
      /<w:compat>/,
      `<w:compat>\n    <w:compatSetting w:name="compatibilityMode" w:val="16" w:uri="http://schemas.microsoft.com/office/word"/>`,
    );
  }
  zip.file(settingsPath, updated);

  // 3) Ensure Content Types has override for settings
  const ctFile = zip.file(contentTypesPath);
  if (ctFile) {
    let ctXml = await ctFile.async("text");
    ctXml = addOverrideIfMissing(
      ctXml,
      "/word/settings.xml",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml",
    );
    zip.file(contentTypesPath, ctXml);
  }

  // 4) Ensure _rels has relationship to settings
  const relsFile = zip.file(relsPath);
  if (relsFile) {
    let relsXml = await relsFile.async("text");
    const hasSettings =
      /Type="http:\/\/schemas.openxmlformats.org\/officeDocument\/2006\/relationships\/settings"/.test(
        relsXml,
      );
    if (!hasSettings) {
      const ids = nextRelId(relsXml);
      relsXml = upsertRelationship(
        relsXml,
        ids.settingsId,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings",
        "settings.xml",
      );
      zip.file(relsPath, relsXml);
    }
  }
}

// Convert HTML to DOCX using Python
async function convertHtmlToDocx(htmlContent: string): Promise<string> {
  const tempDir = os.tmpdir();
  const ts = Date.now();
  const tempHtmlPath = path.join(tempDir, `temp_${ts}.html`);
  const tempDocxPath = path.join(tempDir, `temp_${ts}.docx`);

  try {
    const pythonCmd = process.platform === "win32" ? "python" : "python3";

    // Write HTML content to temp file
    fs.writeFileSync(tempHtmlPath, htmlContent, "utf8");

    // Create Python script for HTML to DOCX conversion
    const pythonScript = `
import os
import sys
import subprocess
import time

def convert_html_to_docx_pandoc(html_path, output_path):
    """Convert HTML to DOCX using pandoc"""
    try:
        # Find pandoc executable - production-friendly paths
        pandoc_paths = [
            'pandoc',  # Try direct command first (if in PATH)
            '/usr/bin/pandoc',  # Linux production
            '/usr/local/bin/pandoc',  # macOS/Linux alternative
            '/opt/pandoc/bin/pandoc',  # Custom installation
            r'C:\\Program Files\\Pandoc\\pandoc.exe',  # Windows default
            r'C:\\Program Files (x86)\\Pandoc\\pandoc.exe',  # Windows 32-bit
            r'C:\\Users\\{}\\AppData\\Local\\Pandoc\\pandoc.exe'.format(os.environ.get('USERNAME', '')),  # Windows user
            r'C:\\Users\\{}\\AppData\\Local\\Pandoc\\pandoc.exe'.format(os.environ.get('USER', '')),  # Windows user alternative
            '/app/pandoc',  # Docker container
            '/usr/local/bin/pandoc',  # Homebrew on macOS
            '/opt/homebrew/bin/pandoc',  # Homebrew on Apple Silicon
        ]
        
        # Check for environment variable override (production deployment)
        pandoc_env_path = os.environ.get('PANDOC_PATH')
        if pandoc_env_path and os.path.exists(pandoc_env_path):
            pandoc_paths.insert(0, pandoc_env_path)
        
        # Also try to find pandoc in PATH
        import shutil
        pandoc_in_path = shutil.which('pandoc')
        if pandoc_in_path:
            pandoc_paths.insert(0, pandoc_in_path)
        
        pandoc_exe = None
        for path in pandoc_paths:
            try:
                if path == 'pandoc':
                    # Try direct command
                    result = subprocess.run([path, '--version'], 
                                          capture_output=True, text=True, timeout=5)
                    if result.returncode == 0:
                        pandoc_exe = path
                        break
                elif os.path.exists(path):
                    # Try full path
                    result = subprocess.run([path, '--version'], 
                                          capture_output=True, text=True, timeout=5)
                    if result.returncode == 0:
                        pandoc_exe = path
                        break
            except:
                continue
        
        if not pandoc_exe:
            # Log all attempted paths for debugging
            attempted_paths = pandoc_paths.copy()
            if pandoc_in_path:
                attempted_paths.insert(0, pandoc_in_path)
            if pandoc_env_path:
                attempted_paths.insert(0, pandoc_env_path)
            
            error_msg = f"Pandoc not found. Attempted paths: {attempted_paths}. "
            error_msg += "For production deployment, set PANDOC_PATH environment variable or install pandoc in standard locations."
            raise Exception(error_msg)
        
        # Create output directory
        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)
        
        # Pandoc conversion command
        cmd = [
            pandoc_exe,
            html_path,
            '-o', output_path,
            '--from', 'html',
            '--to', 'docx'
        ]
        
        # Execute conversion
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        if result.returncode != 0:
            error_msg = f"Pandoc conversion failed (exit code {result.returncode})"
            if result.stderr.strip():
                error_msg += f": {result.stderr.strip()}"
            raise Exception(error_msg)
        
        time.sleep(0.5)
        
        if not os.path.exists(output_path):
            raise Exception("Converted DOCX file not found")
        
        print("SUCCESS")
        
    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        sys.exit(1)

# Main execution
if __name__ == "__main__":
    html_path = "${tempHtmlPath.replace(/\\/g, "\\\\")}"
    output_path = "${tempDocxPath.replace(/\\/g, "\\\\")}"
    convert_html_to_docx_pandoc(html_path, output_path)
`;

    // Write Python script to temp file
    const pythonScriptPath = path.join(
      tempDir,
      `convert_html_${Date.now()}.py`,
    );
    fs.writeFileSync(pythonScriptPath, pythonScript);

    try {
      // Execute Python script using execFile
      const { stdout, stderr } = await execFileAsync(
        pythonCmd,
        [pythonScriptPath],
        {
          env: {
            ...process.env,
            PYTHONUNBUFFERED: "1",
            PYTHONIOENCODING: "utf-8",
          },
          timeout: 120000, // 2 minutes timeout
          maxBuffer: 50 * 1024 * 1024, // 50MB buffer
        },
      );

      // Clean up Python script
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch (e) {
        console.warn("Failed to clean up Python script:", e);
      }

      if (stdout.includes("SUCCESS")) {
        // Read the converted DOCX file
        if (fs.existsSync(tempDocxPath)) {
          const docxBuffer = fs.readFileSync(tempDocxPath);
          const base64Result = docxBuffer.toString("base64");

          // Clean up temp files
          try {
            fs.unlinkSync(tempHtmlPath);
            fs.unlinkSync(tempDocxPath);
          } catch (e) {
            console.warn("Failed to clean up temp files:", e);
          }

          return base64Result;
        } else {
          throw new Error("Converted DOCX file not found");
        }
      } else {
        throw new Error(`Python conversion failed: ${stderr || stdout}`);
      }
    } catch (error: any) {
      // Clean up Python script on error
      try {
        fs.unlinkSync(pythonScriptPath);
      } catch (e) {
        console.warn("Failed to clean up Python script:", e);
      }

      if (error.code === "ETIMEDOUT") {
        throw new Error("Conversion process timed out");
      } else {
        throw new Error(`Python conversion failed: ${error.message}`);
      }
    }
  } catch (error: any) {
    // Clean up temp files on any error
    try {
      if (fs.existsSync(tempHtmlPath)) fs.unlinkSync(tempHtmlPath);
      if (fs.existsSync(tempDocxPath)) fs.unlinkSync(tempDocxPath);
    } catch (e) {
      console.warn("Failed to clean up temp files:", e);
    }

    throw new Error(`HTML to DOCX conversion failed: ${error.message}`);
  }
}

/** Sanitize path/filename for S3: normalize accented chars (ñ, á, é, etc.) to ASCII to avoid SignatureDoesNotMatch. */
function sanitizeS3Key(pathOrName: string): string {
  return pathOrName
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/\\/g, "/")
    .replace(/[^\x00-\x7F]/g, "_");
}

// Helper function to download watermark logo from FRAMEWORK_BUCKET (no versioning)
async function downloadWatermarkLogo(key: string): Promise<Buffer> {
  const bucketName = process.env.FRAMEWORK_BUCKET || "";
  if (!bucketName) {
    throw new Error("FRAMEWORK_BUCKET environment variable is not set");
  }
  const s3 = new AWS.S3({
    region: process.env.AWS_REGION || "us-east-1",
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  });
  const params: AWS.S3.GetObjectRequest = {
    Bucket: bucketName,
    Key: key,
  };
  const result = await s3.getObject(params).promise();
  return result.Body as Buffer;
}

// Main handler for HTML to DOCX conversion with headers, footers, watermarks, and document summary
export const handleHtmlToDocx: RequestHandler = async (req, res) => {
  console.log("Processing handleHtmlToDocx");
  try {
    const {
      s3Path = "",
      s3Version = "",
      sourceBucketName = process.env.BUCKET_NAME,
      htmlContent = "",
      filename,
      headerText = "",
      footerText = "",
      includePageNumbers = true,
      allPages = true,
      headerAlign = "center",
      footerAlign = "right",
      headerImageUrl = "",
      headerImageWidthInch = 1.8,
      headerMarginInch,
      footerMarginInch,
      documentSummary,
      newPath = "",
      writeStream = false,
    } = req.body as any;

    // Get HTML content from S3 or direct input
    let htmlToProcess = htmlContent;

    if (s3Path && sourceBucketName) {
      // Download HTML from S3
      const s3 = new AWS.S3({
        region: process.env.AWS_REGION || "us-east-1",
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      });

      try {
        const params: AWS.S3.GetObjectRequest = {
          Bucket: sourceBucketName,
          Key: s3Path,
          ...(s3Version && { VersionId: s3Version }),
        };

        const result = await s3.getObject(params).promise();
        htmlToProcess = (result.Body as Buffer).toString("utf-8");
      } catch (s3Error) {
        console.error("Error downloading HTML from S3:", s3Error);
        return res.status(400).json({
          error: "Failed to download HTML from S3",
        });
      }
    }

    if (!htmlToProcess) {
      return res.status(400).json({
        error: "htmlContent or s3Path is required",
      });
    }

    // Step 1: Convert HTML to DOCX using Python
    console.log("Converting HTML to DOCX...");
    const convertedDocxBase64 = await convertHtmlToDocx(htmlToProcess);

    // Step 2: Process the converted DOCX with headers/footers using existing logic
    console.log("Processing DOCX with headers and footers...");
    const fileBuffer = Buffer.from(convertedDocxBase64, "base64");
    const zip = await JSZip.loadAsync(fileBuffer);

    let imageRelId: string | null = null;
    let imagePath = "";
    let imageWidthEmu = Math.round(
      EMU_PER_INCH * (Number(headerImageWidthInch) || 1.8),
    );
    let imageHeightEmu = Math.round(imageWidthEmu * 0.35);

    // Remove stale header/footer only for sections we are replacing.
    const relsPathInitial = "word/_rels/document.xml.rels";
    const relsXmlInitial = (await zip.file(relsPathInitial)?.async("text")) ?? "";
    const existingHeaderPart =
      findPartFromRels(relsXmlInitial, "header") ?? "word/header1.xml";
    const existingHeaderXml =
      (await zip.file(existingHeaderPart)?.async("text")) ?? "";
    const watermarkOverride = isWatermarkOverrideRequested(req.body);
    const watermarkPreserve = shouldPreserveWatermark(req.body);
    const watermarkDisabled =
      parseBoolean((req.body as any)?.watermarkEnabled) === false;

    const headerEnabled =
      (req.body as any)?.headerEnabled !== false &&
      (!!(req.body as any)?.headerEnabled || !!(req.body as any)?.headerText);
    const footerEnabled =
      (req.body as any)?.footerEnabled !== false &&
      (!!(req.body as any)?.footerEnabled || !!(req.body as any)?.footerText);

    const headerSnapshots = await snapshotHeaderParts(
      zip,
      relsXmlInitial,
      existingHeaderPart,
    );

    if (headerEnabled) {
      zip.remove("word/header1.xml");
      zip.remove("word/_rels/header1.xml.rels");
    }
    if (footerEnabled) {
      zip.remove("word/footer1.xml");
    }

    // Read the header rels file (may not exist yet) to assign safe, non-colliding IDs
    const existingHeaderRelsXml =
      (await zip.file("word/_rels/header1.xml.rels")?.async("text")) ?? "";
    const headerImageIds = nextRelId(existingHeaderRelsXml);

    let warning: string | undefined;
    if (headerImageUrl && typeof headerImageUrl === "string") {
      try {
        const response = await fetch(headerImageUrl);
        if (!response.ok)
          throw new Error(`Failed to fetch header image: ${response.status}`);
        const arrayBuf = await response.arrayBuffer();
        const contentType = response.headers.get("content-type");
        if (isWebP(contentType, headerImageUrl)) {
          warning =
            "Header image is WebP. Word doesn't support WebP; image skipped. Use PNG/JPG/GIF.";
        } else {
          const ext = guessImageExtension(contentType, headerImageUrl);
          imagePath = `word/media/header-image-1.${ext}`;
          imageRelId = headerImageIds.headerId; // dynamic, never collides
          const buf = Buffer.from(arrayBuf);
          const dims = getImageDimensions(buf);
          if (dims && dims.width > 0 && dims.height > 0) {
            const aspect = dims.height / dims.width;
            imageHeightEmu = Math.round(imageWidthEmu * aspect);
          }
          zip.file(imagePath, buf);
        }
      } catch (e) {
        imageRelId = null;
      }
    }

    const watermarkOptions = getWatermarkOptions(req.body as any);
    const dateFormat = (req.body as any)?.dateFormat as string | undefined;
    const formattedFields = formatDatesInObject(
      (req.body as any)?.fields || (req.body as any),
      dateFormat,
    );

    // Handle watermark logo if enabled
    const watermarkLogoEnable = parseBoolean(
      (req.body as any)?.watermarkLogoEnable,
    );
    const watermarkPath = (req.body as any)?.watermarkPath as
      | string
      | undefined;
    let watermarkImageRelId: string | null = null;
    let watermarkImagePath = "";
    let watermarkImageOptions: WatermarkImageOptions | undefined;

    if (
      watermarkLogoEnable &&
      !watermarkDisabled &&
      watermarkPath &&
      typeof watermarkPath === "string"
    ) {
      try {
        const watermarkBuffer = await downloadWatermarkLogo(watermarkPath);
        const ext = guessImageExtension(null, watermarkPath);
        watermarkImagePath = `word/media/watermark-logo.${ext}`;
        // Use a dynamic ID based on the header rels to avoid collision with imageRelId
        watermarkImageRelId = headerImageIds.footerId;

        // Get watermark logo size from request body, default to 4x4 inches
        const widthInch =
          (req.body as any)?.watermarkLogoWidthInch != null
            ? Number((req.body as any).watermarkLogoWidthInch)
            : 4;
        const heightInch =
          (req.body as any)?.watermarkLogoHeightInch != null
            ? Number((req.body as any).watermarkLogoHeightInch)
            : 4;

        let aspectRatio: number | undefined;
        const dims = getImageDimensions(watermarkBuffer);
        if (dims && dims.width > 0 && dims.height > 0) {
          aspectRatio = dims.width / dims.height;
        }

        watermarkImageOptions = {
          imageBuffer: watermarkBuffer,
          imageExtension: ext,
          opacity: watermarkOptions?.opacity,
          position: watermarkOptions?.position,
          widthInch,
          heightInch,
          aspectRatio,
        };

        zip.file(watermarkImagePath, watermarkBuffer);
      } catch (e: any) {
        console.error("Failed to load watermark logo:", e?.message || e);
        watermarkImageRelId = null;
      }
    }

    console.log("Watermark Added:", watermarkImageRelId ? "YES" : "NO");
    if (watermarkImageOptions) {
      console.log(
        "Watermark Dimensions:",
        watermarkImageOptions.widthInch +
          "x" +
          watermarkImageOptions.heightInch +
          " inch",
      );
    }

    const headerLayoutName = String(
      (req.body as any)?.headerLayoutName || "header1",
    )
      .trim()
      .toLowerCase();
    const footerLayoutName = String(
      (req.body as any)?.footerLayoutName || "footer1",
    )
      .trim()
      .toLowerCase();
    const headerModule = (HEADER_LAYOUTS[headerLayoutName] ??
      HEADER_LAYOUTS.header1) as typeof header1;
    const footerModule = (FOOTER_LAYOUTS[footerLayoutName] ??
      FOOTER_LAYOUTS.footer1) as typeof footer1;

    let headerXml = headerModule.buildHeaderXmlTable({
      withImage: !!imageRelId,
      imageRelId,
      imageWidthEmu,
      imageHeightEmu,
      docCode: (req.body as any)?.docCode,
      docTitle: (req.body as any)?.docTitle,
      company: (req.body as any)?.company,
      seriesLabel: (req.body as any)?.seriesLabel,
      docNo: (req.body as any)?.docNo,
      versionNo: (req.body as any)?.versionNo,
      centerKeys: (req.body as any)?.center,
      selectionKeys: (req.body as any)?.selections,
      fields: formattedFields,
      watermarkOptions:
        watermarkOverride || watermarkImageRelId ? undefined : watermarkOptions,
      watermarkImageRelId: watermarkOverride ? null : watermarkImageRelId,
      watermarkImageOptions: watermarkOverride ? undefined : watermarkImageOptions,
      language: (req.body as any)?.language || "en",
    });
    let preservedWatermark = "";
    let preservedWatermarkRelsXml = "";
    if (headerEnabled && watermarkPreserve) {
      const preserved = findPreservedWatermarkSnapshot(headerSnapshots);
      if (preserved) {
        preservedWatermark = preserved.watermark;
        preservedWatermarkRelsXml = preserved.relsXml;
        headerXml = injectWatermarkIntoHeaderXml(headerXml, preservedWatermark);
      }
    }

    const footerXml = footerModule.buildFooterXmlTable({
      footerKeys: (req.body as any)?.footer,
      fields: formattedFields,
      language: (req.body as any)?.language || "en",
    });

    if (headerEnabled) {
      zip.file("word/header1.xml", headerXml);
    }
    if (watermarkOverride) {
      const headerParts = listHeaderPartPaths(
        relsXmlInitial,
        Object.keys(zip.files),
        existingHeaderPart,
      );
      for (const headerPart of headerParts) {
        const hx = (await zip.file(headerPart)?.async("text")) ?? "";
        if (!hx) continue;
        const relsPart = headerRelsPartPath(headerPart);
        const existingRels =
          (await zip.file(relsPart)?.async("text")) ??
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n</Relationships>`;
        let wmRelId: string | null = null;
        if (watermarkImagePath && watermarkImageOptions) {
          wmRelId = nextHeaderPartRelId(existingRels);
        }
        const wmXml =
          wmRelId && watermarkImageOptions
            ? buildWatermarkImageParagraph(wmRelId, watermarkImageOptions)
            : watermarkOptions
              ? buildWatermarkParagraph(watermarkOptions)
              : "";
        if (!wmXml.trim()) continue;
        zip.file(
          headerPart,
          injectWatermarkIntoHeaderXml(
            removeWatermarkFromHeaderXml(hx),
            wmXml,
          ),
        );
        if (wmRelId && watermarkImagePath) {
          zip.file(
            relsPart,
            mergeHeaderRelationshipsXml(existingRels, [
              `<Relationship Id="${wmRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${watermarkImagePath.replace(
                /^word\//,
                "",
              )}"/>`,
            ]),
          );
        }
      }
    }
    if (footerEnabled) {
      zip.file("word/footer1.xml", footerXml);
    }

    // Build header rels with both header image and watermark image if present
    const headerRelLines: string[] = [];
    if (imageRelId && imagePath) {
      headerRelLines.push(
        `<Relationship Id="${imageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${imagePath.replace(
          /^word\//,
          "",
        )}"/>`,
      );
    }
    if (watermarkImageRelId && watermarkImagePath) {
      headerRelLines.push(
        `<Relationship Id="${watermarkImageRelId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="${watermarkImagePath.replace(
          /^word\//,
          "",
        )}"/>`,
      );
    }
    const preserveImageRels =
      !!preservedWatermark &&
      watermarkUsesImageRelationships(preservedWatermark) &&
      !!preservedWatermarkRelsXml.trim();
    if (
      headerEnabled &&
      (headerRelLines.length > 0 || preserveImageRels)
    ) {
      const headerRels = preserveImageRels
        ? mergeHeaderRelationshipsXml(
            preservedWatermarkRelsXml,
            headerRelLines,
          )
        : `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n${headerRelLines
            .map((line) => `  ${line}`)
            .join("\n")}\n</Relationships>`;
      zip.file("word/_rels/header1.xml.rels", headerRels);
    }

    const ctPath = "[Content_Types].xml";
    let ctXml = await zip.file(ctPath)!.async("text");
    if (headerEnabled) {
      ctXml = addOverrideIfMissing(
        ctXml,
        "/word/header1.xml",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml",
      );
    }
    if (footerEnabled) {
      ctXml = addOverrideIfMissing(
        ctXml,
        "/word/footer1.xml",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml",
      );
    }
    ctXml = addDefaultIfMissing(ctXml, "png", "image/png");
    ctXml = addDefaultIfMissing(ctXml, "jpg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "jpeg", "image/jpeg");
    ctXml = addDefaultIfMissing(ctXml, "gif", "image/gif");
    zip.file(ctPath, ctXml);

    const relsPath = "word/_rels/document.xml.rels";
    let relsXml = await zip.file(relsPath)!.async("text");
    // Strip stale header/footer rels from previous runs before computing new IDs
    relsXml = cleanStaleHeaderFooterRels(relsXml, {
      stripHeader: headerEnabled,
      stripFooter: footerEnabled,
    });
    const ids = nextRelId(relsXml);
    if (headerEnabled) {
      relsXml = upsertRelationship(
        relsXml,
        ids.headerId,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header",
        "header1.xml",
      );
    }
    if (footerEnabled) {
      relsXml = upsertRelationship(
        relsXml,
        ids.footerId,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer",
        "footer1.xml",
      );
    }
    zip.file(relsPath, relsXml);

    const docPath = "word/document.xml";
    let docXml = await zip.file(docPath)!.async("text");
    if (watermarkOverride) {
      docXml = removeDocumentBackgroundWatermark(docXml);
    }
    const headerMarginTwips =
      headerEnabled && headerMarginInch != null
        ? Math.round(Number(headerMarginInch) * TWIPS_PER_INCH)
        : undefined;
    const footerMarginTwips =
      footerEnabled && footerMarginInch != null
        ? Math.round(Number(footerMarginInch) * TWIPS_PER_INCH)
        : undefined;

    docXml = ensureSectPrWithRefs(
      docXml,
      headerEnabled ? ids.headerId : undefined,
      footerEnabled ? ids.footerId : undefined,
      !!allPages,
      headerMarginTwips,
      footerMarginTwips,
    );

    // Add document summary if provided (with optional date formatting)
    const formattedSummary = formatDatesInDocumentSummary(
      documentSummary,
      dateFormat,
    );
    if (formattedSummary) {
      docXml = await addDocumentSummaryToDocument(
        docXml,
        formattedSummary,
        zip,
        createNextRelId(relsXml),
        (req.body as any)?.language || "en",
      );
    }

    zip.file(docPath, docXml);

    // Ensure modern compatibility to avoid legacy save warnings
    await ensureModernCompatibility(zip);

    const out = await zip.generateAsync({ type: "nodebuffer" });
    const outB64 = out.toString("base64");
    const shouldPrint = !!(req.body as any)?.shouldPrint;
    console.log("shouldPrint", shouldPrint);

    // Handle AWS S3 streaming when writeStream is true
    if (writeStream && newPath) {
      try {
        const s3 = new AWS.S3({
          region: process.env.AWS_REGION || "us-east-1",
          accessKeyId: process.env.AWS_ACCESS_KEY_ID,
          secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        });

        const safeFilename = sanitizeS3Key(filename || "document.docx");

        const uploadParams: AWS.S3.PutObjectRequest = {
          Bucket: sourceBucketName,
          Key: newPath,
          Body: out,
          ContentType:
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          ContentDisposition: `attachment; filename="${safeFilename}"`,
        };

        const uploadResult = await s3.upload(uploadParams).promise();
        console.log("Successfully uploaded DOCX to S3:", uploadResult.Location);

        // Get the version ID from the S3 response
        const headResult = await s3
          .headObject({
            Bucket: sourceBucketName,
            Key: newPath,
          })
          .promise();

        return res.json({
          fileBase64: outB64,
          success: true,
          s3Location: uploadResult.Location,
          s3Key: uploadResult.Key,
          versionId: headResult.VersionId,
          filename: filename || "html_converted_and_processed.docx",
          warning,
          conversionInfo:
            "HTML converted to DOCX, processed with headers/footers, and uploaded to S3",
        });
      } catch (s3Error: any) {
        console.error("Error uploading to S3:", s3Error);
        return res.status(500).json({
          error: "Failed to upload DOCX to S3",
          details: s3Error.message,
        });
      }
    }

    if (shouldPrint) {
      try {
        const pdfBase64 = await convertDocxBase64ToPdfBase64(outB64);
        return res.json({
          fileBase64: pdfBase64,
          filename:
            (filename
              ? filename.replace(/\.docx?$/i, "")
              : "html_converted_and_processed") + ".pdf",
          warning,
          conversionInfo:
            "HTML converted to DOCX, processed with headers/footers, and exported to PDF",
        });
      } catch (e) {
        return res.json({
          fileBase64: outB64,
          filename: filename || "html_converted_and_processed.docx",
          warning,
          conversionInfo:
            "HTML converted to DOCX and processed with headers/footers (PDF export failed)",
        });
      }
    }

    return res.json({
      fileBase64: outB64,
      filename: filename || "html_converted_and_processed.docx",
      warning,
      conversionInfo:
        "HTML converted to DOCX and processed with headers/footers",
    });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: String(err) });
  }
};

export default handleHtmlToDocx;
