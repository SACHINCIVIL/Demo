/**
 * Pure lxml + zipfile: patch only headerFooter on each sheet; rest of ZIP unchanged.
 * Injects same build_header / build_footer as openpyxl path (header1/header6 × footer1–5).
 */
const PH_H = "{{BUILD_HEADER_DEF}}";
const PH_F = "{{BUILD_FOOTER_DEF}}";

const PREFIX = String.raw`"""
xlsx_lxml_processor.py — surgical header/footer only (no openpyxl).
"""
import io
import json
import re
import sys
import zipfile
from lxml import etree

XLSX_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
SNS = "{" + XLSX_NS + "}"
SHEET_RE = re.compile(r"^xl/worksheets/sheet\d+\.xml$")

LABELS = {
    "createdBy": "Created By",
    "publishedOn": "Published On",
    "createdOn": "Created On",
    "publishedBy": "Published By",
    "modifiedBy": "Modified By",
    "modifiedOn": "Modified On",
    "approvedBy": "Approved By",
    "approvedOn": "Approved On",
    "reviewedBy": "Reviewed By",
    "reviewedOn": "Reviewed On",
    "version": "Version",
    "docNo": "Doc No",
    "docName": "Document Name",
    "userInitials": "User",
    "issuedDate": "Issued Date",
    "supersedesDate": "Supersedes Date",
    "company": "Company",
    "clientName": "Client Name",
}

def label(k, translations=None):
    if translations and k in translations:
        return translations[k]
    return LABELS.get(k, k.replace("_", " ").title())

def sanitize(s):
    if not s:
        return ""
    s = str(s)
    s = "".join(ch if (ord(ch) >= 32 or ch in "\n\t\r") else " " for ch in s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("&", "&&")
    return s

def safe_for_excel_header_footer(s):
    if s is None:
        return ""
    s = str(s)
    out = []
    for ch in s:
        o = ord(ch)
        if ch in "\n\t\r":
            out.append(ch)
        elif 32 <= o <= 0xD7FF:
            out.append(ch)
        elif 0xE000 <= o <= 0xFFFD:
            out.append(ch)
        else:
            out.append(" ")
    return "".join(out)

def _with_font_size(size, text):
    if not text:
        return ""
    return f"&{size} {text}"

`;

const SUFFIX = String.raw`

def _compose(left, center, right):
    parts = []
    if left:
        parts.append(f"&L{left}")
    if center:
        parts.append(f"&C{center}")
    if right:
        parts.append(f"&R{right}")
    return "".join(parts)


def _coerce_bool(value, default=True):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        v = value.strip().lower()
        if v in ("true", "1", "yes", "on"):
            return True
        if v in ("false", "0", "no", "off", ""):
            return False
    return default


def _escape_hf_text(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _build_hf_element(tag, text):
    esc = _escape_hf_text(text)
    return f'<{tag} xml:space="preserve">{esc}</{tag}>'


def _extract_hf_child(xml_bytes, tag):
    """Return the full <tag>…</tag> element inside headerFooter, or None."""
    pat = re.compile(
        rb'<'
        + tag.encode('ascii')
        + rb'(?:\s[^>]*)?>(.*?)</'
        + tag.encode('ascii')
        + rb'>',
        re.DOTALL,
    )
    m = pat.search(xml_bytes)
    return m.group(0) if m else None


def _extract_hf_attrs(existing_block):
    if not existing_block:
        return ""
    m = re.match(rb'<headerFooter(\s[^>]*)>', existing_block)
    return m.group(1).decode("utf-8") if m else ""


def _append_preserved_hf_children(existing_block, hf_parts, tags):
    if not existing_block:
        return
    for tag in tags:
        preserved = _extract_hf_child(existing_block, tag)
        if preserved:
            hf_parts.append(preserved.decode("utf-8"))


def _header_footer_has_picture(hf_bytes):
    return b"&G" in hf_bytes or b"&amp;G" in hf_bytes


def _strip_orphan_header_footer_drawings(xml_bytes, hf_bytes):
    if _header_footer_has_picture(hf_bytes):
        return xml_bytes
    xml_bytes = re.sub(rb"<legacyDrawingHF[^/]*/>", b"", xml_bytes)
    xml_bytes = re.sub(rb"<drawingHF\b[^>]*/>", b"", xml_bytes)
    return xml_bytes


def _validate_worksheet_xml(xml_bytes):
    try:
        etree.fromstring(xml_bytes)
        return True
    except Exception:
        return False


def _patch_sheet(xml_bytes, header_str, footer_str, header_enabled, footer_enabled):
    """
    Surgically replace only <headerFooter>…</headerFooter> in the sheet XML.
    Disabled sections keep their existing oddHeader/oddFooter content.
    Everything else is preserved byte-for-byte, avoiding lxml namespace reordering.
    """
    hf_full = re.compile(rb'<headerFooter(?:\s[^>]*)?>.*?</headerFooter>', re.DOTALL)
    hf_self = re.compile(rb'<headerFooter[^>]*/>')
    existing_hf = hf_full.search(xml_bytes) or hf_self.search(xml_bytes)
    existing_block = existing_hf.group(0) if existing_hf else None
    hf_attrs = _extract_hf_attrs(existing_block)

    hf_parts = []
    if header_enabled:
        hf_parts.append(_build_hf_element("oddHeader", header_str))
    elif existing_block:
        _append_preserved_hf_children(
            existing_block, hf_parts, ("oddHeader", "evenHeader", "firstHeader")
        )

    if footer_enabled:
        hf_parts.append(_build_hf_element("oddFooter", footer_str))
    elif existing_block:
        _append_preserved_hf_children(
            existing_block, hf_parts, ("oddFooter", "evenFooter", "firstFooter")
        )

    new_hf = (
        f'<headerFooter{hf_attrs}>' + "".join(hf_parts) + "</headerFooter>"
        if hf_parts
        else f"<headerFooter{hf_attrs}/>"
    ).encode("utf-8")

    if hf_full.search(xml_bytes):
        result = hf_full.sub(new_hf, xml_bytes)
    elif hf_self.search(xml_bytes):
        result = hf_self.sub(new_hf, xml_bytes)
    else:
        # No existing headerFooter — insert BEFORE elements that must follow it in
        # OOXML schema order: drawing, drawingHF, picture, oleObjects, controls,
        # webPublishItems, tableParts, extLst — otherwise Excel sees invalid schema.
        # ⚠️  Do NOT just insert before </worksheet>: if <drawing> is already there
        #     (e.g. sheet has embedded images), headerFooter would land after it → corruption.
        insert_before = re.compile(
            rb'<(?:drawing|drawingHF|picture|oleObjects|controls|webPublishItems|tableParts|extLst)[\s>/]'
        )
        m = insert_before.search(xml_bytes)
        if m:
            pos = m.start()
            result = xml_bytes[:pos] + new_hf + xml_bytes[pos:]
        else:
            result = xml_bytes.replace(b'</worksheet>', new_hf + b'</worksheet>', 1)

    if header_enabled or footer_enabled:
        result = _strip_orphan_header_footer_drawings(result, new_hf)

    return result


def process(input_path, output_path, config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    header_enabled = _coerce_bool(cfg.get("headerEnabled"), True)
    footer_enabled = _coerce_bool(cfg.get("footerEnabled"), True)
    lh, ch, rh = build_header(cfg)
    lf, cf, rf = build_footer(cfg)
    lh = "" if not header_enabled else (str(lh) if lh else "")
    ch = "" if not header_enabled else (str(ch) if ch else "")
    rh = "" if not header_enabled else (str(rh) if rh else "")
    lf = "" if not footer_enabled else (str(lf) if lf else "")
    cf = "" if not footer_enabled else (str(cf) if cf else "")
    rf = "" if not footer_enabled else (str(rf) if rf else "")
    header_str = _compose(lh, ch, rh)
    footer_str = _compose(lf, cf, rf)
    with open(input_path, "rb") as f:
        input_bytes = f.read()
    out_buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(input_bytes)) as zin, \
         zipfile.ZipFile(out_buf, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if SHEET_RE.match(item.filename):
                try:
                    patched = _patch_sheet(
                        data, header_str, footer_str, header_enabled, footer_enabled
                    )
                    if _validate_worksheet_xml(patched):
                        data = patched
                    else:
                        print(f"Warning: headerFooter patch produced invalid XML for "
                              f"{item.filename}; keeping original sheet", file=sys.stderr)
                except Exception as e:
                    print(f"Warning: could not patch {item.filename}: {e}", file=sys.stderr)
            zout.writestr(item, data)
    with open(output_path, "wb") as f:
        f.write(out_buf.getvalue())


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: xlsx_lxml_processor.py <in.xlsx> <out.xlsx> <config.json>")
        sys.exit(1)
    process(sys.argv[1], sys.argv[2], sys.argv[3])
`;

export function buildLxmlScript(
  buildHeaderDef: string,
  buildFooterDef: string,
): string {
  return (
    PREFIX + "\n" + buildHeaderDef + "\n\n" + buildFooterDef + "\n" + SUFFIX
  );
}
