/**
 * Universal lxml-based Excel processor.
 *
 * - Header/footer:  lxml patches only <headerFooter> in each sheet XML.
 *   Everything else in the ZIP (x14 validations, sharedStrings, calcChain,
 *   drawing rels, tables, printer settings …) is copied byte-for-byte.
 *
 * - Document summary: built entirely with lxml XML generation (no openpyxl).
 *   The sheet is injected into the ZIP by updating workbook.xml,
 *   workbook.xml.rels, and [Content_Types].xml.  No style-index borrowing
 *   needed: bold/font-size are carried as inline rich-text (<is><r><rPr>).
 *
 * openpyxl is NOT used anywhere in this path, so no data loss is possible.
 */
const PH_H = "{{BUILD_HEADER_DEF}}";
const PH_F = "{{BUILD_FOOTER_DEF}}";

const PREFIX = String.raw`"""
xlsx_lxml_master.py — header/footer patch + optional summary injection.
All original ZIP entries are copied untouched except <headerFooter> elements.
"""
import io, json, re, sys, zipfile
from lxml import etree

# ── namespaces ────────────────────────────────────────────────────────────────
XLSX_NS  = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS   = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL  = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS    = "http://schemas.openxmlformats.org/package/2006/content-types"
WS_TYPE  = REL_NS + "/worksheet"
WS_CT    = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
SNS      = "{" + XLSX_NS + "}"
SHEET_RE = re.compile(r"^xl/worksheets/sheet\d+\.xml$")

# ── shared helpers (same as openpyxl path) ───────────────────────────────────
LABELS = {
    "createdBy": "Created By", "publishedOn": "Published On",
    "createdOn": "Created On", "publishedBy": "Published By",
    "modifiedBy": "Modified By", "modifiedOn": "Modified On",
    "approvedBy": "Approved By", "approvedOn": "Approved On",
    "reviewedBy": "Reviewed By", "reviewedOn": "Reviewed On",
    "version": "Version", "docNo": "Doc No", "docName": "Document Name",
    "userInitials": "User", "issuedDate": "Issued Date",
    "supersedesDate": "Supersedes Date", "company": "Company",
    "clientName": "Client Name",
}

def label(k, translations=None):
    if translations and k in translations:
        return translations[k]
    return LABELS.get(k, k.replace("_", " ").title())

def sanitize(s):
    if not s: return ""
    s = str(s)
    s = "".join(ch if (ord(ch) >= 32 or ch in "\n\t\r") else " " for ch in s)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("&", "&&")
    return s

def safe_for_excel_header_footer(s):
    if s is None: return ""
    s = str(s)
    out = []
    for ch in s:
        o = ord(ch)
        if ch in "\n\t\r": out.append(ch)
        elif 32 <= o <= 0xD7FF: out.append(ch)
        elif 0xE000 <= o <= 0xFFFD: out.append(ch)
        else: out.append(" ")
    return "".join(out)

def _with_font_size(size, text):
    return f"&{size} {text}" if text else ""

def _safe_sheet_name(name):
    try: s = str(name or "Document Control Summary")
    except: s = "Document Control Summary"
    s = "".join(ch for ch in s if ch not in set('\\/*?:[]')).strip() or "Summary"
    return s[:31]

`;

const SUFFIX = String.raw`


def _to_xml(root):
    b = etree.tostring(root, xml_declaration=True, encoding="UTF-8")
    if b.startswith(b"<?xml"):
        end = b.find(b"?>")
        if end != -1:
            return b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + b[end+2:]
    return b


def _coerce_bool(value, default=True):
    """Parse headerEnabled/footerEnabled from JSON (bool, str, int, or null)."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        v = value.strip().lower()
        if v in ("true", "1", "yes", "on"):
            return True
        if v in ("false", "0", "no", "off", ""):
            return False
    return default


def _escape_hf_text(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _build_hf_element(tag, text):
    esc = _escape_hf_text(text)
    return f'<{tag} xml:space="preserve">{esc}</{tag}>'


def _compose(left, center, right):
    parts = []
    if left:   parts.append(f"&L{left}")
    if center: parts.append(f"&C{center}")
    if right:  parts.append(f"&R{right}")
    return "".join(parts)

# ── lxml: patch headerFooter in a single sheet XML ───────────────────────────
def _extract_hf_child(xml_bytes, tag):
  """Return the inner XML of the first <tag>…</tag> inside headerFooter, or None."""
  pat = re.compile(
      rb'<'
      + tag.encode('ascii')
      + rb'(?:\s[^>]*)?>(.*?)</'
      + tag.encode('ascii')
      + rb'>',
      re.DOTALL,
  )
  m = pat.search(xml_bytes)
  return m.group(0) if m else None


def _extract_hf_attrs(existing_block):
    """Return attribute string from <headerFooter ...> if present."""
    if not existing_block:
        return ""
    m = re.match(rb'<headerFooter(\s[^>]*)>', existing_block)
    return m.group(1).decode("utf-8") if m else ""


def _append_preserved_hf_children(existing_block, hf_parts, tags):
    """Copy existing header/footer child elements verbatim when a section is disabled."""
    if not existing_block:
        return
    for tag in tags:
        preserved = _extract_hf_child(existing_block, tag)
        if preserved:
            hf_parts.append(preserved.decode("utf-8"))


def _header_footer_has_picture(hf_bytes):
    """Detect Excel picture placeholder in header/footer markup (&G or XML-escaped &amp;G)."""
    return b"&G" in hf_bytes or b"&amp;G" in hf_bytes


def _strip_orphan_header_footer_drawings(xml_bytes, hf_bytes):
    """Remove header/footer image refs when the new markup has no &G placeholder."""
    if _header_footer_has_picture(hf_bytes):
        return xml_bytes
    xml_bytes = re.sub(rb"<legacyDrawingHF[^/]*/>", b"", xml_bytes)
    xml_bytes = re.sub(rb"<drawingHF\b[^>]*/>", b"", xml_bytes)
    return xml_bytes


def _validate_worksheet_xml(xml_bytes):
    """Fail-safe: ensure patched sheet XML is well-formed before writing."""
    try:
        etree.fromstring(xml_bytes)
        return True
    except Exception:
        return False


def _patch_sheet(xml_bytes, header_str, footer_str, header_enabled, footer_enabled):
    """
    Surgically replace only <headerFooter>…</headerFooter> in the sheet XML.
    Disabled sections keep their existing oddHeader/oddFooter content.
    Everything else is preserved byte-for-byte, avoiding lxml namespace reordering.
    """
    hf_full = re.compile(rb'<headerFooter(?:\s[^>]*)?>.*?</headerFooter>', re.DOTALL)
    hf_self = re.compile(rb'<headerFooter[^>]*/>')
    existing_hf = hf_full.search(xml_bytes) or hf_self.search(xml_bytes)
    existing_block = existing_hf.group(0) if existing_hf else None
    hf_attrs = _extract_hf_attrs(existing_block)

    hf_parts = []
    if header_enabled:
        hf_parts.append(_build_hf_element("oddHeader", header_str))
    elif existing_block:
        _append_preserved_hf_children(
            existing_block, hf_parts, ("oddHeader", "evenHeader", "firstHeader")
        )

    if footer_enabled:
        hf_parts.append(_build_hf_element("oddFooter", footer_str))
    elif existing_block:
        _append_preserved_hf_children(
            existing_block, hf_parts, ("oddFooter", "evenFooter", "firstFooter")
        )

    new_hf = (
        f'<headerFooter{hf_attrs}>' + "".join(hf_parts) + "</headerFooter>"
        if hf_parts
        else f"<headerFooter{hf_attrs}/>"
    ).encode("utf-8")

    if hf_full.search(xml_bytes):
        result = hf_full.sub(new_hf, xml_bytes)
    elif hf_self.search(xml_bytes):
        result = hf_self.sub(new_hf, xml_bytes)
    else:
        # Insert headerFooter before the first element that must follow it
        # in OOXML CT_Worksheet sequence (ECMA-376 §18.3.1.99)
        insert_before = re.compile(
            rb'<(?:rowBreaks|colBreaks|customProperties|cellWatches|ignoredErrors'
            rb'|smartTags|drawing|legacyDrawing|legacyDrawingHF|drawingHF|picture'
            rb'|oleObjects|controls|webPublishItems|tableParts|extLst)[\s>/]'
        )
        m = insert_before.search(xml_bytes)
        if m:
            pos = m.start()
            result = xml_bytes[:pos] + new_hf + xml_bytes[pos:]
        else:
            # No post-headerFooter elements exist — safe to insert before </worksheet>
            result = xml_bytes.replace(b'</worksheet>', new_hf + b'</worksheet>', 1)

    # Only strip orphaned header/footer images when actively replacing that section
    # and the new markup has no &G picture placeholder.
    if header_enabled or footer_enabled:
        result = _strip_orphan_header_footer_drawings(result, new_hf)

    return result

# ── summary sheet helpers ─────────────────────────────────────────────────────
def _col_letter(n):
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s

def _format_action_label(value):
    text = str(value or "").strip()
    if not text:
        return ""
    parts = re.split(r"(\\s+|_|-)", text)
    out = []
    for part in parts:
        if not part or re.match(r"^[\\s_\\-]+$", part):
            out.append(part)
            continue
        if part == part.upper() and re.search(r"[A-Z]", part):
            out.append(part[0] + part[1:].lower())
        else:
            out.append(part)
    return "".join(out)

def _normalize_summary_keys(keys):
    # One Comments column only — fold detail/date fields into parent columns.
    skip = {"Comments Detail", "Action Date", "Performed Date"}
    return [k for k in keys if k not in skip]

def _stack_two_lines(top, bottom):
    top = str(top or "").strip()
    bottom = str(bottom or "").strip()
    if top and bottom:
        return top + chr(10) + bottom
    return top or bottom

def _comments_cell_value(rec):
    # Same as DOCX: "Change Log: detail" in one cell (no second Comments column).
    label = _format_action_label(str((rec or {}).get("Comments") or "").strip())
    detail = str((rec or {}).get("Comments Detail") or "").strip()
    if label and detail:
        return label + " " + detail
    return label or detail

def _action_cell_value(rec, title_case=False):
    action = (rec or {}).get("Action")
    if title_case:
        action = _format_action_label(action)
    # Action column shows label only (no Action Date under it).
    return str(action or "").strip()

def _performed_by_cell_value(rec):
    return _stack_two_lines(
        (rec or {}).get("Performed By"),
        (rec or {}).get("Performed Date"),
    )

def _summary_font_rpr(rpr, font_size=None, bold=False):
    etree.SubElement(rpr, f"{SNS}rFont", val="Arial")
    etree.SubElement(rpr, f"{SNS}sz", val=str(font_size or 11))
    if bold:
        etree.SubElement(rpr, f"{SNS}b")

def _bold_cell(row_el, ref, text, font_size=None):
    c   = etree.SubElement(row_el, f"{SNS}c", r=ref, t="inlineStr")
    is_ = etree.SubElement(c,   f"{SNS}is")
    r   = etree.SubElement(is_, f"{SNS}r")
    rpr = etree.SubElement(r,   f"{SNS}rPr")
    _summary_font_rpr(rpr, font_size=font_size, bold=True)
    etree.SubElement(r, f"{SNS}t").text = str(text or "")

def _plain_cell(row_el, ref, text):
    c   = etree.SubElement(row_el, f"{SNS}c", r=ref, t="inlineStr")
    is_ = etree.SubElement(c,     f"{SNS}is")
    r   = etree.SubElement(is_,   f"{SNS}r")
    rpr = etree.SubElement(r, f"{SNS}rPr")
    _summary_font_rpr(rpr)
    t_el = etree.SubElement(r, f"{SNS}t")
    t_el.text = str(text or "")
    # Preserve real newlines (Action / Performed By stacked values).
    if "\\n" in t_el.text or "\\r" in t_el.text or chr(10) in t_el.text or chr(13) in t_el.text:
        t_el.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")

# ── image download ────────────────────────────────────────────────────────────
def _download_image(url):
    """Return (bytes, ext) or (None, None) on failure."""
    try:
        import urllib.request
        req = urllib.request.Request(
            url, headers={"User-Agent": "Mozilla/5.0 (compatible)"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = resp.read()
            ct = (resp.getheader("Content-Type") or "image/png").lower().split(";")[0].strip()
            if "jpeg" in ct or "jpg" in ct:
                ext = "jpeg"
            else:
                ext = "png"
            return data, ext
    except Exception as e:
        print(f"Warning: signature image download failed ({url}): {e}", file=sys.stderr)
        return None, None

def _get_image_dimensions(data):
    """Return (width, height) in pixels or None."""
    if not data or len(data) < 10:
        return None
    # PNG
    if (len(data) > 24 and data[0] == 0x89 and data[1] == 0x50
            and data[2] == 0x4E and data[3] == 0x47):
        w = int.from_bytes(data[16:20], "big")
        h = int.from_bytes(data[20:24], "big")
        return (w, h) if w and h else None
    # GIF
    if (len(data) > 10 and data[0:3] == b"GIF"):
        w = int.from_bytes(data[6:8], "little")
        h = int.from_bytes(data[8:10], "little")
        return (w, h) if w and h else None
    # JPEG
    if data[0:2] == b"\\xff\\xd8":
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            seg_len = int.from_bytes(data[i + 2:i + 4], "big")
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                          0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h = int.from_bytes(data[i + 5:i + 7], "big")
                w = int.from_bytes(data[i + 7:i + 9], "big")
                return (w, h) if w and h else None
            i += 2 + seg_len
    return None

def _fit_signature_emu(data, max_w_emu, max_h_emu):
    """Fit signature inside max box (EMU), preserving aspect ratio.

    Image header dimensions are pixels; Excel drawing cx/cy are EMUs
    (1 px ≈ 9525 EMU). Mixing the two made PNGs nearly invisible.
    """
    EMU_PER_PX = 9525
    dims = _get_image_dimensions(data)
    if not dims:
        return max_w_emu, max_h_emu
    w, h = dims
    if w <= 0 or h <= 0:
        return max_w_emu, max_h_emu
    w_emu = w * EMU_PER_PX
    h_emu = h * EMU_PER_PX
    scale = min(max_w_emu / w_emu, max_h_emu / h_emu, 1.0)
    return max(1, int(w_emu * scale)), max(1, int(h_emu * scale))

# ── drawing XML builders ──────────────────────────────────────────────────────
XDR_NS   = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
A_NS     = "http://schemas.openxmlformats.org/drawingml/2006/main"
DRAW_TYPE = REL_NS + "/drawing"
IMG_TYPE  = REL_NS + "/image"
DRAW_CT   = "application/vnd.openxmlformats-officedocument.drawing+xml"
SIG_MAX_W_EMU = 837300   # ~88 px — max signature width
SIG_MAX_H_EMU = 342900   # ~36 px — max signature height

def _build_drawing_xml(anchors):
    """anchors = [(col_0based, row_0based, rid_str, cx_emu, cy_emu), ...]"""
    root = etree.Element(f"{{{XDR_NS}}}wsDr",
                         nsmap={"xdr": XDR_NS, "a": A_NS, "r": REL_NS})
    for idx, (col, row, rid, cx, cy) in enumerate(anchors, 1):
        anc = etree.SubElement(root, f"{{{XDR_NS}}}oneCellAnchor")
        frm = etree.SubElement(anc,  f"{{{XDR_NS}}}from")
        etree.SubElement(frm, f"{{{XDR_NS}}}col").text    = str(col)
        etree.SubElement(frm, f"{{{XDR_NS}}}colOff").text = "0"
        etree.SubElement(frm, f"{{{XDR_NS}}}row").text    = str(row)
        etree.SubElement(frm, f"{{{XDR_NS}}}rowOff").text = "0"
        ext = etree.SubElement(anc, f"{{{XDR_NS}}}ext")
        ext.set("cx", str(cx)); ext.set("cy", str(cy))
        pic    = etree.SubElement(anc, f"{{{XDR_NS}}}pic")
        nvPic  = etree.SubElement(pic, f"{{{XDR_NS}}}nvPicPr")
        cNvPr  = etree.SubElement(nvPic, f"{{{XDR_NS}}}cNvPr")
        cNvPr.set("id", str(idx + 1)); cNvPr.set("name", f"Signature {idx}")
        etree.SubElement(nvPic, f"{{{XDR_NS}}}cNvPicPr")
        blipFill = etree.SubElement(pic, f"{{{XDR_NS}}}blipFill")
        blip = etree.SubElement(blipFill, f"{{{A_NS}}}blip")
        blip.set(f"{{{REL_NS}}}embed", rid)
        stretch = etree.SubElement(blipFill, f"{{{A_NS}}}stretch")
        etree.SubElement(stretch, f"{{{A_NS}}}fillRect")
        spPr   = etree.SubElement(pic, f"{{{XDR_NS}}}spPr")
        xfrm   = etree.SubElement(spPr, f"{{{A_NS}}}xfrm")
        off    = etree.SubElement(xfrm, f"{{{A_NS}}}off")
        off.set("x", "0"); off.set("y", "0")
        ext2   = etree.SubElement(xfrm, f"{{{A_NS}}}ext")
        ext2.set("cx", str(cx)); ext2.set("cy", str(cy))
        pg = etree.SubElement(spPr, f"{{{A_NS}}}prstGeom")
        pg.set("prst", "rect")
        etree.SubElement(pg, f"{{{A_NS}}}avLst")
        etree.SubElement(anc, f"{{{XDR_NS}}}clientData")
    return _to_xml(root)

def _build_drawing_rels(media_names):
    """media_names = ['image1.png', 'image2.jpeg', ...]"""
    root = etree.Element(f"{{{PKG_REL}}}Relationships", nsmap={None: PKG_REL})
    for i, name in enumerate(media_names, 1):
        rel = etree.SubElement(root, f"{{{PKG_REL}}}Relationship")
        rel.set("Id", f"rId{i}")
        rel.set("Type", IMG_TYPE)
        rel.set("Target", f"../media/{name}")
    return _to_xml(root)

def _build_sheet_rels(drawing_num):
    root = etree.Element(f"{{{PKG_REL}}}Relationships", nsmap={None: PKG_REL})
    rel  = etree.SubElement(root, f"{{{PKG_REL}}}Relationship")
    rel.set("Id",     "rId1")
    rel.set("Type",   DRAW_TYPE)
    rel.set("Target", f"../drawings/drawing{drawing_num}.xml")
    return _to_xml(root)

# ── summary sheet builder ─────────────────────────────────────────────────────
def _make_summary_sheet(summary, header_str, footer_str, cfg):
    """
    Returns (sheet_xml, sheet_name, sig_placements).
    sig_placements = [(col_0based, row_0based, url), ...] — cells that have sig URLs.
    """
    if not summary:
        return None, None, []

    ts = cfg.get("translationsSummary") or {}
    sheet_name = _safe_sheet_name(ts.get("title", "Document Control Summary"))

    section_key_map = {
        "workflowHistory": ts.get("workflowHistory", "Documents Workflow :"),
        "versionLog":      ts.get("versionLog",      "Version Log :"),
        "documentReview":  ts.get("documentReview",  "Document Review :"),
        "versionSummary":  ts.get("title",           "Document Control Summary"),
        "Documents Workflow :": ts.get("workflowHistory", "Documents Workflow :"),
        "Version Log :":        ts.get("versionLog",      "Version Log :"),
        "Document Review :":    ts.get("documentReview",  "Document Review :"),
    }
    header_map = {
        "Action":                  ts.get("action",              "Action"),
        "User":                    ts.get("user",                "User"),
        "Date and time":           ts.get("dateAndTime",         "Date and time"),
        "Signature":               ts.get("signature",           "Signature"),
        "Version":                 ts.get("version",             "Version"),
        "Change Log Description":  ts.get("changeLogDescription","Change Log Description"),
        "Created by":              ts.get("createdBy",           "Created by"),
        "Created On":              ts.get("createdOn",           "Created On"),
        "Review comments":         ts.get("reviewComments",      "Review comments"),
        "Date time periodic":      ts.get("dateTimePeriodic",    "Date time periodic"),
        "Reviewed by":             ts.get("reviewedBy",          "Reviewed by"),
        "Performed By":            ts.get("performedBy",         "Performed By"),
        "Comments":                ts.get("comments",            "Comments"),
        "Action Type":             ts.get("actionType",          "Action Type"),
    }

    rows   = []
    widths = {}

    for section, items in summary.items():
        if not isinstance(items, list) or not items or not isinstance(items[0], dict):
            continue
        heading = section_key_map.get(section, section)
        keys    = _normalize_summary_keys(list(items[0].keys()))
        # Title-case Action/Action Type labels (DOCS i18n values are often ALL CAPS).
        title_case_action = True
        rows.append(("heading", heading, keys, False))
        rows.append(("header",  keys,    keys, False))
        for i, k in enumerate(keys, 1):
            widths[i] = max(widths.get(i, 10), len(header_map.get(k, k)) + 3)
        for rec in items:
            rows.append(("data", rec, keys, title_case_action))
            for i, k in enumerate(keys, 1):
                if k == "Comments":
                    cell_val = _comments_cell_value(rec)
                elif k == "Action":
                    cell_val = _action_cell_value(rec, title_case=title_case_action)
                elif k == "Action Type":
                    cell_val = _format_action_label(rec.get(k, "") or "")
                elif k == "Performed By":
                    cell_val = _performed_by_cell_value(rec)
                else:
                    cell_val = rec.get(k, "") or ""
                widths[i] = max(widths.get(i, 10),
                                min(len(str(cell_val)), 40))
        rows.append(("gap", None, None, False))
        rows.append(("gap", None, None, False))

    root = etree.Element(f"{SNS}worksheet",
                         nsmap={None: XLSX_NS, "r": REL_NS})
    if widths:
        cols_el = etree.SubElement(root, f"{SNS}cols")
        for idx, w in sorted(widths.items()):
            col = etree.SubElement(cols_el, f"{SNS}col")
            col.set("min", str(idx)); col.set("max", str(idx))
            col.set("width", str(max(w, 14))); col.set("customWidth", "1")

    sd = etree.SubElement(root, f"{SNS}sheetData")
    row_num        = 1
    sig_placements = []   # (col_0based, row_0based, url)

    for kind, payload, keys, title_case_action in rows:
        if kind == "gap":
            row_num += 1
            continue
        row_el = etree.SubElement(sd, f"{SNS}row")
        row_el.set("r", str(row_num))
        if kind == "heading":
            row_el.set("ht", "22"); row_el.set("customHeight", "1")
            _bold_cell(row_el, f"A{row_num}", payload, font_size=14)
        elif kind == "header":
            row_el.set("ht", "18"); row_el.set("customHeight", "1")
            for i, k in enumerate(keys, 1):
                _bold_cell(row_el, f"{_col_letter(i)}{row_num}",
                           header_map.get(k, k))
        elif kind == "data":
            row_el.set("ht", "42"); row_el.set("customHeight", "1")
            sig_col = keys.index("Signature") + 1 if "Signature" in keys else None
            for i, k in enumerate(keys, 1):
                val = payload.get(k, "")
                if k == "Comments":
                    val = _comments_cell_value(payload)
                elif k == "Action":
                    val = _action_cell_value(payload, title_case=title_case_action)
                elif k == "Action Type":
                    val = _format_action_label(val)
                elif k == "Performed By":
                    val = _performed_by_cell_value(payload)
                ref = f"{_col_letter(i)}{row_num}"
                if sig_col and i == sig_col and isinstance(val, str) and val.startswith("http"):
                    # Leave cell empty — drawing image floats on top
                    sig_placements.append((i - 1, row_num - 1, val))  # 0-based
                else:
                    _plain_cell(row_el, ref, str(val) if val is not None else "")
        row_num += 1

    # headerFooter (must precede <drawing> per schema order)
    hf_el = etree.SubElement(root, f"{SNS}headerFooter")
    if header_str:
        etree.SubElement(hf_el, f"{SNS}oddHeader").text = header_str
    if footer_str:
        etree.SubElement(hf_el, f"{SNS}oddFooter").text = footer_str

    # drawing reference placeholder — only added when signatures exist
    if sig_placements:
        drawing_el = etree.SubElement(root, f"{SNS}drawing")
        drawing_el.set(f"{{{REL_NS}}}id", "rId1")

    xml = _to_xml(root)
    return xml, sheet_name, sig_placements

# ── ZIP-level summary injection ───────────────────────────────────────────────
def _next_sheet_num(names):
    nums = [int(re.search(r'sheet(\d+)\.xml$', n).group(1))
            for n in names if re.match(r'^xl/worksheets/sheet\d+\.xml$', n)]
    return (max(nums) + 1) if nums else 1

def _next_seq(names, pattern):
    nums = [int(re.search(pattern, n).group(1))
            for n in names if re.search(pattern, n)]
    return (max(nums) + 1) if nums else 1

def _update_rels(data, next_num):
    root  = etree.fromstring(data)
    max_n = max(
        (int(re.search(r'(\d+)$', el.get("Id", "0")).group(1))
         for el in root), default=0)
    rid = f"rId{max_n + 1}"
    rel = etree.SubElement(root, f"{{{PKG_REL}}}Relationship")
    rel.set("Id", rid); rel.set("Type", WS_TYPE)
    rel.set("Target", f"worksheets/sheet{next_num}.xml")
    return rid, _to_xml(root)

def _update_workbook(data, sheet_name, next_num, rid):
    root   = etree.fromstring(data)
    sheets = root.find(f"{SNS}sheets")
    if sheets is None:
        sheets = etree.SubElement(root, f"{SNS}sheets")
    ids  = [int(s.get("sheetId", 0)) for s in sheets]
    s_el = etree.SubElement(sheets, f"{SNS}sheet")
    s_el.set("name", sheet_name)
    s_el.set("sheetId", str((max(ids) + 1) if ids else 1))
    s_el.set(f"{{{REL_NS}}}id", rid)
    return _to_xml(root)

def _update_content_types(data, sheet_num, drawing_num=None, img_exts=None):
    root  = etree.fromstring(data)
    existing_parts    = {el.get("PartName") for el in root}
    existing_defaults = {el.get("Extension") for el in root}

    sheet_part = f"/xl/worksheets/sheet{sheet_num}.xml"
    if sheet_part not in existing_parts:
        ov = etree.SubElement(root, f"{{{CT_NS}}}Override")
        ov.set("PartName", sheet_part); ov.set("ContentType", WS_CT)

    if drawing_num is not None:
        draw_part = f"/xl/drawings/drawing{drawing_num}.xml"
        if draw_part not in existing_parts:
            ov = etree.SubElement(root, f"{{{CT_NS}}}Override")
            ov.set("PartName", draw_part); ov.set("ContentType", DRAW_CT)

    for ext, ct in (img_exts or {}).items():
        if ext not in existing_defaults:
            df = etree.SubElement(root, f"{{{CT_NS}}}Default")
            df.set("Extension", ext); df.set("ContentType", ct)

    return _to_xml(root)

def _inject_summary(base_bytes, summary_xml, sheet_name, sig_placements):
    with zipfile.ZipFile(io.BytesIO(base_bytes)) as zin:
        names    = zin.namelist()
        next_num = _next_sheet_num(names)
        rels_raw = zin.read("xl/_rels/workbook.xml.rels")
        wb_raw   = zin.read("xl/workbook.xml")
        ct_raw   = zin.read("[Content_Types].xml")

    # ── Guard: check if summary sheet already exists ──────────────────────────
    wb_root = etree.fromstring(wb_raw)
    sheets_el = wb_root.find(f"{SNS}sheets")
    if sheets_el is not None:
        existing = [s for s in sheets_el if s.get("name") == sheet_name]
        if existing:
            return base_bytes   # already has summary, skip injection
    # ──────────────────────────────────────────────────────────────────────────

    rid, new_rels = _update_rels(rels_raw, next_num)
    new_wb        = _update_workbook(wb_raw, sheet_name, next_num, rid)

    # ── Download signature images ─────────────────────────────────────────────
    extra_files = {}   # zip_path -> bytes
    img_exts    = {}   # ext -> content-type
    draw_num    = None

    if sig_placements:
        with zipfile.ZipFile(io.BytesIO(base_bytes)) as zin:
            all_names = zin.namelist()
        draw_num  = _next_seq(all_names, r'drawing(\d+)\.xml')
        media_num = _next_seq(all_names, r'image(\d+)\.')

        anchors     = []   # (col, row, rid, cx_emu, cy_emu)
        media_names = []   # file names inside xl/media/

        for col, row, url in sig_placements:
            img_bytes, ext = _download_image(url)
            if img_bytes is None:
                continue
            cx, cy = _fit_signature_emu(img_bytes, SIG_MAX_W_EMU, SIG_MAX_H_EMU)
            media_name = f"image{media_num}.{ext}"
            media_num += 1
            rid_img    = f"rId{len(anchors) + 1}"
            extra_files[f"xl/media/{media_name}"] = img_bytes
            media_names.append(media_name)
            anchors.append((col, row, rid_img, cx, cy))
            img_exts[ext] = "image/jpeg" if ext == "jpeg" else "image/png"

        if anchors:
            extra_files[f"xl/drawings/drawing{draw_num}.xml"]              = _build_drawing_xml(anchors)
            extra_files[f"xl/drawings/_rels/drawing{draw_num}.xml.rels"]   = _build_drawing_rels(media_names)
            extra_files[f"xl/worksheets/_rels/sheet{next_num}.xml.rels"]   = _build_sheet_rels(draw_num)
        else:
            draw_num = None  # all downloads failed — cell stays blank, no broken drawing ref

    new_ct = _update_content_types(
        ct_raw, next_num,
        drawing_num=draw_num,
        img_exts=img_exts if img_exts else None,
    )

    # If all image downloads failed, strip the <drawing> element we added
    if sig_placements and draw_num is None:
        root_ws = etree.fromstring(summary_xml)
        draw_el = root_ws.find(f"{SNS}drawing")
        if draw_el is not None:
            root_ws.remove(draw_el)
        summary_xml = _to_xml(root_ws)

    new_path = f"xl/worksheets/sheet{next_num}.xml"
    out = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(base_bytes)) as zin, \
         zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if   item.filename == "xl/_rels/workbook.xml.rels": data = new_rels
            elif item.filename == "xl/workbook.xml":            data = new_wb
            elif item.filename == "[Content_Types].xml":        data = new_ct
            zout.writestr(item, data)
        zout.writestr(new_path, summary_xml)
        for path_, bytes_ in extra_files.items():
            zout.writestr(path_, bytes_)
    return out.getvalue()

# ── main ──────────────────────────────────────────────────────────────────────
def process(in_path, out_path, cfg_path):
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    header_enabled = _coerce_bool(cfg.get("headerEnabled"), True)
    footer_enabled = _coerce_bool(cfg.get("footerEnabled"), True)

    lh, ch, rh = build_header(cfg)
    lf, cf, rf = build_footer(cfg)
    lh = "" if not header_enabled else (str(lh) if lh else "")
    ch = "" if not header_enabled else (str(ch) if ch else "")
    rh = "" if not header_enabled else (str(rh) if rh else "")
    lf = "" if not footer_enabled else (str(lf) if lf else "")
    cf = "" if not footer_enabled else (str(cf) if cf else "")
    rf = "" if not footer_enabled else (str(rf) if rf else "")
    header_str = _compose(lh, ch, rh)
    footer_str = _compose(lf, cf, rf)

    with open(in_path, "rb") as f:
        in_bytes = f.read()

    # ── Step 1: patch headerFooter on every original sheet ───────────────────
    out_buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(in_bytes)) as zin, \
         zipfile.ZipFile(out_buf, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if SHEET_RE.match(item.filename):
                original_data = data
                try:
                    patched = _patch_sheet(data, header_str, footer_str,
                                           header_enabled, footer_enabled)
                    if _validate_worksheet_xml(patched):
                        data = patched
                    else:
                        print(f"Warning: headerFooter patch produced invalid XML for "
                              f"{item.filename}; keeping original sheet", file=sys.stderr)
                except Exception as e:
                    print(f"Warning: headerFooter patch skipped for "
                          f"{item.filename}: {e}", file=sys.stderr)
            zout.writestr(item, data)
    result = out_buf.getvalue()

    # ── Step 2: inject summary sheet if present ───────────────────────────────
    summary = cfg.get("documentSummary")
    if summary:
        summary_xml, sheet_name, sig_placements = _make_summary_sheet(
            summary, header_str, footer_str, cfg)
        if summary_xml is not None:
            result = _inject_summary(result, summary_xml, sheet_name, sig_placements)

    with open(out_path, "wb") as f:
        f.write(result)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: xlsx_lxml_master.py <in.xlsx> <out.xlsx> <config.json>")
        sys.exit(1)
    process(sys.argv[1], sys.argv[2], sys.argv[3])
`;

export function buildLxmlMasterScript(
  buildHeaderDef: string,
  buildFooterDef: string,
): string {
  return (
    PREFIX + "\n" + buildHeaderDef + "\n\n" + buildFooterDef + "\n" + SUFFIX
  );
}
