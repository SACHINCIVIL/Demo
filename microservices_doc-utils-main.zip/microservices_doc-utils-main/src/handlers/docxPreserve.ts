function parseBoolean(value: unknown): boolean | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const lower = value.trim().toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
  }
  return undefined;
}

/** True when the request explicitly provides a new text or image watermark. */
export function isWatermarkOverrideRequested(payload: unknown): boolean {
  if (!payload || typeof payload !== "object") return false;
  if (isWatermarkExplicitlyDisabled(payload)) return false;
  const body = payload as Record<string, unknown>;
  const text =
    typeof body.watermarkText === "string" ? body.watermarkText.trim() : "";
  if (text) return true;
  const logoEnable = parseBoolean(body.watermarkLogoEnable);
  const path = body.watermarkPath;
  return (
    logoEnable === true && typeof path === "string" && path.trim().length > 0
  );
}

export function isWatermarkExplicitlyDisabled(payload: unknown): boolean {
  if (!payload || typeof payload !== "object") return false;
  const body = payload as Record<string, unknown>;
  return parseBoolean(body.watermarkEnabled) === false;
}

/** Preserve existing watermark whenever the request is not actively replacing it. */
export function shouldPreserveWatermark(payload: unknown): boolean {
  return !isWatermarkOverrideRequested(payload);
}

const WATERMARK_MARKER =
  /PowerPlusWaterMarkObject|name="watermark-logo"|name='watermark-logo'|WordPictureWatermark|PictureWatermark|docPartGallery\s+w:val="Watermarks"/i;

/** Extract one balanced OOXML element (handles nested tags of the same name). */
function extractBalancedElement(
  xml: string,
  localName: string,
): { element: string; rest: string } | null {
  const openRe = new RegExp(`<${localName}(\\s[^>]*)?>`, "i");
  const openMatch = openRe.exec(xml);
  if (!openMatch || openMatch.index === undefined) return null;

  const start = openMatch.index;
  const openTagRe = new RegExp(`<${localName}(\\s[^>]*)?>`, "gi");
  const closeTagRe = new RegExp(`</${localName}>`, "gi");
  let depth = 0;
  let searchFrom = start;

  while (searchFrom < xml.length) {
    openTagRe.lastIndex = searchFrom;
    closeTagRe.lastIndex = searchFrom;
    const open = openTagRe.exec(xml);
    const close = closeTagRe.exec(xml);
    if (!close) return null;

    if (open && open.index <= close.index) {
      depth++;
      searchFrom = open.index + open[0].length;
      continue;
    }

    depth--;
    searchFrom = close.index + close[0].length;
    if (depth === 0) {
      return {
        element: xml.slice(start, searchFrom),
        rest: xml.slice(searchFrom),
      };
    }
  }
  return null;
}

/** True when a header part contains any known watermark construct. */
export function headerHasWatermark(headerXml: string): boolean {
  if (!headerXml) return false;
  if (WATERMARK_MARKER.test(headerXml)) return true;
  if (
    /<w:pict>/.test(headerXml) &&
    /mso-position-(?:vertical|horizontal)-relative:page/.test(headerXml)
  ) {
    return true;
  }
  if (/<wp:anchor\b/.test(headerXml) && /behindDoc="1"/.test(headerXml)) {
    return true;
  }
  return false;
}

/** Detect watermark paragraphs from our service, Word built-in, or page-relative VML/drawing. */
export function isWatermarkParagraph(block: string): boolean {
  if (!block || !/<w:p[\s>]/i.test(block)) return false;
  if (WATERMARK_MARKER.test(block)) return true;
  if (/<w:sdt>/.test(block) && /docPartGallery\s+w:val="Watermarks"/i.test(block)) {
    return true;
  }
  if (
    /<w:pict>/.test(block) &&
    /mso-position-(?:vertical|horizontal)-relative:page/.test(block)
  ) {
    return true;
  }
  if (/<wp:anchor\b/.test(block) && /behindDoc="1"/.test(block)) {
    return true;
  }
  if (/<wp:docPr[^>]*\bhidden="1"/.test(block)) {
    return true;
  }
  if (/<v:shape\b/.test(block) && /z-index:\s*-/.test(block)) {
    return true;
  }
  if (
    /<w:pict\b/.test(block) &&
    /<v:(?:shape|textpath)\b/i.test(block) &&
    /rotation:\s*-?\d+/i.test(block)
  ) {
    return true;
  }
  return false;
}

/** True when preserved watermark XML references embedded images. */
export function watermarkUsesImageRelationships(watermarkXml: string): boolean {
  return (
    /r:embed\s*=\s*"/.test(watermarkXml) ||
    /v:imagedata[^>]*\br:id\s*=\s*"/i.test(watermarkXml) ||
    /<a:blip[^>]*\br:embed\s*=\s*"/i.test(watermarkXml)
  );
}

export type HeaderPartSnapshot = {
  part: string;
  xml: string;
  relsXml: string;
};

/** Collect every header part path referenced in rels plus any header*.xml in the package. */
export function listHeaderPartPaths(
  relsXml: string,
  zipPartNames: string[],
  fallbackHeaderPart: string,
): string[] {
  const fromRels = findAllPartsFromRels(relsXml, "header");
  const fromZip = zipPartNames.filter((name) =>
    /^word\/header\d+\.xml$/i.test(name),
  );
  const base = fromRels.length > 0 ? fromRels : [fallbackHeaderPart];
  return [...new Set([...base, ...fromZip])];
}

/** Find watermark XML and its source header rels from pre-loaded snapshots. */
export function findPreservedWatermarkSnapshot(
  snapshots: HeaderPartSnapshot[],
): (HeaderPartSnapshot & { watermark: string }) | null {
  for (const snap of snapshots) {
    const watermark = extractWatermarkFromHeaderXml(snap.xml);
    if (watermark) return { ...snap, watermark };
  }
  return null;
}

/** True when document.xml uses a page background watermark. */
export function documentHasBackgroundWatermark(documentXml: string): boolean {
  if (!documentXml || !/<w:background\b/.test(documentXml)) return false;
  return (
    WATERMARK_MARKER.test(documentXml) ||
    /v:shape\b/i.test(documentXml) ||
    /opacity:/i.test(documentXml)
  );
}

/** Keep existing header image relationships and append any new ones. */
export function mergeHeaderRelationshipsXml(
  existingRelsXml: string,
  additionalRelXmlLines: string[],
): string {
  let merged = existingRelsXml.trim();
  if (!merged) {
    merged =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n</Relationships>';
  }
  if (!merged.includes("</Relationships>")) {
    merged += "\n</Relationships>";
  }
  let out = merged.replace("</Relationships>", "");
  for (const line of additionalRelXmlLines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const id = trimmed.match(/\bId="([^"]+)"/)?.[1];
    if (id && !merged.includes(`Id="${id}"`)) {
      out += `  ${trimmed}\n`;
    }
  }
  return `${out}</Relationships>`;
}

export function nextHeaderPartRelId(relsXml: string): string {
  const ids = Array.from(relsXml.matchAll(/Id="rId(\d+)"/g)).map((m) =>
    parseInt(m[1]!, 10),
  );
  const max = ids.length ? Math.max(...ids) : 0;
  return `rId${max + 1}`;
}

const WORD_SDT_WATERMARK_RE =
  /<w:sdt>[\s\S]*?<w:docPartGallery\s+w:val="Watermarks"[\s\S]*?<\/w:sdt>/gi;

/** Extract existing watermark paragraph(s) from a header part XML string. */
export function extractWatermarkFromHeaderXml(headerXml: string): string {
  if (!headerXml) return "";
  const watermarks: string[] = [];

  for (const match of headerXml.matchAll(WORD_SDT_WATERMARK_RE)) {
    if (match[0]) watermarks.push(match[0]);
  }
  if (watermarks.length > 0) return watermarks.join("\n");

  let rest = headerXml;
  const hdrOpen = rest.match(/<w:hdr\b[^>]*>/)?.[0] ?? "";
  if (hdrOpen) rest = rest.slice(hdrOpen.length);

  while (rest.trim()) {
    const extracted = extractBalancedElement(rest, "w:p");
    if (!extracted) break;
    if (isWatermarkParagraph(extracted.element)) {
      watermarks.push(extracted.element);
    }
    rest = extracted.rest;
  }
  return watermarks.join("\n");
}

/** Find the first header part that contains a watermark. */
export function findWatermarkInHeaderParts(
  parts: { part: string; xml: string }[],
): { part: string; watermark: string } | null {
  for (const { part, xml } of parts) {
    const watermark = extractWatermarkFromHeaderXml(xml);
    if (watermark) return { part, watermark };
  }
  return null;
}

/** Remove orphan VML/drawing watermark fragments left outside paragraph blocks. */
function stripOrphanWatermarkFragments(xml: string): string {
  let out = xml;
  out = out.replace(
    /<v:shape[^>]*\bid="PowerPlusWaterMarkObject\d+"[^>]*>[\s\S]*?<\/v:shape>\s*/gi,
    "",
  );
  out = out.replace(
    /<w:pict\b[^>]*>[\s\S]*?PowerPlusWaterMarkObject[\s\S]*?<\/w:pict>\s*/gi,
    "",
  );
  out = out.replace(
    /<wp:anchor\b[^>]*>[\s\S]*?behindDoc="1"[\s\S]*?<\/wp:anchor>\s*/gi,
    "",
  );
  return out;
}

/** Remove all watermark content from a header part without breaking nested paragraphs. */
export function removeWatermarkFromHeaderXml(headerXml: string): string {
  if (!headerXml) return headerXml;

  let result = headerXml.replace(
    /<w:sdt>[\s\S]*?<w:docPartGallery\s+w:val="Watermarks"[\s\S]*?<\/w:sdt>\s*/gi,
    "",
  );

  const hdrMatch = result.match(/^(?<prefix>[\s\S]*?<w:hdr\b[^>]*>)(?<body>[\s\S]*)(?<suffix><\/w:hdr>[\s\S]*)$/i);
  const { prefix, body: rawBody, suffix } = hdrMatch?.groups ?? {};
  if (!prefix || rawBody === undefined || !suffix) {
    return stripOrphanWatermarkFragments(result);
  }

  let body = rawBody;
  let changed = true;
  while (changed) {
    changed = false;
    let offset = 0;
    while (offset < body.length) {
      const tail = body.slice(offset);
      const extracted = extractBalancedElement(tail, "w:p");
      if (!extracted) break;
      const absStart = offset + tail.indexOf(extracted.element);
      if (isWatermarkParagraph(extracted.element)) {
        body =
          body.slice(0, absStart) +
          body.slice(absStart + extracted.element.length);
        changed = true;
        break;
      }
      offset = absStart + extracted.element.length;
    }
  }

  body = stripOrphanWatermarkFragments(body);
  result = `${prefix}${body}${suffix}`;
  return stripOrphanWatermarkFragments(result);
}

/** Remove document-level background watermark if present. */
export function removeDocumentBackgroundWatermark(documentXml: string): string {
  if (!documentXml || !/<w:background\b/.test(documentXml)) {
    return documentXml;
  }
  return documentXml.replace(/<w:background[\s\S]*?<\/w:background>\s*/g, "");
}

/** Insert watermark XML immediately after the opening <w:hdr> tag. */
export function injectWatermarkIntoHeaderXml(
  headerXml: string,
  watermarkXml: string,
): string {
  const trimmed = watermarkXml.trim();
  if (!trimmed) return headerXml;
  return headerXml.replace(/(<w:hdr[^>]*>)/, (open) => `${open}\n    ${trimmed}`);
}

function relTargetPath(target: string): string {
  const normalized = target.replace(/^\//, "");
  return normalized.startsWith("word/") ? normalized : `word/${normalized}`;
}

function collectPartsFromRels(
  relsXml: string,
  kind: "header" | "footer",
): string[] {
  const typePattern = kind === "header" ? /\/header"/ : /\/footer"/;
  const parts: string[] = [];
  const relRegex = /<Relationship\b[^>]*\/>/g;
  let match: RegExpExecArray | null;
  while ((match = relRegex.exec(relsXml)) !== null) {
    const rel = match[0];
    if (!typePattern.test(rel)) continue;
    const targetMatch = rel.match(/\bTarget="([^"]+)"/);
    if (targetMatch?.[1]) {
      parts.push(relTargetPath(targetMatch[1]));
    }
  }
  return [...new Set(parts)];
}

/** Resolve the first header or footer part path from document.xml.rels. */
export function findPartFromRels(
  relsXml: string,
  kind: "header" | "footer",
): string | null {
  const parts = collectPartsFromRels(relsXml, kind);
  return parts[0] ?? null;
}

/** Resolve every distinct header or footer part referenced in document.xml.rels. */
export function findAllPartsFromRels(
  relsXml: string,
  kind: "header" | "footer",
): string[] {
  return collectPartsFromRels(relsXml, kind);
}

export function headerRelsPartPath(headerPart: string): string {
  const name = headerPart.replace(/^word\//, "");
  return `word/_rels/${name}.rels`;
}

export type DocxSectionFlags = {
  headerEnabled: boolean;
  footerEnabled: boolean;
  watermarkEnabled: boolean | undefined;
  watermarkOverride: boolean;
  watermarkPreserve: boolean;
  watermarkDisabled: boolean;
};

export function getDocxSectionFlags(body: unknown): DocxSectionFlags {
  const payload = (body || {}) as Record<string, unknown>;
  const watermarkEnabled = parseBoolean(payload.watermarkEnabled);
  return {
    headerEnabled: !!payload.headerEnabled,
    footerEnabled: !!payload.footerEnabled,
    watermarkEnabled,
    watermarkOverride: isWatermarkOverrideRequested(payload),
    watermarkPreserve: shouldPreserveWatermark(payload),
    watermarkDisabled: watermarkEnabled === false,
  };
}
