# vsdxprocessor

Python microservice that converts Visio `.vsdx` files to native draw.io XML using the `vsdx` library (preserves colours and Shape Data better than draw.io's built-in importer).

## CLI (batch)

```bash
pip install -r requirements.txt
python run.py diagrams/network.vsdx -o ./output
```

## REST API

```bash
pip install -r requirements.txt
python server.py
```

| Method | Path | Body | Response |
|--------|------|------|----------|
| `GET` | `/health` | — | `{ "status": "ok", "service": "vsdx2drawio" }` |
| `POST` | `/convertToDrawio` | JSON `{ "base64": "<vsdx bytes>" }` or multipart `file` | `{ "ok", "xml", "shapesConverted", "shapesTotal", "warnings" }` |

## Docker

```bash
docker compose up -d --build
curl http://localhost:3002/health
```

Default port: **3002** (xmltovsdx uses 3001).

## Smart Docs integration

When a user opens a `.vsdx` / `.vsd` for **edit** in draw.io, the web app calls this service first, then loads the returned XML into the editor.

Configure in Smart GFSI `appConfig`:

```json
"vsdxProcessorUrl": "http://YOUR_VM:3002/convertToDrawio"
```
