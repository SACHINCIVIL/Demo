"""
converter.py - Convert Visio .vsdx files into native draw.io (.drawio) XML.

Strategy (Option B): parse the VSDX with the `vsdx` library and emit
draw.io mxGraphModel XML directly, so shape colours and Shape Data
survive instead of being dropped by draw.io's built-in importer.

Safety design:
  * The source .vsdx is only ever READ. It is never modified.
  * Every shape that cannot be fully mapped is logged, not silently dropped.
  * The generated XML is parsed back (validated) before being written.
  * If validation fails, the output is rejected and the file is flagged.
"""

from __future__ import annotations

import html
import logging
from dataclasses import dataclass, field
from pathlib import Path
from xml.etree import ElementTree as ET

try:
    from vsdx import VisioFile
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "The 'vsdx' library is required. Install with:\n"
        "    pip install vsdx\n"
        f"(import error: {exc})"
    )

log = logging.getLogger("vsdx2drawio")


# --------------------------------------------------------------------------- #
# Result container
# --------------------------------------------------------------------------- #
@dataclass
class ConversionResult:
    source: Path
    output: Path | None = None
    ok: bool = False
    shapes_total: int = 0
    shapes_converted: int = 0
    warnings: list[str] = field(default_factory=list)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)
        log.warning(msg)


# --------------------------------------------------------------------------- #
# Colour helpers
# --------------------------------------------------------------------------- #
def _clean_colour(value: str | None) -> str | None:
    """Return a '#rrggbb' string if value looks like a usable colour, else None.

    Visio sometimes stores theme indices (e.g. themed=... or an int) rather
    than a literal hex colour. Those cannot be resolved reliably here, so we
    return None and let the caller log/skip.
    """
    if not value:
        return None
    v = value.strip()
    if v.startswith("#") and len(v) in (4, 7):
        return v
    # Bare 6-hex-digit string without a leading '#'
    if len(v) == 6:
        try:
            int(v, 16)
            return "#" + v
        except ValueError:
            return None
    return None


def _cell_value(shape, name: str) -> str | None:
    """Safely read a Visio Cell value from a shape by cell name."""
    try:
        # vsdx exposes cells via .cells (dict-like) in recent versions
        cells = getattr(shape, "cells", None)
        if cells and name in cells:
            cell = cells[name]
            return getattr(cell, "value", None) or getattr(cell, "V", None)
    except Exception:  # noqa: BLE001 - defensive: never crash on one cell
        return None
    return None


# --------------------------------------------------------------------------- #
# draw.io style string builder
# --------------------------------------------------------------------------- #
def _build_style(shape, result: ConversionResult) -> str:
    parts = ["rounded=0", "whiteSpace=wrap", "html=1"]

    fill = _clean_colour(_cell_value(shape, "FillForegnd"))
    if fill:
        parts.append(f"fillColor={fill}")
    else:
        # keep default; note when a fill existed but wasn't a literal colour
        raw = _cell_value(shape, "FillForegnd")
        if raw:
            result.warn(
                f"shape {getattr(shape, 'ID', '?')}: fill '{raw}' not a literal "
                f"colour (likely themed) - used default fill"
            )

    line = _clean_colour(_cell_value(shape, "LineColor"))
    if line:
        parts.append(f"strokeColor={line}")

    return ";".join(parts) + ";"


# --------------------------------------------------------------------------- #
# Shape Data (custom properties) -> draw.io <object> attributes
# --------------------------------------------------------------------------- #
def _collect_data_properties(shape, result: ConversionResult) -> dict[str, str]:
    data: dict[str, str] = {}
    try:
        props = getattr(shape, "data_properties", None)
        if not props:
            return data
        # data_properties is a dict-like of {name: ShapeProperty}
        for key, prop in props.items():
            val = getattr(prop, "value", None)
            label = getattr(prop, "label", None) or key
            if val is not None:
                data[str(label)] = str(val)
    except Exception as exc:  # noqa: BLE001
        result.warn(
            f"shape {getattr(shape, 'ID', '?')}: could not read Shape Data ({exc})"
        )
    return data


# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #
def _geometry(shape) -> tuple[float, float, float, float]:
    """Return (x, y, w, h) in draw.io pixel space.

    Visio uses inches with origin at bottom-left. We scale by 72 (px/inch)
    and flip Y so the diagram is right-way-up in draw.io (origin top-left).
    Missing values fall back to sane defaults.
    """
    scale = 72.0

    def num(v, default):
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    w = num(_cell_value(shape, "Width"), 1.0) * scale
    h = num(_cell_value(shape, "Height"), 0.5) * scale
    # PinX/PinY is the centre of the shape in Visio
    cx = num(_cell_value(shape, "PinX"), 0.0) * scale
    cy = num(_cell_value(shape, "PinY"), 0.0) * scale
    x = cx - w / 2.0
    # flip Y: use a large canvas height then subtract; keep simple positive space
    y = -(cy + h / 2.0)
    return x, y, w, h


# --------------------------------------------------------------------------- #
# XML building
# --------------------------------------------------------------------------- #
def _add_shape_cell(root: ET.Element, shape, result: ConversionResult) -> None:
    sid = f"s{getattr(shape, 'ID', id(shape))}"
    text = (getattr(shape, "text", "") or "").strip()
    style = _build_style(shape, result)
    x, y, w, h = _geometry(shape)

    data = _collect_data_properties(shape, result)

    geom_attrs = {
        "x": f"{x:.2f}", "y": f"{y:.2f}",
        "width": f"{w:.2f}", "height": f"{h:.2f}",
        "as": "geometry",
    }

    if data:
        # draw.io stores custom data by wrapping the mxCell in an <object>
        obj = ET.SubElement(root, "object")
        obj.set("id", sid)
        obj.set("label", text)
        for k, v in data.items():
            # attribute names can't contain spaces/reserved chars in XML;
            # draw.io tolerates most, but sanitise lightly
            safe_k = k.replace(" ", "_")
            obj.set(safe_k, v)
        cell = ET.SubElement(obj, "mxCell")
        cell.set("style", style)
        cell.set("vertex", "1")
        cell.set("parent", "1")
        ET.SubElement(cell, "mxGeometry", geom_attrs)
    else:
        cell = ET.SubElement(root, "mxCell")
        cell.set("id", sid)
        cell.set("value", text)
        cell.set("style", style)
        cell.set("vertex", "1")
        cell.set("parent", "1")
        ET.SubElement(cell, "mxGeometry", geom_attrs)

    result.shapes_converted += 1


def _iter_shapes(page):
    """Yield all shapes on a page, descending into groups where possible."""
    shapes = getattr(page, "shapes", []) or []
    stack = list(shapes)
    while stack:
        s = stack.pop()
        yield s
        child = getattr(s, "child_shapes", None) or getattr(s, "shapes", None)
        if child:
            stack.extend(child)


# --------------------------------------------------------------------------- #
# Public entry point
# --------------------------------------------------------------------------- #
def convert(src: str | Path, out_dir: str | Path) -> ConversionResult:
    src = Path(src)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    result = ConversionResult(source=src)

    if not src.exists():
        result.warn(f"source not found: {src}")
        return result

    mxfile = ET.Element("mxfile", {"host": "vsdx2drawio", "type": "device"})

    try:
        # VisioFile opens read-only; we never call save_vsdx on it.
        with VisioFile(str(src)) as vis:
            pages = getattr(vis, "pages", []) or []
            if not pages:
                result.warn("no pages found in file")
            for pidx, page in enumerate(pages):
                pname = getattr(page, "name", f"Page-{pidx + 1}")
                diagram = ET.SubElement(
                    mxfile, "diagram",
                    {"id": f"page{pidx}", "name": str(pname)},
                )
                model = ET.SubElement(diagram, "mxGraphModel", {
                    "dx": "800", "dy": "600", "grid": "1", "gridSize": "10",
                    "guides": "1", "tooltips": "1", "connect": "1",
                    "arrows": "1", "fold": "1", "page": "1",
                    "pageWidth": "850", "pageHeight": "1100",
                    "math": "0", "shadow": "0",
                })
                root = ET.SubElement(model, "root")
                # two mandatory base cells in every draw.io model
                ET.SubElement(root, "mxCell", {"id": "0"})
                ET.SubElement(root, "mxCell", {"id": "1", "parent": "0"})

                for shape in _iter_shapes(page):
                    result.shapes_total += 1
                    try:
                        _add_shape_cell(root, shape, result)
                    except Exception as exc:  # noqa: BLE001
                        result.warn(
                            f"shape {getattr(shape, 'ID', '?')} on '{pname}' "
                            f"skipped ({exc})"
                        )
    except Exception as exc:  # noqa: BLE001
        result.warn(f"failed to parse '{src.name}': {exc}")
        return result

    # ---- serialise + validate before writing ----
    xml_bytes = ET.tostring(mxfile, encoding="utf-8", xml_declaration=True)
    try:
        ET.fromstring(xml_bytes)  # round-trip validation
    except ET.ParseError as exc:
        result.warn(f"generated XML failed validation, output rejected ({exc})")
        return result

    out_path = out_dir / (src.stem + ".drawio")
    out_path.write_bytes(xml_bytes)
    result.output = out_path
    result.ok = True
    log.info(
        "converted %s -> %s (%d/%d shapes)",
        src.name, out_path.name,
        result.shapes_converted, result.shapes_total,
    )
    return result
