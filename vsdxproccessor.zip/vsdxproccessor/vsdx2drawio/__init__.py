"""vsdx2drawio - convert Visio .vsdx files to native draw.io XML (Option B)."""
from .converter import convert, ConversionResult

__all__ = ["convert", "ConversionResult"]
__version__ = "0.1.0"
