#!/usr/bin/env python3
"""
run.py - Batch-convert Visio .vsdx files to draw.io XML.

Usage:
    python run.py <input>              # a single .vsdx file OR a folder
    python run.py <input> -o outdir    # choose output folder (default: ./output)

Examples:
    python run.py diagrams/network.vsdx
    python run.py ./visio_files -o ./drawio_files

Originals are never modified. A summary report is printed and also written
to <outdir>/conversion_report.txt so you can see exactly what happened to
each file and each shape.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from vsdx2drawio.converter import convert, ConversionResult


def _gather_inputs(target: Path) -> list[Path]:
    if target.is_dir():
        return sorted(target.glob("*.vsdx"))
    if target.suffix.lower() == ".vsdx":
        return [target]
    return []


def _write_report(results: list[ConversionResult], out_dir: Path) -> None:
    lines: list[str] = ["VSDX -> draw.io conversion report", "=" * 40, ""]
    ok = sum(1 for r in results if r.ok)
    lines.append(f"Files processed : {len(results)}")
    lines.append(f"Succeeded       : {ok}")
    lines.append(f"Failed          : {len(results) - ok}")
    lines.append("")
    for r in results:
        status = "OK " if r.ok else "FAIL"
        out = r.output.name if r.output else "-"
        lines.append(f"[{status}] {r.source.name} -> {out} "
                     f"({r.shapes_converted}/{r.shapes_total} shapes)")
        for w in r.warnings:
            lines.append(f"        ! {w}")
    report = "\n".join(lines) + "\n"
    (out_dir / "conversion_report.txt").write_text(report, encoding="utf-8")
    print("\n" + report)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Convert .vsdx to draw.io XML")
    parser.add_argument("input", help="a .vsdx file or a folder of them")
    parser.add_argument("-o", "--output", default="output",
                        help="output directory (default: ./output)")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(levelname)s %(message)s",
    )

    target = Path(args.input)
    out_dir = Path(args.output)

    inputs = _gather_inputs(target)
    if not inputs:
        print(f"No .vsdx files found at: {target}", file=sys.stderr)
        return 1

    results = [convert(p, out_dir) for p in inputs]
    _write_report(results, out_dir)

    # non-zero exit if anything failed, useful for scripting
    return 0 if all(r.ok for r in results) else 2


if __name__ == "__main__":
    raise SystemExit(main())
