"""
REST API microservice: VSDX → draw.io XML (mxfile).

Endpoints:
  GET  /health           → service status
  POST /convertToDrawio  → JSON { "base64": "..." } or multipart file field "file"
                           Returns JSON { xml, ok, shapesConverted, shapesTotal, warnings }
"""

from __future__ import annotations

import base64
import logging
import os
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from vsdx2drawio.converter import convert

log = logging.getLogger("vsdx2drawio.api")

PORT = int(os.environ.get("PORT", "3002"))
MAX_UPLOAD_BYTES = int(os.environ.get("MAX_UPLOAD_BYTES", str(50 * 1024 * 1024)))

app = FastAPI(title="VSDX Processor", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Base64Payload(BaseModel):
    base64: str = Field(..., description="Base64-encoded .vsdx file bytes")


class ConvertResponse(BaseModel):
    ok: bool
    xml: str | None = None
    shapesConverted: int = 0
    shapesTotal: int = 0
    warnings: list[str] = []


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "vsdx2drawio"}


def _run_conversion(vsdx_bytes: bytes) -> ConvertResponse:
    if not vsdx_bytes:
        raise HTTPException(status_code=400, detail="Empty VSDX payload")
    if len(vsdx_bytes) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="VSDX file exceeds size limit")

    with tempfile.TemporaryDirectory(prefix="vsdx2drawio_") as work_dir:
        work_path = Path(work_dir)
        src = work_path / "input.vsdx"
        src.write_bytes(vsdx_bytes)

        result = convert(src, work_path)
        if not result.ok or not result.output:
            raise HTTPException(
                status_code=422,
                detail={
                    "message": "VSDX conversion failed",
                    "warnings": result.warnings,
                    "shapesConverted": result.shapes_converted,
                    "shapesTotal": result.shapes_total,
                },
            )

        xml = result.output.read_text(encoding="utf-8")
        return ConvertResponse(
            ok=True,
            xml=xml,
            shapesConverted=result.shapes_converted,
            shapesTotal=result.shapes_total,
            warnings=result.warnings,
        )


@app.post("/convertToDrawio", response_model=ConvertResponse)
async def convert_to_drawio(
    request: Request,
    file: UploadFile | None = File(None),
) -> ConvertResponse:
    content_type = (request.headers.get("content-type") or "").lower()
    vsdx_bytes: bytes | None = None

    if file is not None:
        vsdx_bytes = await file.read()
    elif "application/json" in content_type:
        payload = Base64Payload.model_validate(await request.json())
        try:
            vsdx_bytes = base64.b64decode(payload.base64, validate=True)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=f"Invalid base64 payload: {exc}") from exc
    else:
        raw = await request.body()
        if raw:
            vsdx_bytes = raw

    if vsdx_bytes is None:
        raise HTTPException(
            status_code=400,
            detail="Provide multipart field 'file', JSON { base64 }, or raw .vsdx body",
        )

    return _run_conversion(vsdx_bytes)


if __name__ == "__main__":
    import uvicorn

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    uvicorn.run("server:app", host="0.0.0.0", port=PORT, log_level="info")
