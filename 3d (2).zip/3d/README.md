# 3D Facility Marker Platform (POC)

Industry-aligned proof-of-concept for **EMP-style** facility layout tools: floor plans, 3D models, markers, and a custom shape library.

## Run

```bash
cd C:\Users\LENOVO\OneDrive\Desktop\3d
npm install
npm run dev
```

## Supported assets

| Mode | Formats | Viewer | Industry pattern |
|------|---------|--------|------------------|
| **Floor plan** | PNG, JPG, JPEG, WebP | Orthographic top-down, pan + zoom | CAD / FM plan view (Autodesk, Matterport 2D) |
| **3D model** | GLB, GLTF | Perspective orbit | Digital twin / BIM web viewer |

## Why images looked broken (fixed)

Floor plan PNG/JPEG must use **unlit materials** (`meshBasicMaterial`), not PBR lighting. Lit materials on a flat plane appear black when viewed at an angle. The app now uses:

- **Plan view** — orthographic camera, locked to top-down
- **Unlit texture** — image always renders at full brightness
- **White mat** behind the plan — no dark bleed-through

## Architecture (industry alignment)

```
┌─────────────────────────────────────────────────────────────┐
│  Asset layer     GLB/GLTF (3D)  |  PNG/JPEG (2D floor plan)   │
├─────────────────────────────────────────────────────────────┤
│  Viewer layer    ModelViewer    |  FloorPlanViewer           │
│                  orbit 3D       |  orthographic plan         │
├─────────────────────────────────────────────────────────────┤
│  Annotation      Markers + custom shape library              │
├─────────────────────────────────────────────────────────────┤
│  Interaction     click · hover · zoom/pan · placement        │
└─────────────────────────────────────────────────────────────┘
```

### Roadmap to production (EMP / facility management)

| Phase | Feature | Industry reference |
|-------|---------|-------------------|
| **Now (POC)** | GLB + PNG, markers, shapes, export JSON | Custom R3F viewer |
| **Next** | Zones, layers, marker types from EMP | Smart EMP / draw.io parity |
| **Future** | IFC/BIM import | That Open / web-ifc |
| **Future** | Sensor overlays, status colors | Digital twin FM tools |

## Shape library

Right panel → **Advanced — Shape Library**

- **Basic:** Box, Sphere, Cylinder, Cone
- **Advanced:** Rectangle, Ring, Capsule, Diamond, Arrow
- **Equipment:** Drain, Tank, Traffic

## EMP module parity (current vs target)

| EMP (draw.io) | This POC |
|---------------|----------|
| Upload floor plan image | ✅ PNG/JPEG plan view |
| Upload / view 3D | ✅ GLB orbit view |
| Marker name + type | ✅ |
| Click / hover | ✅ |
| Zoom / pan | ✅ |
| Shape library | ✅ Custom 3D shapes |
| Traffic paths on diagram | 🔜 Phase 2 |
| Zones / layers | 🔜 Phase 2 |
| S3 / API persistence | 🔜 Phase 3 |
| IFC / Revit BIM | 🔜 Phase 4 |
