import { useCallback, useEffect, useState } from 'react';
import MarkerDetailsDialog from './components/MarkerDetailsDialog';
import MarkerPlacementDialog from './components/MarkerPlacementDialog';
import PropertiesPanel from './components/PropertiesPanel';
import Scene3D from './components/Scene3D';
import SceneSidebar from './components/SceneSidebar';
import ShapeDetailsDialog from './components/ShapeDetailsDialog';
import ShapeLibraryPanel from './components/ShapeLibraryPanel';
import Toolbar from './components/Toolbar';
import ValidationBanner from './components/ValidationBanner';
import { useSceneState } from './hooks/useSceneState';
import { isMarkerOnTrafficPath } from './utils/trafficPathUtils';
import {
  TRAFFIC_PATH_SNAP_THRESHOLD,
  snapPointToTrafficPath,
  validateTrafficMarkersOnPaths,
} from './utils/trafficPathUtils';
import './App.css';

const TRAFFIC_PATH_ERROR =
  'Each marker must be placed on the yellow traffic path. Select a point on the traffic path.';

export default function App() {
  const scene = useSceneState();
  const [markerDialogOpen, setMarkerDialogOpen] = useState(false);
  const [shapeDialogOpen, setShapeDialogOpen] = useState(false);
  const [placementDialogOpen, setPlacementDialogOpen] = useState(false);
  const [pendingMarkerPosition, setPendingMarkerPosition] = useState(null);
  const [pendingTrafficPathId, setPendingTrafficPathId] = useState(null);
  const [trafficMarkerMode, setTrafficMarkerMode] = useState(false);
  const [focusMarkerId, setFocusMarkerId] = useState(null);
  const [validationError, setValidationError] = useState(null);

  const showValidation = useCallback((message) => {
    setValidationError(message);
    window.setTimeout(() => setValidationError(null), 4500);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.matches('input, textarea, select')) return;
      if (e.key === 'Delete' && scene.selectedShapeId) scene.removeShape(scene.selectedShapeId);
      if (e.key === 'Delete' && scene.selectedMarkerId) scene.removeMarker(scene.selectedMarkerId);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [scene]);

  const handleSurfacePlace = useCallback(
    (position, rotation) => {
      if (scene.placementMode === 'marker') {
        setPendingMarkerPosition(position);
        setPendingTrafficPathId(null);
        setTrafficMarkerMode(false);
        setPlacementDialogOpen(true);
        scene.cancelPlacement();
      } else if (scene.placementMode === 'shape' && scene.activeShapeType) {
        scene.placeShapeAt(position, scene.activeShapeType, rotation);
        scene.cancelPlacement();
      }
    },
    [scene]
  );

  const handleTrafficMarkerPlace = useCallback(
    (point) => {
      const path = scene.activeTrafficPath;
      if (!path) {
        showValidation('Select a traffic flow path first.');
        scene.cancelPlacement();
        return;
      }

      const isModel = scene.asset?.type === 'model';
      const snap = snapPointToTrafficPath(
        path,
        point.x,
        point.y,
        isModel ? 0.32 : TRAFFIC_PATH_SNAP_THRESHOLD,
        isModel ? point.z : null
      );

      if (!snap) {
        showValidation(TRAFFIC_PATH_ERROR);
        return;
      }

      setPendingMarkerPosition([snap.x, snap.y, snap.z + 0.04]);
      setPendingTrafficPathId(path.id);
      setTrafficMarkerMode(true);
      setPlacementDialogOpen(true);
      scene.cancelPlacement();
    },
    [scene, showValidation]
  );

  const confirmMarkerPlacement = useCallback(
    ({ name, type }) => {
      if (!pendingMarkerPosition) return;

      const markerType = trafficMarkerMode ? 'trafficFlow' : type;
      const extras = {};
      if (trafficMarkerMode && pendingTrafficPathId) {
        extras.trafficPathId = pendingTrafficPathId;
      }

      const marker = scene.addMarker(pendingMarkerPosition, name, markerType, extras);
      setPendingMarkerPosition(null);
      setPendingTrafficPathId(null);
      setTrafficMarkerMode(false);
      setPlacementDialogOpen(false);
      setFocusMarkerId(marker.id);
    },
    [pendingMarkerPosition, pendingTrafficPathId, trafficMarkerMode, scene]
  );

  const handleExport = useCallback(() => {
    if (!validateTrafficMarkersOnPaths(scene.markers, scene.trafficPaths)) {
      showValidation(TRAFFIC_PATH_ERROR);
      return;
    }

    const payload = {
      version: 1,
      asset: scene.asset
        ? { type: scene.asset.type, fileName: scene.asset.fileName }
        : null,
      objects: {
        markers: scene.markers,
        shapes: scene.shapes,
        trafficPaths: scene.trafficPaths,
      },
      editor: { transformMode: scene.transformMode, snapToGrid: scene.snapToGrid, gridSize: scene.gridSize },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'scene-export.json';
    a.click();
    URL.revokeObjectURL(url);
  }, [scene, showValidation]);

  const selectMarker = useCallback(
    (id, { openDialog = false } = {}) => {
      if (!id) return;
      scene.setSelectedShapeId(null);
      scene.setSelectedTrafficPathId(null);
      scene.setSelectedMarkerId(id);
      setFocusMarkerId(id);
      if (openDialog) setMarkerDialogOpen(true);
    },
    [scene]
  );

  const selectShape = useCallback(
    (id, { openDialog = false } = {}) => {
      scene.setSelectedMarkerId(null);
      scene.setSelectedTrafficPathId(null);
      scene.setSelectedShapeId(id);
      if (openDialog) setShapeDialogOpen(true);
    },
    [scene]
  );

  const handleSaveMarker = useCallback(
    (id, patch) => {
      const marker = scene.markers.find((m) => m.id === id);
      const next = { ...marker, ...patch };
      if (next.type === 'trafficFlow' && next.trafficPathId) {
        const path = scene.trafficPaths.find((p) => p.id === next.trafficPathId);
        if (!isMarkerOnTrafficPath(next, path)) {
          showValidation(TRAFFIC_PATH_ERROR);
          return false;
        }
      }
      scene.updateMarker(id, patch);
      return true;
    },
    [scene, showValidation]
  );

  return (
    <div className="app-root">
      <Toolbar
        onUpload={scene.loadAssetFile}
        onReset={scene.resetScene}
        hasAsset={Boolean(scene.asset)}
        assetFileName={scene.asset?.fileName}
        assetType={scene.asset?.type}
        onExport={handleExport}
      />

      <ValidationBanner message={validationError} onDismiss={() => setValidationError(null)} />

      <div className="app-body">
        <SceneSidebar
          markers={scene.markers}
          shapes={scene.shapes}
          trafficPaths={scene.trafficPaths}
          selectedMarkerId={scene.selectedMarkerId}
          selectedShapeId={scene.selectedShapeId}
          selectedTrafficPathId={scene.selectedTrafficPathId}
          placementMode={scene.placementMode}
          draftTrafficPathPoints={scene.draftTrafficPathPoints}
          onMarkerSelect={(id) => selectMarker(id, { openDialog: true })}
          onShapeSelect={(id) => selectShape(id, { openDialog: true })}
          onHierarchySelectMarker={(id) => selectMarker(id)}
          onHierarchySelectShape={(id) => selectShape(id)}
          onTrafficPathSelect={scene.setSelectedTrafficPathId}
          onToggleMarkerPlacement={() => {
            if (scene.placementMode === 'marker') scene.cancelPlacement();
            else {
              scene.cancelPlacement();
              scene.startMarkerPlacement();
            }
          }}
          onStartTrafficPathDraw={scene.startTrafficPathDraw}
          onFinishTrafficPath={() => scene.finishTrafficPath()}
          onCancelTrafficPathDraw={scene.cancelTrafficPathDraw}
          onStartTrafficMarkerPlacement={(pathId) => scene.startTrafficMarkerPlacement(pathId)}
          onRemoveMarker={scene.removeMarker}
          onRemoveShape={scene.removeShape}
          onRemoveTrafficPath={scene.removeTrafficPath}
          hasAsset={Boolean(scene.asset)}
        />

        <div className="canvas-wrap">
          <Scene3D
            asset={scene.asset}
            markers={scene.markers}
            shapes={scene.shapes}
            trafficPaths={scene.trafficPaths}
            draftTrafficPathPoints={scene.draftTrafficPathPoints}
            selectedTrafficPathId={scene.selectedTrafficPathId}
            selectedMarkerId={scene.selectedMarkerId}
            selectedShapeId={scene.selectedShapeId}
            hoveredMarkerId={scene.hoveredMarkerId}
            hoveredShapeId={scene.hoveredShapeId}
            placementMode={scene.placementMode}
            activeShapeType={scene.activeShapeType}
            focusMarkerId={focusMarkerId}
            onSurfacePlace={handleSurfacePlace}
            onTrafficPathPointAdd={scene.addTrafficPathPoint}
            onTrafficMarkerPlace={handleTrafficMarkerPlace}
            onMarkerSelect={(id) => selectMarker(id)}
            onShapeSelect={(id) => selectShape(id)}
            onMarkerHover={scene.setHoveredMarkerId}
            onMarkerLeave={() => scene.setHoveredMarkerId(null)}
            onShapeHover={scene.setHoveredShapeId}
            onShapeLeave={() => scene.setHoveredShapeId(null)}
            clearSelection={() => {
              scene.setSelectedMarkerId(null);
              scene.setSelectedShapeId(null);
            }}
          />
        </div>

        <div className="app-right-column">
          <PropertiesPanel
            selectedShape={scene.selectedShape}
            selectedMarker={scene.selectedMarker}
            onUpdateShape={scene.updateShape}
            onUpdateMarker={handleSaveMarker}
            onDuplicateShape={scene.duplicateShape}
            onDuplicateMarker={scene.duplicateMarker}
            onDeleteShape={scene.removeShape}
            onDeleteMarker={scene.removeMarker}
          />
          <ShapeLibraryPanel
            hasAsset={Boolean(scene.asset)}
            placementMode={scene.placementMode}
            activeShapeType={scene.activeShapeType}
            onSelectShape={(shapeType) => {
              if (scene.placementMode === 'shape' && scene.activeShapeType === shapeType) {
                scene.cancelPlacement();
              } else {
                scene.cancelPlacement();
                scene.startShapePlacement(shapeType);
              }
            }}
            onCancelPlacement={scene.cancelPlacement}
          />
        </div>
      </div>

      <MarkerPlacementDialog
        open={placementDialogOpen}
        defaultName={
          trafficMarkerMode
            ? `Traffic point ${scene.markers.filter((m) => m.type === 'trafficFlow').length + 1}`
            : `Marker ${scene.markers.length + 1}`
        }
        trafficOnly={trafficMarkerMode}
        onCancel={() => {
          setPlacementDialogOpen(false);
          setPendingMarkerPosition(null);
          setPendingTrafficPathId(null);
          setTrafficMarkerMode(false);
        }}
        onConfirm={confirmMarkerPlacement}
      />

      <MarkerDetailsDialog
        marker={scene.selectedMarker}
        open={markerDialogOpen && Boolean(scene.selectedMarker)}
        onClose={() => setMarkerDialogOpen(false)}
        onSave={handleSaveMarker}
        onDelete={(id) => {
          scene.removeMarker(id);
          setMarkerDialogOpen(false);
          setFocusMarkerId(null);
        }}
      />

      <ShapeDetailsDialog
        shape={scene.selectedShape}
        open={shapeDialogOpen && Boolean(scene.selectedShape)}
        onClose={() => setShapeDialogOpen(false)}
        onSave={scene.updateShape}
        onDelete={(id) => {
          scene.removeShape(id);
          setShapeDialogOpen(false);
        }}
      />
    </div>
  );
}
