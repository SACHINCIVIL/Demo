import { useCallback, useEffect, useState } from 'react';

const STORAGE_KEY = '3d-marker-poc-state';

const createId = () => `marker-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const loadStored = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { markers: [], modelUrl: null };
    const parsed = JSON.parse(raw);
    return {
      markers: Array.isArray(parsed.markers) ? parsed.markers : [],
      modelUrl: parsed.modelUrl || null,
    };
  } catch {
    return { markers: [], modelUrl: null };
  }
};

export function useMarkers() {
  const [markers, setMarkers] = useState(() => loadStored().markers);
  const [modelUrl, setModelUrl] = useState(() => loadStored().modelUrl);
  const [selectedId, setSelectedId] = useState(null);
  const [hoveredId, setHoveredId] = useState(null);
  const [placementMode, setPlacementMode] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ markers, modelUrl }));
  }, [markers, modelUrl]);

  const addMarker = useCallback((position, name, type = 'equipment') => {
    const marker = {
      id: createId(),
      name: name.trim() || 'Unnamed marker',
      type,
      position,
      createdAt: new Date().toISOString(),
    };
    setMarkers((prev) => [...prev, marker]);
    setSelectedId(marker.id);
    return marker;
  }, []);

  const updateMarker = useCallback((id, patch) => {
    setMarkers((prev) => prev.map((m) => (m.id === id ? { ...m, ...patch } : m)));
  }, []);

  const removeMarker = useCallback((id) => {
    setMarkers((prev) => prev.filter((m) => m.id !== id));
    setSelectedId((current) => (current === id ? null : current));
    setHoveredId((current) => (current === id ? null : current));
  }, []);

  const clearMarkers = useCallback(() => {
    setMarkers([]);
    setSelectedId(null);
    setHoveredId(null);
  }, []);

  const loadModelFile = useCallback((file) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setModelUrl((prev) => {
      if (prev?.startsWith('blob:')) URL.revokeObjectURL(prev);
      return url;
    });
    setSelectedId(null);
    setHoveredId(null);
  }, []);

  const resetModel = useCallback(() => {
    setModelUrl((prev) => {
      if (prev?.startsWith('blob:')) URL.revokeObjectURL(prev);
      return null;
    });
    clearMarkers();
  }, [clearMarkers]);

  const selectedMarker = markers.find((m) => m.id === selectedId) || null;
  const hoveredMarker = markers.find((m) => m.id === hoveredId) || null;

  return {
    markers,
    modelUrl,
    selectedId,
    selectedMarker,
    hoveredId,
    hoveredMarker,
    placementMode,
    setPlacementMode,
    setSelectedId,
    setHoveredId,
    addMarker,
    updateMarker,
    removeMarker,
    clearMarkers,
    loadModelFile,
    resetModel,
  };
}
