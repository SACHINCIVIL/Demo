import { useCallback, useEffect, useState } from 'react';
import { getAssetTypeFromFile, readFileAsDataUrl } from '../utils/assetUtils';
import { getShapeDef } from '../utils/shapeLibrary';
import { snapPosition } from '../utils/snapUtils';

const STORAGE_KEY = '3d-marker-poc-state-v4';

const createId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const normalizeMarker = (m) => ({
  locked: false,
  hidden: false,
  ...m,
});

const normalizeShape = (s) => ({
  locked: false,
  hidden: false,
  rotation: [0, 0, 0],
  scale: [1, 1, 1],
  ...s,
});

const loadStored = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        markers: [],
        shapes: [],
        trafficPaths: [],
        asset: null,
        placementMode: null,
        activeShapeType: null,
        activeTrafficPathId: null,
        transformMode: 'translate',
        snapToGrid: false,
        gridSize: 0.25,
      };
    }
    const parsed = JSON.parse(raw);
    let asset = parsed.asset || null;
    if (asset?.type === 'image' && asset.imageDataUrl) {
      asset = { ...asset, url: asset.imageDataUrl };
    }
    return {
      markers: Array.isArray(parsed.markers) ? parsed.markers.map(normalizeMarker) : [],
      shapes: Array.isArray(parsed.shapes) ? parsed.shapes.map(normalizeShape) : [],
      trafficPaths: Array.isArray(parsed.trafficPaths) ? parsed.trafficPaths : [],
      asset,
      placementMode: parsed.placementMode || null,
      activeShapeType: parsed.activeShapeType || null,
      activeTrafficPathId: parsed.activeTrafficPathId || null,
      transformMode: parsed.transformMode || 'translate',
      snapToGrid: Boolean(parsed.snapToGrid),
      gridSize: parsed.gridSize || 0.25,
    };
  } catch {
    return {
      markers: [],
      shapes: [],
      trafficPaths: [],
      asset: null,
      placementMode: null,
      activeShapeType: null,
      activeTrafficPathId: null,
      transformMode: 'translate',
      snapToGrid: false,
      gridSize: 0.25,
    };
  }
};

export function useSceneState() {
  const stored = loadStored();
  const [markers, setMarkers] = useState(stored.markers);
  const [shapes, setShapes] = useState(stored.shapes);
  const [trafficPaths, setTrafficPaths] = useState(stored.trafficPaths);
  const [asset, setAsset] = useState(stored.asset);
  const [selectedMarkerId, setSelectedMarkerId] = useState(null);
  const [selectedShapeId, setSelectedShapeId] = useState(null);
  const [selectedTrafficPathId, setSelectedTrafficPathId] = useState(null);
  const [hoveredMarkerId, setHoveredMarkerId] = useState(null);
  const [hoveredShapeId, setHoveredShapeId] = useState(null);
  const [placementMode, setPlacementMode] = useState(stored.placementMode);
  const [activeShapeType, setActiveShapeType] = useState(stored.activeShapeType);
  const [activeTrafficPathId, setActiveTrafficPathId] = useState(stored.activeTrafficPathId);
  const [draftTrafficPathPoints, setDraftTrafficPathPoints] = useState([]);
  const [transformMode, setTransformMode] = useState(stored.transformMode);
  const [snapToGrid, setSnapToGrid] = useState(stored.snapToGrid);
  const [gridSize, setGridSize] = useState(stored.gridSize);

  useEffect(() => {
    const toStore = {
      markers,
      shapes,
      trafficPaths,
      asset: asset
        ? {
            type: asset.type,
            fileName: asset.fileName,
            imageDataUrl: asset.type === 'image' ? asset.imageDataUrl || asset.url : undefined,
          }
        : null,
      placementMode,
      activeShapeType,
      activeTrafficPathId,
      transformMode,
      snapToGrid,
      gridSize,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toStore));
  }, [
    markers,
    shapes,
    trafficPaths,
    asset,
    placementMode,
    activeShapeType,
    activeTrafficPathId,
    transformMode,
    snapToGrid,
    gridSize,
  ]);

  const revokeBlob = useCallback((url) => {
    if (url?.startsWith('blob:')) URL.revokeObjectURL(url);
  }, []);

  const addMarker = useCallback(
    (position, name, type = 'equipment', extras = {}) => {
      const marker = {
        id: createId('marker'),
        name: name.trim() || 'Unnamed marker',
        type,
        position,
        locked: false,
        hidden: false,
        ...extras,
        createdAt: new Date().toISOString(),
      };
      setMarkers((prev) => [...prev, marker]);
      setSelectedMarkerId(marker.id);
      setSelectedShapeId(null);
      return marker;
    },
    []
  );

  const updateMarker = useCallback((id, patch) => {
    setMarkers((prev) => prev.map((m) => (m.id === id ? { ...m, ...patch } : m)));
  }, []);

  const removeMarker = useCallback((id) => {
    setMarkers((prev) => prev.filter((m) => m.id !== id));
    setSelectedMarkerId((c) => (c === id ? null : c));
    setHoveredMarkerId((c) => (c === id ? null : c));
  }, []);

  const addShape = useCallback(
    (position, shapeType, rotation = [0, 0, 0], imageCoords = null) => {
      const def = getShapeDef(shapeType);
      const shape = {
        id: createId('shape'),
        name: def.label,
        shapeType,
        category: def.category,
        color: def.color,
        modelUrl: def.modelUrl,
        position,
        rotation,
        scale: [...def.defaultScale],
        locked: false,
        hidden: false,
        ...(imageCoords ? { imageCoords } : {}),
        createdAt: new Date().toISOString(),
      };
      setShapes((prev) => [...prev, shape]);
      setSelectedShapeId(shape.id);
      setSelectedMarkerId(null);
      return shape;
    },
    []
  );

  const updateShape = useCallback((id, patch) => {
    setShapes((prev) => prev.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  }, []);

  const removeShape = useCallback((id) => {
    setShapes((prev) => prev.filter((s) => s.id !== id));
    setSelectedShapeId((c) => (c === id ? null : c));
    setHoveredShapeId((c) => (c === id ? null : c));
  }, []);

  const duplicateShape = useCallback((id) => {
    setShapes((prev) => {
      const source = prev.find((s) => s.id === id);
      if (!source) return prev;
      const copy = {
        ...source,
        id: createId('shape'),
        name: `${source.name} copy`,
        position: [
          source.position[0] + gridSize,
          source.position[1],
          source.position[2] ?? 0,
        ],
        locked: false,
      };
      setSelectedShapeId(copy.id);
      setSelectedMarkerId(null);
      return [...prev, copy];
    });
  }, [gridSize]);

  const duplicateMarker = useCallback(
    (id) => {
      setMarkers((prev) => {
        const source = prev.find((m) => m.id === id);
        if (!source) return prev;
        const copy = {
          ...source,
          id: createId('marker'),
          name: `${source.name} copy`,
          position: snapPosition(
            [source.position[0] + gridSize, source.position[1], source.position[2] ?? 0],
            gridSize
          ),
          locked: false,
          trafficPathId: source.type === 'trafficFlow' ? source.trafficPathId : undefined,
        };
        setSelectedMarkerId(copy.id);
        setSelectedShapeId(null);
        return [...prev, copy];
      });
    },
    [gridSize]
  );

  const placeShapeAt = useCallback(
    (position, shapeType, rotation = [0, 0, 0]) => {
      const pos = snapToGrid ? snapPosition(position, gridSize) : position;
      return addShape(pos, shapeType, rotation);
    },
    [addShape, snapToGrid, gridSize]
  );

  const addTrafficPathPoint = useCallback((point) => {
    setDraftTrafficPathPoints((prev) => [...prev, point]);
  }, []);

  const finishTrafficPath = useCallback((name) => {
    setDraftTrafficPathPoints((draft) => {
      if (draft.length < 2) return draft;
      const path = {
        id: createId('traffic'),
        name: name?.trim() || `Traffic flow ${Date.now()}`,
        points: draft,
        createdAt: new Date().toISOString(),
      };
      setTrafficPaths((prev) => [...prev, path]);
      setSelectedTrafficPathId(path.id);
      setPlacementMode(null);
      return [];
    });
  }, []);

  const cancelTrafficPathDraw = useCallback(() => {
    setDraftTrafficPathPoints([]);
    setPlacementMode(null);
  }, []);

  const removeTrafficPath = useCallback((id) => {
    setTrafficPaths((prev) => prev.filter((p) => p.id !== id));
    setMarkers((prev) => prev.filter((m) => m.trafficPathId !== id));
    setSelectedTrafficPathId((c) => (c === id ? null : c));
    setActiveTrafficPathId((c) => (c === id ? null : c));
  }, []);

  const loadAssetFile = useCallback(
    async (file) => {
      if (!file) return;
      const type = getAssetTypeFromFile(file);
      if (!type) {
        window.alert('Unsupported file. Use .glb, .gltf, .png, .jpg, or .jpeg');
        return;
      }

      setSelectedMarkerId(null);
      setSelectedShapeId(null);
      setSelectedTrafficPathId(null);
      setHoveredMarkerId(null);
      setHoveredShapeId(null);
      setDraftTrafficPathPoints([]);
      setPlacementMode(null);
      setActiveTrafficPathId(null);

      if (type === 'image') {
        const dataUrl = await readFileAsDataUrl(file);
        setAsset((prev) => {
          revokeBlob(prev?.url);
          return {
            type: 'image',
            fileName: file.name,
            url: dataUrl,
            imageDataUrl: dataUrl,
          };
        });
      } else {
        const url = URL.createObjectURL(file);
        setAsset((prev) => {
          revokeBlob(prev?.url);
          return { type: 'model', fileName: file.name, url };
        });
      }
    },
    [revokeBlob]
  );

  const resetScene = useCallback(() => {
    setAsset((prev) => {
      revokeBlob(prev?.url);
      return null;
    });
    setMarkers([]);
    setShapes([]);
    setTrafficPaths([]);
    setSelectedMarkerId(null);
    setSelectedShapeId(null);
    setSelectedTrafficPathId(null);
    setHoveredMarkerId(null);
    setHoveredShapeId(null);
    setPlacementMode(null);
    setActiveShapeType(null);
    setActiveTrafficPathId(null);
    setDraftTrafficPathPoints([]);
  }, [revokeBlob]);

  const startMarkerPlacement = useCallback(() => {
    setPlacementMode('marker');
    setActiveShapeType(null);
    setActiveTrafficPathId(null);
    setDraftTrafficPathPoints([]);
  }, []);

  const startShapePlacement = useCallback((shapeType) => {
    setPlacementMode('shape');
    setActiveShapeType(shapeType);
    setActiveTrafficPathId(null);
    setDraftTrafficPathPoints([]);
  }, []);

  const startTrafficPathDraw = useCallback(() => {
    setPlacementMode('trafficPath');
    setActiveShapeType(null);
    setActiveTrafficPathId(null);
    setDraftTrafficPathPoints([]);
  }, []);

  const startTrafficMarkerPlacement = useCallback((pathId) => {
    setPlacementMode('trafficMarker');
    setActiveTrafficPathId(pathId);
    setActiveShapeType(null);
    setSelectedTrafficPathId(pathId);
    setDraftTrafficPathPoints([]);
  }, []);

  const cancelPlacement = useCallback(() => {
    setPlacementMode(null);
    setActiveShapeType(null);
    setActiveTrafficPathId(null);
    setDraftTrafficPathPoints([]);
  }, []);

  const selectedMarker = markers.find((m) => m.id === selectedMarkerId) || null;
  const selectedShape = shapes.find((s) => s.id === selectedShapeId) || null;
  const selectedTrafficPath = trafficPaths.find((p) => p.id === selectedTrafficPathId) || null;
  const activeTrafficPath = trafficPaths.find((p) => p.id === activeTrafficPathId) || null;
  const hoveredMarker = markers.find((m) => m.id === hoveredMarkerId) || null;
  const hoveredShape = shapes.find((s) => s.id === hoveredShapeId) || null;

  return {
    markers,
    shapes,
    trafficPaths,
    asset,
    assetUrl: asset?.url || null,
    assetType: asset?.type || null,
    selectedMarkerId,
    selectedShapeId,
    selectedTrafficPathId,
    selectedMarker,
    selectedShape,
    selectedTrafficPath,
    activeTrafficPathId,
    activeTrafficPath,
    draftTrafficPathPoints,
    hoveredMarkerId,
    hoveredShapeId,
    hoveredMarker,
    hoveredShape,
    placementMode,
    activeShapeType,
    transformMode,
    snapToGrid,
    gridSize,
    setTransformMode,
    setSnapToGrid,
    setGridSize,
    setSelectedMarkerId,
    setSelectedShapeId,
    setSelectedTrafficPathId,
    setHoveredMarkerId,
    setHoveredShapeId,
    addMarker,
    updateMarker,
    removeMarker,
    addShape,
    updateShape,
    removeShape,
    duplicateShape,
    duplicateMarker,
    placeShapeAt,
    addTrafficPathPoint,
    finishTrafficPath,
    cancelTrafficPathDraw,
    removeTrafficPath,
    loadAssetFile,
    resetScene,
    startMarkerPlacement,
    startShapePlacement,
    startTrafficPathDraw,
    startTrafficMarkerPlacement,
    cancelPlacement,
  };
}
