/** Fit perspective camera so a w×h board is fully visible */
export function fitCameraDistance(camera, boardW, boardH, viewportAspect, padding = 1.55) {
  const fovRad = (camera.fov * Math.PI) / 180;
  const distForHeight = (boardH / 2) / Math.tan(fovRad / 2);
  const distForWidth = (boardW / 2) / (Math.tan(fovRad / 2) * viewportAspect);
  return Math.max(distForHeight, distForWidth) * padding;
}
