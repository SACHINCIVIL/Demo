/** Snap a single axis value to grid */
export function snapAxis(value, gridSize = 0.25) {
  if (!gridSize || gridSize <= 0) return value;
  return Math.round(value / gridSize) * gridSize;
}

export function snapPosition(position, gridSize = 0.25) {
  if (!position) return [0, 0, 0];
  return position.map((v) => snapAxis(v, gridSize));
}

export function snapEuler(rotation, gridSize = 0.25) {
  if (!rotation) return [0, 0, 0];
  const step = Math.PI / 12; // 15° when grid snapping rotations
  return rotation.map((r) => Math.round(r / step) * step);
}
