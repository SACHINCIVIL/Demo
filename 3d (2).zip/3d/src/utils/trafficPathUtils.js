/** EMP-style traffic path geometry (snap + validate markers on yellow path) */

export const TRAFFIC_PATH_COLOR = '#d6b656';
export const TRAFFIC_PATH_SNAP_THRESHOLD = 0.35;
export const TRAFFIC_PATH_VALIDATE_THRESHOLD = 0.45;

export function distancePointToSegment(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  if (dx === 0 && dy === 0) return Math.hypot(px - x1, py - y1);
  const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)));
  const projX = x1 + t * dx;
  const projY = y1 + t * dy;
  return {
    distance: Math.hypot(px - projX, py - projY),
    x: projX,
    y: projY,
    t,
  };
}

/** Nearest point on a polyline (array of [x,y] or [x,y,z]) */
export function findNearestPointOnPolyline(points, x, y) {
  if (!points?.length) return null;
  if (points.length === 1) {
    const [px, py] = points[0];
    return { x: px, y: py, distance: Math.hypot(x - px, y - py), segmentIndex: 0, t: 0 };
  }

  let best = null;
  for (let i = 0; i < points.length - 1; i += 1) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[i + 1];
    const hit = distancePointToSegment(x, y, x1, y1, x2, y2);
    if (!best || hit.distance < best.distance) {
      best = { ...hit, segmentIndex: i };
    }
  }
  return best;
}

/** Nearest point on a polyline segment in 3D */
function closestPointOnSegment3D(px, py, pz, a, b) {
  const [x1, y1, z1] = a;
  const [x2, y2, z2] = b;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dz = z2 - z1;
  const lenSq = dx * dx + dy * dy + dz * dz;
  if (lenSq === 0) {
    return { x: x1, y: y1, z: z1, distance: Math.hypot(px - x1, py - y1, pz - z1) };
  }
  const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy + (pz - z1) * dz) / lenSq));
  const x = x1 + t * dx;
  const y = y1 + t * dy;
  const z = z1 + t * dz;
  return { x, y, z, distance: Math.hypot(px - x, py - y, pz - z) };
}

export function findNearestPointOnPolyline3D(points, x, y, z = 0) {
  if (!points?.length) return null;
  if (points.length === 1) {
    const [px, py, pz = 0] = points[0];
    return { x: px, y: py, z: pz, distance: Math.hypot(x - px, y - py, z - pz), segmentIndex: 0 };
  }
  let best = null;
  for (let i = 0; i < points.length - 1; i += 1) {
    const hit = closestPointOnSegment3D(x, y, z, points[i], points[i + 1]);
    if (!best || hit.distance < best.distance) {
      best = { ...hit, segmentIndex: i };
    }
  }
  return best;
}

export function snapPointToTrafficPath(path, x, y, maxDistance = TRAFFIC_PATH_SNAP_THRESHOLD, z = null) {
  if (!path?.points?.length) return null;
  const use3d = z != null;
  const nearest = use3d
    ? findNearestPointOnPolyline3D(path.points, x, y, z)
    : findNearestPointOnPolyline(path.points, x, y);
  if (!nearest || nearest.distance > maxDistance) return null;
  const snapZ = nearest.z ?? path.points[0]?.[2] ?? 0.18;
  return { x: nearest.x, y: nearest.y, z: snapZ, distance: nearest.distance };
}

export function isPointOnTrafficPath(path, x, y, threshold = TRAFFIC_PATH_VALIDATE_THRESHOLD, z = null) {
  if (!path?.points?.length) return false;
  const nearest =
    z != null
      ? findNearestPointOnPolyline3D(path.points, x, y, z)
      : findNearestPointOnPolyline(path.points, x, y);
  return Boolean(nearest && nearest.distance <= threshold);
}

export function getTrafficPathById(trafficPaths, pathId) {
  return trafficPaths.find((p) => p.id === pathId) || null;
}

function pathIsMostlyFlat(path) {
  if (!path?.points?.length) return true;
  const zs = path.points.map((p) => p[2] ?? 0);
  return Math.max(...zs) - Math.min(...zs) < 0.08;
}

export function isMarkerOnTrafficPath(marker, path, threshold = TRAFFIC_PATH_VALIDATE_THRESHOLD) {
  if (!marker || !path) return false;
  const [x, y, z = 0] = marker.position;
  if (pathIsMostlyFlat(path)) {
    return isPointOnTrafficPath(path, x, y, threshold);
  }
  return isPointOnTrafficPath(path, x, y, threshold * 1.2, z);
}

export function validateTrafficMarkersOnPaths(
  markers,
  trafficPaths,
  threshold = TRAFFIC_PATH_VALIDATE_THRESHOLD
) {
  const trafficMarkers = markers.filter((m) => m.type === 'trafficFlow');
  if (!trafficMarkers.length) return true;
  return findFirstOffPathTrafficMarker(markers, trafficPaths, threshold) === null;
}

export function findFirstOffPathTrafficMarker(
  markers,
  trafficPaths,
  threshold = TRAFFIC_PATH_VALIDATE_THRESHOLD
) {
  for (const marker of markers) {
    if (marker.type !== 'trafficFlow') continue;
    const path = getTrafficPathById(trafficPaths, marker.trafficPathId);
    if (!path) return marker;
    if (!isMarkerOnTrafficPath(marker, path, threshold)) return marker;
  }
  return null;
}

export function boardPointToImageCoords(x, y, boardWidth, boardHeight) {
  if (!boardWidth || !boardHeight) return null;
  return [(x / boardWidth) + 0.5, 0.5 - y / boardHeight];
}
