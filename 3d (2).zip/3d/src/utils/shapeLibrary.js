/** Custom shape library — draw.io-style palette for 3D scene editor */
export const SHAPE_CATEGORIES = [
  { id: 'basic', label: 'Basic' },
  { id: 'advanced', label: 'Advanced' },
  { id: 'equipment', label: 'Equipment' },
  { id: 'models', label: '3D Models' },
];

export const SHAPE_LIBRARY = [
  { id: 'box', label: 'Box', category: 'basic', color: '#1976d2', icon: '▣', defaultScale: [0.4, 0.4, 0.4] },
  { id: 'sphere', label: 'Sphere', category: 'basic', color: '#2e7d32', icon: '●', defaultScale: [0.25, 0.25, 0.25] },
  { id: 'cylinder', label: 'Cylinder', category: 'basic', color: '#ed6c02', icon: '⬭', defaultScale: [0.2, 0.35, 0.2] },
  { id: 'cone', label: 'Cone', category: 'basic', color: '#9c27b0', icon: '▲', defaultScale: [0.25, 0.4, 0.25] },
  { id: 'plane', label: 'Rectangle', category: 'advanced', color: '#5d4037', icon: '▭', defaultScale: [0.6, 0.02, 0.4] },
  { id: 'torus', label: 'Ring', category: 'advanced', color: '#00838f', icon: '◯', defaultScale: [0.35, 0.35, 0.35] },
  { id: 'capsule', label: 'Capsule', category: 'advanced', color: '#c62828', icon: '⬮', defaultScale: [0.18, 0.35, 0.18] },
  { id: 'octahedron', label: 'Diamond', category: 'advanced', color: '#6a1b9a', icon: '◆', defaultScale: [0.3, 0.3, 0.3] },
  { id: 'arrow', label: 'Arrow', category: 'advanced', color: '#f57c00', icon: '→', defaultScale: [1, 1, 1] },
  { id: 'drain', label: 'Drain', category: 'equipment', color: '#2e7d32', icon: '◎', defaultScale: [0.3, 0.05, 0.3] },
  { id: 'tank', label: 'Tank', category: 'equipment', color: '#1565c0', icon: '⛢', defaultScale: [0.35, 0.5, 0.35] },
  { id: 'traffic', label: 'Traffic', category: 'equipment', color: '#e65100', icon: '➤', defaultScale: [1, 1, 1] },
  // GLB models — optional: drop files in /public/models/ (see README). No modelUrl until file exists.
  {
    id: 'pump',
    label: 'Pump',
    category: 'models',
    color: '#455a64',
    icon: '⚙',
    defaultScale: [0.5, 0.5, 0.5],
    primitiveFallback: 'cylinder',
    // modelUrl: '/models/pump.glb', — uncomment when file is added
  },
  {
    id: 'valve',
    label: 'Valve',
    category: 'models',
    color: '#546e7a',
    icon: '◈',
    defaultScale: [0.4, 0.4, 0.4],
    primitiveFallback: 'box',
  },
  {
    id: 'motor',
    label: 'Motor',
    category: 'models',
    color: '#37474f',
    icon: '⊛',
    defaultScale: [0.45, 0.45, 0.45],
    primitiveFallback: 'cylinder',
  },
  {
    id: 'pipe',
    label: 'Pipe',
    category: 'models',
    color: '#78909c',
    icon: '═',
    defaultScale: [0.6, 0.15, 0.15],
    primitiveFallback: 'cylinder',
  },
];

export function getShapeDef(shapeType) {
  return SHAPE_LIBRARY.find((s) => s.id === shapeType) || SHAPE_LIBRARY[0];
}

export function getShapesByCategory(categoryId) {
  return SHAPE_LIBRARY.filter((s) => s.category === categoryId);
}

export function getEffectiveShapeType(shapeType) {
  const def = getShapeDef(shapeType);
  return def.primitiveFallback || def.id;
}
