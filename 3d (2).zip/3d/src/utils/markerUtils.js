import * as THREE from 'three';

export const MARKER_TYPES = [
  { value: 'equipment', label: 'Equipment' },
  { value: 'drain', label: 'Drain' },
  { value: 'trafficFlow', label: 'Traffic Flow' },
];

export const MARKER_COLORS = {
  equipment: '#1976d2',
  drain: '#2e7d32',
  trafficFlow: '#ed6c02',
  default: '#d32f2f',
};

export function getMarkerColor(type) {
  return MARKER_COLORS[type] || MARKER_COLORS.default;
}

export function truncate(text, max = 20) {
  const s = String(text || '');
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

export function getRotationFromNormal(normal) {
  const n = new THREE.Vector3(normal?.x ?? 0, normal?.y ?? 1, normal?.z ?? 0).normalize();
  const up = new THREE.Vector3(0, 1, 0);
  const quaternion = new THREE.Quaternion().setFromUnitVectors(up, n);
  const euler = new THREE.Euler().setFromQuaternion(quaternion);
  return [euler.x, euler.y, euler.z];
}

/** Convert normalized image coords (0–1) to 3D position on vertical board */
export function imageCoordsToBoardPosition(nx, ny, boardWidth, boardHeight, z = 0.2) {
  return [(nx - 0.5) * boardWidth, (0.5 - ny) * boardHeight, z];
}

export function resolveMarkerPosition(marker, boardSize) {
  if (marker?.imageCoords && boardSize?.width) {
    return imageCoordsToBoardPosition(
      marker.imageCoords[0],
      marker.imageCoords[1],
      boardSize.width,
      boardSize.height
    );
  }
  return marker?.position || [0, 0, 0];
}

export function resolveShapePosition(shape, boardSize) {
  if (shape?.imageCoords && boardSize?.width) {
    return imageCoordsToBoardPosition(
      shape.imageCoords[0],
      shape.imageCoords[1],
      boardSize.width,
      boardSize.height,
      0.24
    );
  }
  return shape?.position || [0, 0, 0];
}
