import * as THREE from 'three';

const tmpTarget = new THREE.Vector3();
const tmpPos = new THREE.Vector3();

/** Smooth camera focus on a marker (like EMP marker-zoom focus) */
export function focusCameraOnMarker(camera, controls, position, options = {}) {
  if (!camera || !controls || !position) return null;

  const {
    distance = 2.8,
    duration = 450,
    onDone,
  } = options;

  const target = tmpTarget.set(position[0], position[1], position[2]);
  const startTarget = controls.target.clone();
  const startPos = camera.position.clone();

  const dir = startPos.clone().sub(startTarget);
  if (dir.lengthSq() < 0.001) dir.set(0.4, 0.25, 1);
  dir.normalize();

  const endTarget = target.clone();
  const endPos = target.clone().add(dir.multiplyScalar(distance));

  const start = performance.now();
  let frame = 0;

  const tick = (now) => {
    const t = Math.min(1, (now - start) / duration);
    const ease = 1 - (1 - t) ** 3;

    camera.position.lerpVectors(startPos, endPos, ease);
    controls.target.lerpVectors(startTarget, endTarget, ease);
    controls.update();

    if (t < 1) {
      frame = requestAnimationFrame(tick);
    } else {
      onDone?.();
    }
  };

  frame = requestAnimationFrame(tick);
  return () => cancelAnimationFrame(frame);
}

/** Screen-stable marker scale (marker stays same size when zooming — like draw.io marker-zoom) */
export function getMarkerScreenScale(camera, worldPosition, baseDistance = 7) {
  const dist = camera.position.distanceTo(
    tmpPos.set(worldPosition[0], worldPosition[1], worldPosition[2])
  );
  return Math.max(0.35, Math.min(2.5, dist / baseDistance));
}
