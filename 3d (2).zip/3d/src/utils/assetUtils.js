export const MODEL_EXTENSIONS = ['glb', 'gltf'];
export const IMAGE_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];

export function getAssetTypeFromFile(file) {
  if (!file?.name) return null;
  const ext = file.name.split('.').pop().toLowerCase();
  if (MODEL_EXTENSIONS.includes(ext)) return 'model';
  if (IMAGE_EXTENSIONS.includes(ext)) return 'image';
  return null;
}

export function getAcceptString() {
  return [...MODEL_EXTENSIONS, ...IMAGE_EXTENSIONS].map((e) => `.${e}`).join(',');
}

export function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
