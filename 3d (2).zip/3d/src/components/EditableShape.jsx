import { useState } from 'react';
import ObjectTransformGizmo from './ObjectTransformGizmo';
import PlacedShape from './PlacedShape';

export default function EditableShape({
  shape,
  isSelected,
  transformMode,
  snapToGrid,
  gridSize,
  onTransformEnd,
  ...shapeProps
}) {
  const [groupObj, setGroupObj] = useState(null);
  const objectRef = { current: groupObj };

  return (
    <>
      <PlacedShape
        ref={setGroupObj}
        shape={shape}
        isSelected={isSelected}
        disableInteraction={isSelected && !shape.locked}
        {...shapeProps}
      />
      {isSelected && !shape.locked && groupObj && (
        <ObjectTransformGizmo
          objectRef={objectRef}
          mode={transformMode}
          snapToGrid={snapToGrid}
          gridSize={gridSize}
          onTransformEnd={onTransformEnd}
          enabled
        />
      )}
    </>
  );
}
