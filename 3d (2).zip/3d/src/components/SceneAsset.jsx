import { Center } from '@react-three/drei';
import { Suspense } from 'react';
import ImagePlane from './ImagePlane';
import Model3D from './Model3D';

function LoadingPlane() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[8, 8]} />
      <meshStandardMaterial color="#e8eef5" />
    </mesh>
  );
}

export default function SceneAsset({ asset, onSurfacePointerDown }) {
  if (!asset?.url) return <LoadingPlane />;

  return (
    <group onPointerDown={onSurfacePointerDown}>
      {asset.type === 'image' ? (
        <Suspense fallback={<LoadingPlane />}>
          <ImagePlane url={asset.url} />
        </Suspense>
      ) : (
        <Suspense fallback={<LoadingPlane />}>
          <Center>
            <Model3D url={asset.url} />
          </Center>
        </Suspense>
      )}
    </group>
  );
}
