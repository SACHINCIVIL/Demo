import { useState } from 'react';
import { getMarkerColor } from '../utils/markerUtils';
import { getShapeDef } from '../utils/shapeLibrary';
import { TRAFFIC_PATH_COLOR } from '../utils/trafficPathUtils';
import SceneHierarchy from './SceneHierarchy';

export default function SceneSidebar({
  markers,
  shapes,
  trafficPaths,
  selectedMarkerId,
  selectedShapeId,
  selectedTrafficPathId,
  placementMode,
  draftTrafficPathPoints,
  onMarkerSelect,
  onShapeSelect,
  onHierarchySelectMarker,
  onHierarchySelectShape,
  onTrafficPathSelect,
  onToggleMarkerPlacement,
  onStartTrafficPathDraw,
  onFinishTrafficPath,
  onCancelTrafficPathDraw,
  onStartTrafficMarkerPlacement,
  onRemoveMarker,
  onRemoveShape,
  onRemoveTrafficPath,
  hasAsset,
}) {
  const [tab, setTab] = useState('scene');
  const trafficMarkers = markers.filter((m) => m.type === 'trafficFlow');

  return (
    <aside className="scene-sidebar">
      <div className="scene-sidebar-tabs">
        <button
          type="button"
          className={tab === 'scene' ? 'active' : ''}
          onClick={() => setTab('scene')}>
          Scene
        </button>
        <button
          type="button"
          className={tab === 'markers' ? 'active' : ''}
          onClick={() => setTab('markers')}>
          Markers ({markers.length})
        </button>
        <button
          type="button"
          className={tab === 'traffic' ? 'active' : ''}
          onClick={() => setTab('traffic')}>
          Traffic ({trafficPaths.length})
        </button>
        <button
          type="button"
          className={tab === 'shapes' ? 'active' : ''}
          onClick={() => setTab('shapes')}>
          Shapes ({shapes.length})
        </button>
      </div>

      {tab === 'scene' && (
        <SceneHierarchy
          markers={markers}
          shapes={shapes}
          trafficPaths={trafficPaths}
          selectedMarkerId={selectedMarkerId}
          selectedShapeId={selectedShapeId}
          selectedTrafficPathId={selectedTrafficPathId}
          onSelectMarker={onHierarchySelectMarker}
          onSelectShape={onHierarchySelectShape}
          onSelectTrafficPath={onTrafficPathSelect}
        />
      )}

      {tab === 'markers' && (
        <>
          <button
            type="button"
            className={`placement-btn ${placementMode === 'marker' ? 'on' : ''}`}
            disabled={!hasAsset}
            onClick={onToggleMarkerPlacement}>
            {placementMode === 'marker' ? '✓ Click surface once…' : '+ Add marker'}
          </button>
          {!placementMode && (
            <p className="sidebar-placement-note">
              Equipment / drain — anywhere on surface. Traffic markers go on a path (Traffic tab).
            </p>
          )}
          <div className="scene-list">
            {markers.length === 0 && <p className="scene-list-empty">No markers yet.</p>}
            {markers.map((marker, index) => (
              <ListItem
                key={marker.id}
                selected={marker.id === selectedMarkerId}
                color={getMarkerColor(marker.type)}
                title={marker.name}
                subtitle={`${marker.type}${marker.trafficPathId ? ' · on path' : ''} · #${index + 1}`}
                onClick={() => onMarkerSelect(marker.id)}
                onRemove={() => onRemoveMarker(marker.id)}
              />
            ))}
          </div>
        </>
      )}

      {tab === 'traffic' && (
        <>
          <button
            type="button"
            className={`placement-btn placement-btn--traffic ${placementMode === 'trafficPath' ? 'on' : ''}`}
            disabled={!hasAsset}
            onClick={() => {
              if (placementMode === 'trafficPath') onCancelTrafficPathDraw();
              else onStartTrafficPathDraw();
            }}>
            {placementMode === 'trafficPath' ? '✓ Drawing path…' : '+ Draw traffic flow'}
          </button>

          {placementMode === 'trafficPath' && (
            <div className="traffic-draw-actions">
              <p className="sidebar-placement-note">
                Click the floor plan to add points ({draftTrafficPathPoints?.length || 0}). Min 2
                points.
              </p>
              <button
                type="button"
                className="btn-primary btn-small"
                disabled={(draftTrafficPathPoints?.length || 0) < 2}
                onClick={() => onFinishTrafficPath()}>
                Finish path
              </button>
              <button type="button" className="btn-secondary btn-small" onClick={onCancelTrafficPathDraw}>
                Cancel
              </button>
            </div>
          )}

          <div className="scene-list">
            {trafficPaths.length === 0 && (
              <p className="scene-list-empty">No traffic paths. Draw a yellow flow line first.</p>
            )}
            {trafficPaths.map((path, index) => {
              const pathMarkerCount = markers.filter((m) => m.trafficPathId === path.id).length;
              const isSelected = path.id === selectedTrafficPathId;
              return (
                <div key={path.id} className={`traffic-path-item ${isSelected ? 'selected' : ''}`}>
                  <div
                    role="button"
                    tabIndex={0}
                    className="traffic-path-item__main"
                    onClick={() => onTrafficPathSelect(path.id)}
                    onKeyDown={(e) => e.key === 'Enter' && onTrafficPathSelect(path.id)}>
                    <span className="scene-list-dot" style={{ background: TRAFFIC_PATH_COLOR }} />
                    <div className="scene-list-text">
                      <div className="scene-list-title">{path.name}</div>
                      <div className="scene-list-sub">
                        {path.points?.length || 0} pts · {pathMarkerCount} markers · #{index + 1}
                      </div>
                    </div>
                  </div>
                  <div className="traffic-path-item__actions">
                    <button
                      type="button"
                      className={`placement-btn placement-btn--compact ${placementMode === 'trafficMarker' && isSelected ? 'on' : ''}`}
                      title="Add marker on this path"
                      onClick={() => onStartTrafficMarkerPlacement(path.id)}>
                      + Point
                    </button>
                    <button
                      type="button"
                      className="scene-list-remove"
                      onClick={() => onRemoveTrafficPath(path.id)}>
                      ×
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {trafficMarkers.length > 0 && (
            <p className="sidebar-placement-note traffic-validation-note">
              Traffic markers must stay on the yellow path (validated on export).
            </p>
          )}
        </>
      )}

      {tab === 'shapes' && (
        <div className="scene-list">
          {shapes.length === 0 && (
            <p className="scene-list-empty">No shapes yet. Use the Advanced panel on the right.</p>
          )}
          {shapes.map((shape, index) => {
            const def = getShapeDef(shape.shapeType);
            return (
              <ListItem
                key={shape.id}
                selected={shape.id === selectedShapeId}
                color={shape.color || def.color}
                title={shape.name}
                subtitle={`${def.label} · #${index + 1}`}
                onClick={() => onShapeSelect(shape.id)}
                onRemove={() => onRemoveShape(shape.id)}
              />
            );
          })}
        </div>
      )}
    </aside>
  );
}

function ListItem({ selected, color, title, subtitle, onClick, onRemove }) {
  return (
    <div
      role="button"
      tabIndex={0}
      className={`scene-list-item ${selected ? 'selected' : ''}`}
      onClick={onClick}
      onKeyDown={(e) => e.key === 'Enter' && onClick()}>
      <span className="scene-list-dot" style={{ background: color }} />
      <div className="scene-list-text">
        <div className="scene-list-title">{title}</div>
        <div className="scene-list-sub">{subtitle}</div>
      </div>
      <button
        type="button"
        className="scene-list-remove"
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}>
        ×
      </button>
    </div>
  );
}
