import { OrbitControls, OrthographicCamera } from '@react-three/drei';
import { Canvas, useThree } from '@react-three/fiber';
import { Suspense, useCallback, useEffect, useState } from 'react';
import { getRotationFromNormal } from '../utils/markerUtils';
import ImagePlane from './ImagePlane';
import MarkerPin from './MarkerPin';
import PlacedShape from './PlacedShape';

function AutoFitOrtho({ planeWidth, planeHeight }) {
  const { camera, size } = useThree();

  useEffect(() => {
    if (!camera.isOrthographicCamera || !planeWidth) return;
    const aspect = size.width / size.height;
    const padding = 1.12;
    const viewHeight = Math.max(planeHeight, planeWidth / aspect) * padding;
    camera.top = viewHeight / 2;
    camera.bottom = -viewHeight / 2;
    camera.left = (-viewHeight * aspect) / 2;
    camera.right = (viewHeight * aspect) / 2;
    camera.position.set(0, 20, 0);
    camera.lookAt(0, 0, 0);
    camera.near = 0.1;
    camera.far = 200;
    camera.updateProjectionMatrix();
  }, [camera, planeWidth, planeHeight, size.width, size.height]);

  return null;
}

function FloorPlanContent({
  asset,
  markers,
  shapes,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  onSurfacePlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  onPlaneReady,
}) {
  const handleSurfacePointerDown = useCallback(
    (e) => {
      if (!placementMode || !asset?.url) return;
      e.stopPropagation();
      const point = e.point;
      const normal = { x: 0, y: 1, z: 0 };
      const y = placementMode === 'shape' ? 0.15 : 0.12;
      const position = [point.x, y, point.z];
      const rotation = getRotationFromNormal(normal);
      onSurfacePlace(position, rotation, normal, e);
    },
    [placementMode, asset, onSurfacePlace]
  );

  return (
    <>
      <color attach="background" args={['#eef2f6']} />
      <ambientLight intensity={1} />

      <group onPointerDown={handleSurfacePointerDown}>
        <Suspense fallback={null}>
          <ImagePlane url={asset.url} onReady={onPlaneReady} />
        </Suspense>
      </group>

      {/* Subtle grid under floor plan */}
      <gridHelper
        args={[30, 30, '#c5cdd8', '#dde3ea']}
        position={[0, -0.01, 0]}
      />

      {shapes.map((shape) => (
        <PlacedShape
          key={shape.id}
          shape={shape}
          isSelected={shape.id === selectedShapeId}
          isHovered={shape.id === hoveredShapeId}
          onSelect={onShapeSelect}
          onHover={onShapeHover}
          onLeave={onShapeLeave}
        />
      ))}

      {markers.map((marker) => (
        <MarkerPin
          key={marker.id}
          marker={marker}
          isSelected={marker.id === selectedMarkerId}
          isHovered={marker.id === hoveredMarkerId}
          onSelect={onMarkerSelect}
          onHover={onMarkerHover}
          onLeave={onMarkerLeave}
        />
      ))}

      <OrbitControls
        makeDefault
        enableRotate={false}
        enablePan
        enableZoom
        screenSpacePanning
        minZoom={0.3}
        maxZoom={8}
        mouseButtons={{ LEFT: 2, MIDDLE: 1, RIGHT: 0 }}
      />
    </>
  );
}

/** 2D floor plan mode — orthographic top-down (CAD / FM industry standard) */
export default function FloorPlanViewer({
  asset,
  markers,
  shapes,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  activeShapeType,
  onSurfacePlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  clearSelection,
}) {
  const [planeSize, setPlaneSize] = useState({ width: 12, height: 12 });

  const placementLabel =
    placementMode === 'marker'
      ? 'Click floor plan to place marker'
      : placementMode === 'shape'
        ? `Click floor plan to place: ${activeShapeType}`
        : null;

  return (
    <div className="scene-wrap scene-wrap--floorplan">
      <Canvas
        orthographic
        onPointerMissed={() => {
          if (!placementMode) clearSelection?.();
        }}
        style={{ width: '100%', height: '100%' }}
        gl={{ antialias: true, alpha: false }}
        dpr={[1, 2]}>
        <OrthographicCamera makeDefault position={[0, 20, 0]} zoom={50} near={0.1} far={200} />
        <AutoFitOrtho planeWidth={planeSize.width} planeHeight={planeSize.height} />
        <FloorPlanContent
          asset={asset}
          markers={markers}
          shapes={shapes}
          selectedMarkerId={selectedMarkerId}
          selectedShapeId={selectedShapeId}
          hoveredMarkerId={hoveredMarkerId}
          hoveredShapeId={hoveredShapeId}
          placementMode={placementMode}
          onSurfacePlace={onSurfacePlace}
          onMarkerSelect={onMarkerSelect}
          onShapeSelect={onShapeSelect}
          onMarkerHover={onMarkerHover}
          onMarkerLeave={onMarkerLeave}
          onShapeHover={onShapeHover}
          onShapeLeave={onShapeLeave}
          onPlaneReady={setPlaneSize}
        />
      </Canvas>

      <div className="scene-asset-badge">Floor plan · Plan view</div>

      {placementLabel && <div className="scene-placement-hint">{placementLabel}</div>}

      <div className="scene-controls-hint">
        Scroll to zoom · Drag to pan (2D plan view)
      </div>
    </div>
  );
}
