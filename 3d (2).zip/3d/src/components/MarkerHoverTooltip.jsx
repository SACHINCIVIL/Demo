import { truncate } from '../utils/markerUtils';

/** Same idea as EMP MarkerHoverTooltip — lightblue card on hover */
export default function MarkerHoverTooltip({ marker, style }) {
  if (!marker) return null;

  return (
    <div
      style={{
        pointerEvents: 'none',
        zIndex: 10001,
        backgroundColor: 'lightblue',
        borderRadius: 4,
        boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
        maxWidth: '22vw',
        minWidth: 260,
        padding: 8,
        ...style,
      }}>
      <div style={{ color: '#afafaf', fontSize: 16, fontWeight: 600, textTransform: 'capitalize' }}>
        {marker.type || 'equipment'}:
        <span style={{ color: '#808080', fontSize: 16, paddingLeft: 7, fontWeight: 500 }}>
          {truncate(marker.name, 20) || '-'}
        </span>
      </div>
      <div style={{ color: '#afafaf', fontSize: 15, fontWeight: 600, marginTop: 4 }}>
        Marker ID:
        <span style={{ color: '#808080', paddingLeft: 7, fontWeight: 500 }}>
          {marker.id.slice(-8)}
        </span>
      </div>
      <div style={{ color: '#afafaf', fontSize: 13, marginTop: 4 }}>
        Position:{' '}
        <span style={{ color: '#808080' }}>
          {marker.position.map((v) => v.toFixed(2)).join(', ')}
        </span>
      </div>
    </div>
  );
}
