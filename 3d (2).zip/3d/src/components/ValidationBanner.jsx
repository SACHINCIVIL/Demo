export default function ValidationBanner({ message, onDismiss }) {
  if (!message) return null;
  return (
    <div className="validation-banner" role="alert">
      <span>{message}</span>
      {onDismiss && (
        <button type="button" className="validation-banner__close" onClick={onDismiss}>
          ×
        </button>
      )}
    </div>
  );
}
