import { useGLTF } from '@react-three/drei';
import { useMemo } from 'react';

export default function Model3D({ url }) {
  const { scene } = useGLTF(url);
  const cloned = useMemo(() => scene.clone(true), [scene]);

  return <primitive object={cloned} />;
}
