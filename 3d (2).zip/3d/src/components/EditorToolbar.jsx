export default function EditorToolbar({
  transformMode,
  onTransformModeChange,
  snapToGrid,
  onSnapToggle,
  gridSize,
  onGridSizeChange,
  hasSelection,
}) {
  return (
    <div className="editor-toolbar">
      <span className="editor-toolbar__label">Transform</span>
      <div className="editor-toolbar__group">
        <button
          type="button"
          className={`editor-tool-btn ${transformMode === 'translate' ? 'active' : ''}`}
          title="Move (G)"
          onClick={() => onTransformModeChange('translate')}>
          ↔ Move
        </button>
        <button
          type="button"
          className={`editor-tool-btn ${transformMode === 'rotate' ? 'active' : ''}`}
          title="Rotate (R)"
          disabled={!hasSelection}
          onClick={() => onTransformModeChange('rotate')}>
          ↻ Rotate
        </button>
        <button
          type="button"
          className={`editor-tool-btn ${transformMode === 'scale' ? 'active' : ''}`}
          title="Scale (S)"
          disabled={!hasSelection}
          onClick={() => onTransformModeChange('scale')}>
          ⤢ Scale
        </button>
      </div>

      <span className="editor-toolbar__divider" />

      <label className="editor-snap-toggle">
        <input type="checkbox" checked={snapToGrid} onChange={(e) => onSnapToggle(e.target.checked)} />
        Snap to grid
      </label>
      {snapToGrid && (
        <select
          className="editor-grid-select"
          value={gridSize}
          onChange={(e) => onGridSizeChange(Number(e.target.value))}>
          <option value={0.1}>0.1</option>
          <option value={0.25}>0.25</option>
          <option value={0.5}>0.5</option>
          <option value={1}>1.0</option>
        </select>
      )}
    </div>
  );
}
