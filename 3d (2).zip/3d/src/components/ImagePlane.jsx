import { useTexture } from '@react-three/drei';
import { useEffect, useState } from 'react';
import * as THREE from 'three';

const MAX_PLANE_SIZE = 12;

/**
 * Industry practice for 2D floor plans in WebGL:
 * - meshBasicMaterial (unlit) so PNG/JPEG always render correctly
 * - horizontal plane on XZ (Y-up)
 * - no shadows / no PBR lighting on the image itself
 */
export default function ImagePlane({ url, onReady }) {
  const texture = useTexture(url);
  const [size, setSize] = useState([MAX_PLANE_SIZE, MAX_PLANE_SIZE]);

  useEffect(() => {
    if (!texture?.image) return;

    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = 16;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.needsUpdate = true;

    const img = texture.image;
    const aspect = img.width / img.height;
    let width = MAX_PLANE_SIZE;
    let height = MAX_PLANE_SIZE;
    if (aspect >= 1) {
      height = width / aspect;
    } else {
      width = height * aspect;
    }
    setSize([width, height]);
    onReady?.({ width, height, aspect });
  }, [texture, onReady]);

  return (
    <group>
      {/* White mat behind plan — prevents dark bleed-through */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.003, 0]}>
        <planeGeometry args={[size[0] + 0.4, size[1] + 0.4]} />
        <meshBasicMaterial color="#ffffff" toneMapped={false} />
      </mesh>

      {/* Floor plan image — unlit, always full brightness */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
        <planeGeometry args={size} />
        <meshBasicMaterial map={texture} toneMapped={false} transparent={false} />
      </mesh>
    </group>
  );
}
