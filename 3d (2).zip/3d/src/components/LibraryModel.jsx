import { Component, Suspense, useEffect, useMemo, useState } from 'react';
import { useGLTF } from '@react-three/drei';
import { getEffectiveShapeType } from '../utils/shapeLibrary';
import { ShapeGeometryInner } from './PlacedShape';

function PrimitiveFallback({ shapeType, color, emissiveIntensity }) {
  return (
    <ShapeGeometryInner
      shapeType={getEffectiveShapeType(shapeType)}
      color={color}
      emissiveIntensity={emissiveIntensity}
    />
  );
}

/** Verify response is a real GLB/GLTF (not Vite's HTML fallback) */
async function probeGlbUrl(modelUrl) {
  try {
    const res = await fetch(modelUrl);
    if (!res.ok) return false;
    const type = res.headers.get('content-type') || '';
    if (type.includes('text/html')) return false;
    const buf = await res.arrayBuffer();
    if (buf.byteLength < 4) return false;
    const magic = new DataView(buf).getUint32(0, true);
    return magic === 0x46546c67; // "glTF"
  } catch {
    return false;
  }
}

function useGlbAvailable(modelUrl) {
  const [available, setAvailable] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (!modelUrl) {
      setAvailable(false);
      setChecked(true);
      return undefined;
    }

    let cancelled = false;
    setChecked(false);

    probeGlbUrl(modelUrl).then((ok) => {
      if (!cancelled) {
        setAvailable(ok);
        setChecked(true);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [modelUrl]);

  return { available, checked };
}

function GlbModel({ url, color }) {
  const { scene } = useGLTF(url);
  const cloned = useMemo(() => {
    const c = scene.clone(true);
    c.traverse((child) => {
      if (child.isMesh && child.material) {
        child.material = child.material.clone();
        if (child.material.color) child.material.color.set(color || '#888');
      }
    });
    return c;
  }, [scene, color]);
  return <primitive object={cloned} scale={0.5} />;
}

class GlbErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }

  static getDerivedStateFromError() {
    return { failed: true };
  }

  render() {
    if (this.state.failed) return this.props.fallback;
    return this.props.children;
  }
}

function GlbLoader({ modelUrl, shapeType, color, emissiveIntensity }) {
  const fallback = (
    <PrimitiveFallback shapeType={shapeType} color={color} emissiveIntensity={emissiveIntensity} />
  );

  return (
    <GlbErrorBoundary fallback={fallback}>
      <Suspense fallback={fallback}>
        <GlbModel url={modelUrl} color={color} />
      </Suspense>
    </GlbErrorBoundary>
  );
}

/** GLB from shape library — primitive fallback when file is missing or load fails */
export default function LibraryModel({ modelUrl, shapeType, color, emissiveIntensity }) {
  const { available, checked } = useGlbAvailable(modelUrl);

  if (!modelUrl || (checked && !available)) {
    return (
      <PrimitiveFallback shapeType={shapeType} color={color} emissiveIntensity={emissiveIntensity} />
    );
  }

  if (!checked) {
    return (
      <PrimitiveFallback shapeType={shapeType} color={color} emissiveIntensity={emissiveIntensity} />
    );
  }

  return (
    <GlbLoader
      modelUrl={modelUrl}
      shapeType={shapeType}
      color={color}
      emissiveIntensity={emissiveIntensity}
    />
  );
}
