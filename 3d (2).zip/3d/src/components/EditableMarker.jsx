import { useState } from 'react';
import ObjectTransformGizmo from './ObjectTransformGizmo';
import MarkerPin from './MarkerPin';

export default function EditableMarker({
  marker,
  isSelected,
  transformMode,
  snapToGrid,
  gridSize,
  onTransformEnd,
  boardMode,
  ...markerProps
}) {
  const [groupObj, setGroupObj] = useState(null);
  const objectRef = { current: groupObj };

  if (marker.hidden) return null;

  return (
    <>
      <group ref={setGroupObj} position={marker.position}>
        <MarkerPin
          marker={marker}
          isSelected={isSelected}
          atOrigin
          boardMode={boardMode}
          disableInteraction={isSelected && !marker.locked}
          {...markerProps}
        />
      </group>
      {isSelected && !marker.locked && groupObj && (
        <ObjectTransformGizmo
          objectRef={objectRef}
          mode={transformMode}
          snapToGrid={snapToGrid}
          gridSize={gridSize}
          translateOnly
          onTransformEnd={({ position }) => onTransformEnd({ position })}
          enabled
        />
      )}
    </>
  );
}
