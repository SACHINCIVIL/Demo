import { useMemo, useState } from 'react';
import { getMarkerColor } from '../utils/markerUtils';
import { getShapeDef } from '../utils/shapeLibrary';
import { TRAFFIC_PATH_COLOR } from '../utils/trafficPathUtils';

export default function SceneHierarchy({
  markers,
  shapes,
  trafficPaths,
  selectedMarkerId,
  selectedShapeId,
  selectedTrafficPathId,
  onSelectMarker,
  onSelectShape,
  onSelectTrafficPath,
}) {
  const [query, setQuery] = useState('');

  const items = useMemo(() => {
    const list = [
      ...shapes.map((s) => ({
        id: s.id,
        kind: 'shape',
        name: s.name,
        sub: getShapeDef(s.shapeType).label,
        color: s.color,
        hidden: s.hidden,
        locked: s.locked,
      })),
      ...markers.map((m) => ({
        id: m.id,
        kind: 'marker',
        name: m.name,
        sub: m.type,
        color: getMarkerColor(m.type),
        hidden: m.hidden,
        locked: m.locked,
      })),
      ...trafficPaths.map((p) => ({
        id: p.id,
        kind: 'traffic',
        name: p.name,
        sub: `${p.points?.length || 0} points`,
        color: TRAFFIC_PATH_COLOR,
        hidden: false,
        locked: false,
      })),
    ];
    const q = query.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        item.sub.toLowerCase().includes(q) ||
        item.kind.includes(q)
    );
  }, [markers, shapes, trafficPaths, query]);

  const select = (item) => {
    if (item.kind === 'shape') onSelectShape(item.id);
    else if (item.kind === 'marker') onSelectMarker(item.id);
    else onSelectTrafficPath(item.id);
  };

  const isSelected = (item) => {
    if (item.kind === 'shape') return item.id === selectedShapeId;
    if (item.kind === 'marker') return item.id === selectedMarkerId;
    return item.id === selectedTrafficPathId;
  };

  return (
    <div className="scene-hierarchy">
      <input
        type="search"
        className="scene-hierarchy__search"
        placeholder="Search scene…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="scene-hierarchy__list">
        {items.length === 0 && <p className="scene-list-empty">No objects match.</p>}
        {items.map((item) => (
          <button
            key={`${item.kind}-${item.id}`}
            type="button"
            className={`scene-hierarchy__item ${isSelected(item) ? 'selected' : ''} ${item.hidden ? 'hidden-item' : ''}`}
            onClick={() => select(item)}>
            <span className="scene-list-dot" style={{ background: item.color }} />
            <span className="scene-hierarchy__text">
              <span className="scene-list-title">{item.name}</span>
              <span className="scene-list-sub">
                {item.kind} · {item.sub}
                {item.locked ? ' · 🔒' : ''}
                {item.hidden ? ' · hidden' : ''}
              </span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
