import { useThree } from '@react-three/fiber';
import { useEffect } from 'react';
import { focusCameraOnMarker } from '../utils/markerCamera';

/** Zooms orbit camera to the selected marker */
export default function CameraFocus({ marker, enabled = true }) {
  const { camera } = useThree();
  const controls = useThree((state) => state.controls);

  useEffect(() => {
    if (!enabled || !marker?.position || !controls) return undefined;

    return focusCameraOnMarker(camera, controls, marker.position, {
      distance: 2.6,
      duration: 420,
    });
  }, [marker?.id, enabled, camera, controls]);

  return null;
}
