import { TransformControls } from '@react-three/drei';
import { useThree } from '@react-three/fiber';
import { useEffect, useRef } from 'react';
import { snapEuler, snapPosition } from '../utils/snapUtils';

/**
 * Attach transform gizmo to a scene object ref.
 * Disables orbit controls while dragging.
 */
export default function ObjectTransformGizmo({
  objectRef,
  mode = 'translate',
  enabled = true,
  snapToGrid = false,
  gridSize = 0.25,
  translateOnly = false,
  onTransformEnd,
}) {
  const controlsRef = useRef();
  const orbit = useThree((state) => state.controls);
  const gizmoMode = translateOnly && mode !== 'translate' ? 'translate' : mode;

  useEffect(() => {
    const tc = controlsRef.current;
    if (!tc) return undefined;

    const onChange = (e) => {
      if (!e.value && orbit) orbit.enabled = true;
      else if (e.value && orbit) orbit.enabled = false;
    };

    tc.addEventListener('dragging-changed', onChange);
    return () => tc.removeEventListener('dragging-changed', onChange);
  }, [orbit]);

  const handleMouseUp = () => {
    const obj = objectRef?.current;
    if (!obj || !onTransformEnd) return;

    let position = obj.position.toArray();
    let rotation = [obj.rotation.x, obj.rotation.y, obj.rotation.z];
    const scale = obj.scale.toArray();

    if (snapToGrid) {
      position = snapPosition(position, gridSize);
      rotation = snapEuler(rotation);
      obj.position.set(...position);
      obj.rotation.set(...rotation);
    }

    onTransformEnd({ position, rotation, scale });
  };

  if (!enabled || !objectRef?.current) return null;

  return (
    <TransformControls
      ref={controlsRef}
      object={objectRef.current}
      mode={gizmoMode}
      size={0.8}
      onMouseUp={handleMouseUp}
    />
  );
}
