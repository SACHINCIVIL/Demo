import { useState } from 'react';
import { SHAPE_CATEGORIES, SHAPE_LIBRARY, getShapesByCategory } from '../utils/shapeLibrary';

export default function ShapeLibraryPanel({
  placementMode,
  activeShapeType,
  onSelectShape,
  onCancelPlacement,
  hasAsset,
}) {
  const [expanded, setExpanded] = useState(true);
  const [activeCategory, setActiveCategory] = useState('basic');

  const categoryShapes = getShapesByCategory(activeCategory);

  return (
    <aside className="shape-library-panel">
      <button
        type="button"
        className="shape-library-header"
        onClick={() => setExpanded((v) => !v)}>
        <span>
          <strong>Advanced</strong> — Shape Library
        </span>
        <span className="shape-library-toggle">{expanded ? '▲' : '▼'}</span>
      </button>

      {expanded && (
        <div className="shape-library-body">
          <p className="shape-library-hint">
            Pick a shape, then click on the model or floor plan to place it.
          </p>

          {!hasAsset && (
            <p className="shape-library-warning">Upload a 3D model or image first.</p>
          )}

          <div className="shape-category-tabs">
            {SHAPE_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                className={`shape-category-tab ${activeCategory === cat.id ? 'active' : ''}`}
                onClick={() => setActiveCategory(cat.id)}>
                {cat.label}
              </button>
            ))}
          </div>

          <div className="shape-grid">
            {categoryShapes.map((shape) => {
              const isActive =
                placementMode === 'shape' && activeShapeType === shape.id;
              return (
                <button
                  key={shape.id}
                  type="button"
                  disabled={!hasAsset}
                  draggable={hasAsset}
                  className={`shape-card ${isActive ? 'active' : ''}`}
                  onClick={() => onSelectShape(shape.id)}
                  onDragStart={(e) => {
                    e.dataTransfer.setData('shapeType', shape.id);
                    onSelectShape(shape.id);
                  }}
                  title={`${shape.label}${shape.modelUrl ? ' (GLB)' : ''}`}>
                  <span className="shape-icon" style={{ color: shape.color }}>
                    {shape.icon}
                  </span>
                  <span className="shape-label">{shape.label}</span>
                </button>
              );
            })}
          </div>

          {placementMode === 'shape' && (
            <div className="shape-placement-banner">
              <span>Placing: {SHAPE_LIBRARY.find((s) => s.id === activeShapeType)?.label}</span>
              <button type="button" onClick={onCancelPlacement}>
                Cancel
              </button>
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
