import { Center, OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { Canvas } from '@react-three/fiber';
import { Suspense, useCallback } from 'react';
import * as THREE from 'three';
import { getRotationFromNormal } from '../utils/markerUtils';
import MarkerPin from './MarkerPin';
import PlacedShape from './PlacedShape';
import CameraFocus from './CameraFocus';
import Model3D from './Model3D';
import TrafficPathLine from './TrafficPathLine';

function offsetFromSurface(point, normal, amount = 0.08) {
  const n = normal || { x: 0, y: 1, z: 0 };
  return [point.x + n.x * amount, point.y + n.y * amount, point.z + n.z * amount];
}

function ModelContent({
  asset,
  markers,
  shapes,
  trafficPaths,
  draftTrafficPathPoints,
  selectedTrafficPathId,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  onSurfacePlace,
  onTrafficPathPointAdd,
  onTrafficMarkerPlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  focusMarkerId,
}) {
  const focusMarker = focusMarkerId ? markers.find((m) => m.id === focusMarkerId) : null;

  const handleSurfacePointerDown = useCallback(
    (e) => {
      if (!placementMode || !asset?.url) return;
      e.stopPropagation();
      const point = e.point;
      const normal = e.face?.normal
        ? e.face.normal.clone().transformDirection(e.object.matrixWorld)
        : { x: 0, y: 1, z: 0 };

      if (placementMode === 'trafficPath') {
        onTrafficPathPointAdd?.([
          point.x + normal.x * 0.02,
          point.y + normal.y * 0.02,
          point.z + normal.z * 0.02,
        ]);
        return;
      }

      if (placementMode === 'trafficMarker') {
        onTrafficMarkerPlace?.(point);
        return;
      }

      const position = offsetFromSurface(point, normal, placementMode === 'shape' ? 0.12 : 0.06);
      const rotation = getRotationFromNormal(normal);
      onSurfacePlace(position, rotation, normal, e);
    },
    [placementMode, asset, onSurfacePlace, onTrafficPathPointAdd, onTrafficMarkerPlace]
  );

  return (
    <>
      <color attach="background" args={['#eef2f6']} />
      <ambientLight intensity={0.75} />
      <directionalLight position={[8, 12, 6]} intensity={1.2} castShadow />
      <directionalLight position={[-6, 4, -4]} intensity={0.4} />
      <gridHelper args={[24, 24, '#c5cdd8', '#dde3ea']} position={[0, -0.01, 0]} />

      <group onPointerDown={handleSurfacePointerDown}>
        <Suspense fallback={null}>
          <Center>
            <Model3D url={asset.url} />
          </Center>
        </Suspense>
      </group>

      {trafficPaths?.map((path) => (
        <TrafficPathLine
          key={path.id}
          path={path}
          isSelected={path.id === selectedTrafficPathId}
        />
      ))}

      {draftTrafficPathPoints?.length > 0 && (
        <TrafficPathLine
          path={{ id: 'draft', points: draftTrafficPathPoints }}
          isDraft
        />
      )}

      {shapes.map((shape) => (
        <PlacedShape
          key={shape.id}
          shape={shape}
          isSelected={shape.id === selectedShapeId}
          isHovered={shape.id === hoveredShapeId}
          onSelect={onShapeSelect}
          onHover={onShapeHover}
          onLeave={onShapeLeave}
        />
      ))}

      {markers.map((marker) => (
        <MarkerPin
          key={marker.id}
          marker={marker}
          isSelected={marker.id === selectedMarkerId}
          isHovered={marker.id === hoveredMarkerId}
          onSelect={onMarkerSelect}
          onHover={onMarkerHover}
          onLeave={onMarkerLeave}
        />
      ))}

      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={0.4}
        maxDistance={80}
      />

      {focusMarker && <CameraFocus marker={focusMarker} />}
    </>
  );
}

/** 3D model mode — perspective orbit (BIM / digital twin standard) */
export default function ModelViewer({
  asset,
  markers,
  shapes,
  trafficPaths,
  draftTrafficPathPoints,
  selectedTrafficPathId,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  activeShapeType,
  onSurfacePlace,
  onTrafficPathPointAdd,
  onTrafficMarkerPlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  clearSelection,
  focusMarkerId,
}) {
  const placementLabel =
    placementMode === 'marker'
      ? 'Click once on model — one marker per click'
      : placementMode === 'shape'
        ? `Click once to place: ${activeShapeType}`
        : placementMode === 'trafficPath'
          ? `Click model to add path points (${draftTrafficPathPoints?.length || 0})`
          : placementMode === 'trafficMarker'
            ? 'Click on the yellow traffic path to add a marker'
            : null;

  return (
    <div className="scene-wrap scene-wrap--model">
      <Canvas
        shadows
        onPointerMissed={() => {
          if (!placementMode) clearSelection?.();
        }}
        style={{ width: '100%', height: '100%' }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: 'high-performance',
        }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.NoToneMapping;
          gl.outputColorSpace = THREE.SRGBColorSpace;
        }}
        dpr={typeof window !== 'undefined' ? Math.min(window.devicePixelRatio, 2) : 1}>
        <PerspectiveCamera makeDefault position={[4, 3, 5]} fov={50} />
        <ModelContent
          asset={asset}
          markers={markers}
          shapes={shapes}
          trafficPaths={trafficPaths}
          draftTrafficPathPoints={draftTrafficPathPoints}
          selectedTrafficPathId={selectedTrafficPathId}
          selectedMarkerId={selectedMarkerId}
          selectedShapeId={selectedShapeId}
          hoveredMarkerId={hoveredMarkerId}
          hoveredShapeId={hoveredShapeId}
          placementMode={placementMode}
          onSurfacePlace={onSurfacePlace}
          onTrafficPathPointAdd={onTrafficPathPointAdd}
          onTrafficMarkerPlace={onTrafficMarkerPlace}
          onMarkerSelect={onMarkerSelect}
          onShapeSelect={onShapeSelect}
          onMarkerHover={onMarkerHover}
          onMarkerLeave={onMarkerLeave}
          onShapeHover={onShapeHover}
          onShapeLeave={onShapeLeave}
          focusMarkerId={focusMarkerId}
        />
      </Canvas>

      <div className="scene-asset-badge scene-asset-badge--model">3D model · Orbit view</div>

      {placementLabel && <div className="scene-placement-hint">{placementLabel}</div>}

      <div className="scene-controls-hint">
        Scroll to zoom · Drag to rotate · Right-drag to pan
      </div>
    </div>
  );
}
