import { Html } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';
import { getMarkerColor, truncate } from '../utils/markerUtils';
import { getMarkerScreenScale } from '../utils/markerCamera';

const _worldPos = new THREE.Vector3();

function MarkerTooltipCard({ marker }) {
  const displayName = truncate(marker.name, 20);
  return (
    <div className="marker-tooltip-3d">
      <div className="marker-tooltip-3d__title">
        {marker.type || 'equipment'}:
        <span>{displayName || '-'}</span>
      </div>
      <div className="marker-tooltip-3d__row">
        Marker ID: <span>{marker.id.slice(-8)}</span>
      </div>
    </div>
  );
}

export default function MarkerPin({
  marker,
  isSelected,
  isHovered,
  onSelect,
  onHover,
  onLeave,
  boardMode = false,
  atOrigin = false,
  disableInteraction = false,
}) {
  const groupRef = useRef();
  const { camera } = useThree();
  const color = getMarkerColor(marker.type);
  const highlight = isSelected || isHovered;

  useFrame(() => {
    if (!groupRef.current) return;
    const pos = atOrigin
      ? groupRef.current.getWorldPosition(_worldPos).toArray()
      : marker.position;
    const s = getMarkerScreenScale(camera, pos);
    groupRef.current.scale.setScalar(s);
  });

  if (marker.hidden) return null;

  return (
    <group ref={groupRef} position={atOrigin ? undefined : marker.position}>
      <mesh
        onClick={(e) => {
          if (disableInteraction || marker.locked) return;
          e.stopPropagation();
          onSelect(marker.id);
        }}
        onPointerOver={(e) => {
          if (disableInteraction) return;
          e.stopPropagation();
          document.body.style.cursor = marker.locked ? 'not-allowed' : 'pointer';
          onHover(marker.id);
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          document.body.style.cursor = 'auto';
          onLeave();
        }}>
        <sphereGeometry args={[0.09, 20, 20]} />
        <meshStandardMaterial
          color={color}
          emissive={highlight ? color : '#000000'}
          emissiveIntensity={isSelected ? 0.55 : isHovered ? 0.4 : 0.05}
        />
      </mesh>
      {boardMode ? (
        <mesh position={[0, 0, 0.11]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.018, 0.024, 0.14, 10]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ) : (
        <mesh position={[0, -0.14, 0]}>
          <cylinderGeometry args={[0.018, 0.024, 0.14, 10]} />
          <meshStandardMaterial color={color} />
        </mesh>
      )}

      {isHovered && !isSelected && (
        <Html
          center
          distanceFactor={6}
          style={{ pointerEvents: 'none' }}
          position={[0, boardMode ? 0.2 : 0.22, boardMode ? 0.15 : 0]}>
          <MarkerTooltipCard marker={marker} />
        </Html>
      )}
    </group>
  );
}
