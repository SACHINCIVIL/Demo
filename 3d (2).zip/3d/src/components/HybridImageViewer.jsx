import { useCallback, useRef, useState } from 'react';
import { getMarkerColor } from '../utils/markerUtils';
import { getShapeDef } from '../utils/shapeLibrary';

function MarkerOverlay({ marker, isSelected, isHovered, onSelect, onHover, onLeave }) {
  const [nx, ny] = marker.imageCoords || [0.5, 0.5];
  const color = getMarkerColor(marker.type);

  return (
    <button
      type="button"
      className={`hybrid-marker ${isSelected ? 'selected' : ''} ${isHovered ? 'hovered' : ''}`}
      style={{ left: `${nx * 100}%`, top: `${ny * 100}%`, '--marker-color': color }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(marker.id);
      }}
      onMouseEnter={() => onHover(marker.id)}
      onMouseLeave={onLeave}
      title={marker.name}>
      <span className="hybrid-marker-pin" />
      {(isSelected || isHovered) && <span className="hybrid-marker-label">{marker.name}</span>}
    </button>
  );
}

function ShapeOverlay({ shape, isSelected, isHovered, onSelect, onHover, onLeave }) {
  const [nx, ny] = shape.imageCoords || [0.5, 0.5];
  const def = getShapeDef(shape.shapeType);

  return (
    <button
      type="button"
      className={`hybrid-shape ${isSelected ? 'selected' : ''} ${isHovered ? 'hovered' : ''}`}
      style={{
        left: `${nx * 100}%`,
        top: `${ny * 100}%`,
        background: shape.color || def.color,
      }}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(shape.id);
      }}
      onMouseEnter={() => onHover(shape.id)}
      onMouseLeave={onLeave}
      title={shape.name}>
      <span className="hybrid-shape-icon">{def.icon}</span>
      {(isSelected || isHovered) && <span className="hybrid-marker-label">{shape.name}</span>}
    </button>
  );
}

/**
 * Sharp floor plan — native HTML <img> (like draw.io), NOT WebGL texture.
 * Image + markers share one flat board that zooms/pans together.
 */
export default function HybridImageViewer({
  asset,
  markers,
  shapes,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  activeShapeType,
  onImagePlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  clearSelection,
}) {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const dragRef = useRef(null);

  const handleOverlayClick = useCallback(
    (e) => {
      if (!placementMode) return;
      e.stopPropagation();
      const rect = e.currentTarget.getBoundingClientRect();
      const nx = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
      const ny = Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height));
      onImagePlace(nx, ny, placementMode, activeShapeType);
    },
    [placementMode, activeShapeType, onImagePlace]
  );

  const onWheel = useCallback((e) => {
    e.preventDefault();
    setZoom((z) => Math.min(5, Math.max(0.25, z - e.deltaY * 0.0015)));
  }, []);

  const onPointerDown = useCallback(
    (e) => {
      if (placementMode) return;
      if (e.button === 1 || e.button === 2 || e.altKey) {
        e.preventDefault();
        dragRef.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
      }
    },
    [placementMode, pan]
  );

  const onPointerMove = useCallback((e) => {
    if (!dragRef.current) return;
    setPan({
      x: dragRef.current.px + (e.clientX - dragRef.current.x),
      y: dragRef.current.py + (e.clientY - dragRef.current.y),
    });
  }, []);

  const onPointerUp = useCallback(() => {
    dragRef.current = null;
  }, []);

  const placementLabel =
    placementMode === 'marker'
      ? 'Click floor plan to place marker'
      : placementMode === 'shape'
        ? `Click to place: ${activeShapeType}`
        : null;

  return (
    <div
      className="hybrid-view"
      onWheel={onWheel}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onClick={() => {
        if (!placementMode) clearSelection?.();
      }}>
      <div
        className="hybrid-stage"
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}>
        <div className="hybrid-board">
          <img
            src={asset.url}
            alt={asset.fileName || 'Floor plan'}
            className="hybrid-img"
            draggable={false}
          />
          <div
            className="hybrid-overlay"
            style={{ cursor: placementMode ? 'crosshair' : 'default' }}
            onClick={handleOverlayClick}>
            {markers.map((m) => (
              <MarkerOverlay
                key={m.id}
                marker={m}
                isSelected={m.id === selectedMarkerId}
                isHovered={m.id === hoveredMarkerId}
                onSelect={onMarkerSelect}
                onHover={onMarkerHover}
                onLeave={onMarkerLeave}
              />
            ))}
            {shapes.map((s) => (
              <ShapeOverlay
                key={s.id}
                shape={s}
                isSelected={s.id === selectedShapeId}
                isHovered={s.id === hoveredShapeId}
                onSelect={onShapeSelect}
                onHover={onShapeHover}
                onLeave={onShapeLeave}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="scene-asset-badge">Floor plan · Flat board</div>
      {placementLabel && <div className="scene-placement-hint">{placementLabel}</div>}
      <div className="scene-controls-hint">
        Scroll to zoom · Right-drag or Alt+drag to pan
      </div>
    </div>
  );
}
