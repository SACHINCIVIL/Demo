import ModelViewer from './ModelViewer';
import UnifiedSceneViewer from './UnifiedSceneViewer';
import { useState } from 'react';

/** Images → UnifiedSceneViewer (Bounds fit). GLB/GLTF → ModelViewer (free orbit). */
export default function Scene3D(props) {
  const [boardSize, setBoardSize] = useState({ width: 12, height: 12 });

  if (!props.asset?.url) {
    return (
      <div className="scene-wrap">
        <div className="scene-hint">
          Upload a <strong>.glb</strong>, <strong>.gltf</strong>, <strong>.png</strong>, or{' '}
          <strong>.jpeg</strong> — images become a 3D board, models use full orbit controls
        </div>
      </div>
    );
  }

  if (props.asset.type === 'image') {
    return (
      <UnifiedSceneViewer
        {...props}
        boardSize={boardSize}
        onBoardReady={setBoardSize}
      />
    );
  }

  return <ModelViewer {...props} />;
}
