import { Image } from '@react-three/drei';
import { useEffect, useState } from 'react';
import * as THREE from 'three';

const BOARD_MAX = 10;

function BoardFrame({ w, h }) {
  const depth = 0.06;
  const pad = 0.22;
  return (
    <>
      <mesh position={[0, 0, -depth / 2 - 0.01]}>
        <boxGeometry args={[w + pad, h + pad, depth]} />
        <meshStandardMaterial color="#eceff1" roughness={0.9} />
      </mesh>
      <mesh position={[0, -h / 2 - 0.15, -depth / 2]}>
        <boxGeometry args={[w * 0.5, 0.05, depth]} />
        <meshStandardMaterial color="#b0bec5" roughness={0.8} />
      </mesh>
    </>
  );
}

export default function ImageBoard({ url, onReady }) {
  const [size, setSize] = useState(null);

  useEffect(() => {
    const img = new window.Image();
    img.onload = () => {
      const aspect = img.naturalWidth / img.naturalHeight;
      let w = BOARD_MAX;
      let h = BOARD_MAX;
      if (aspect >= 1) h = w / aspect;
      else w = h * aspect;
      const next = { w, h, aspect };
      setSize(next);
      onReady?.({ width: w, height: h, aspect });
    };
    img.src = url;
  }, [url, onReady]);

  if (!size) {
    return (
      <mesh>
        <planeGeometry args={[4, 3]} />
        <meshBasicMaterial color="#dde3ea" />
      </mesh>
    );
  }

  const { w, h } = size;

  return (
    <group name="image-board-root">
      <BoardFrame w={w} h={h} />
      <Image
        url={url}
        scale={[w, h]}
        toneMapped={false}
        transparent={false}
        position={[0, 0, 0.02]}
      />
      <mesh position={[0, 0, 0.03]} name="floor-plan-hit">
        <planeGeometry args={[w, h]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}
