import { MARKER_TYPES } from '../utils/markerUtils';

export default function MarkerPlacementDialog({
  open,
  defaultName,
  trafficOnly = false,
  onCancel,
  onConfirm,
}) {
  if (!open) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    onConfirm({
      name: String(fd.get('name') || defaultName),
      type: trafficOnly ? 'trafficFlow' : String(fd.get('type') || 'equipment'),
    });
  };

  return (
    <div className="dialog-overlay" onClick={onCancel}>
      <form className="dialog-box" onClick={(e) => e.stopPropagation()} onSubmit={handleSubmit}>
        <div className="dialog-header">
          <h3>{trafficOnly ? 'Add Traffic Flow Marker' : 'Add Marker'}</h3>
          <button type="button" className="dialog-close" onClick={onCancel}>
            ×
          </button>
        </div>
        <div className="dialog-body">
          <label className="dialog-label">
            Marker Name
            <input name="name" className="dialog-input" defaultValue={defaultName} autoFocus required />
          </label>
          {!trafficOnly && (
            <label className="dialog-label">
              Type
              <select name="type" className="dialog-input" defaultValue="equipment">
                {MARKER_TYPES.filter((t) => t.value !== 'trafficFlow').map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </label>
          )}
          {trafficOnly && (
            <p className="placement-hint-text traffic-only-hint">
              This marker is snapped to the <strong>yellow traffic path</strong>. Click off the path
              is not allowed.
            </p>
          )}
          {!trafficOnly && (
            <p className="placement-hint-text">
              One marker per placement. Click <strong>+ Add marker</strong> again to place another.
            </p>
          )}
        </div>
        <div className="dialog-footer">
          <button type="button" className="btn-danger" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn-primary">
            Place Marker
          </button>
        </div>
      </form>
    </div>
  );
}
