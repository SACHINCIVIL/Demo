import { getMarkerColor } from '../utils/markerUtils';

export default function MarkerSidebar({
  markers,
  selectedId,
  placementMode,
  onSelect,
  onTogglePlacement,
  onRemove,
}) {
  return (
    <aside style={sidebarStyle}>
      <div style={headerStyle}>
        <h2 style={{ margin: 0, fontSize: 16, color: '#12539E' }}>Markers</h2>
        <span style={{ fontSize: 12, color: '#888' }}>{markers.length} total</span>
      </div>

      <button
        type="button"
        onClick={onTogglePlacement}
        style={{
          ...placementBtnStyle,
          background: placementMode ? '#12539E' : '#E3F2FD',
          color: placementMode ? '#fff' : '#12539E',
        }}>
        {placementMode ? '✓ Placement mode ON — click model' : '+ Add marker (click model)'}
      </button>

      <div style={listStyle}>
        {markers.length === 0 && (
          <p style={{ color: '#999', fontSize: 13, textAlign: 'center', marginTop: 24 }}>
            No markers yet. Upload a model and enable placement mode.
          </p>
        )}
        {markers.map((marker, index) => {
          const isSelected = marker.id === selectedId;
          const color = getMarkerColor(marker.type);
          return (
            <div
              key={marker.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelect(marker.id)}
              onKeyDown={(e) => e.key === 'Enter' && onSelect(marker.id)}
              style={{
                ...itemStyle,
                background: isSelected ? '#E3F2FD' : '#fff',
                borderColor: isSelected ? '#12539E' : '#EAEAEA',
              }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span
                  style={{
                    width: 10,
                    height: 10,
                    borderRadius: '50%',
                    background: color,
                    flexShrink: 0,
                  }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {marker.name}
                  </div>
                  <div style={{ fontSize: 12, color: '#888', textTransform: 'capitalize' }}>
                    {marker.type} · #{index + 1}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemove(marker.id);
                  }}
                  style={removeBtnStyle}
                  title="Remove marker">
                  ×
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
}

const sidebarStyle = {
  width: 280,
  minWidth: 280,
  background: '#fff',
  borderRight: '1px solid #EAEAEA',
  display: 'flex',
  flexDirection: 'column',
  height: '100%',
};

const headerStyle = {
  padding: '12px 14px',
  borderBottom: '1px solid #EAEAEA',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
};

const placementBtnStyle = {
  margin: '10px 12px',
  padding: '10px 12px',
  border: '1px solid #12539E',
  borderRadius: 4,
  fontWeight: 600,
  fontSize: 13,
};

const listStyle = {
  flex: 1,
  overflowY: 'auto',
  padding: '0 8px 12px',
};

const itemStyle = {
  padding: '10px 10px',
  marginBottom: 6,
  border: '1px solid #EAEAEA',
  borderRadius: 4,
  cursor: 'pointer',
};

const removeBtnStyle = {
  border: 'none',
  background: 'transparent',
  color: '#d32f2f',
  fontSize: 18,
  lineHeight: 1,
  padding: '0 4px',
};
