import { useRef } from 'react';
import { getAcceptString } from '../utils/assetUtils';

export default function Toolbar({ onUpload, onReset, hasAsset, assetFileName, assetType, onExport }) {
  const fileRef = useRef();

  return (
    <header className="toolbar">
      <div className="toolbar-left">
        <h1>3D Scene Editor</h1>
        <span className="toolbar-sub">Draw.io-style 3D editor</span>
        {hasAsset && (
          <span className="toolbar-file">
            {assetType === 'image' ? '🖼' : '📦'} {assetFileName}
          </span>
        )}
      </div>
      <div className="toolbar-actions">
        <input
          ref={fileRef}
          type="file"
          accept={getAcceptString()}
          style={{ display: 'none' }}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onUpload(file);
            e.target.value = '';
          }}
        />
        <button type="button" className="btn-primary" onClick={() => fileRef.current?.click()}>
          Upload Model / Image
        </button>
        {hasAsset && (
          <>
            <button type="button" className="btn-secondary" onClick={onExport}>
              Export scene JSON
            </button>
            <button type="button" className="btn-danger" onClick={onReset}>
              Reset
            </button>
          </>
        )}
      </div>
    </header>
  );
}
