import { useEffect, useState } from 'react';
import { MARKER_TYPES } from '../utils/markerUtils';

export default function MarkerDetailsDialog({ marker, open, onClose, onSave, onDelete }) {
  const [name, setName] = useState('');
  const [type, setType] = useState('equipment');

  useEffect(() => {
    if (marker) {
      setName(marker.name || '');
      setType(marker.type || 'equipment');
    }
  }, [marker]);

  if (!open || !marker) return null;

  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={dialogStyle} onClick={(e) => e.stopPropagation()}>
        <div style={headerStyle}>
          <h3 style={{ margin: 0, color: '#12539E' }}>Marker Details</h3>
          <button type="button" onClick={onClose} style={closeBtnStyle}>
            ×
          </button>
        </div>
        <div style={{ padding: 16 }}>
          <label style={labelStyle}>
            Marker Name
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={inputStyle}
              placeholder="Enter marker name"
            />
          </label>
          <label style={labelStyle}>
            Type
            <select value={type} onChange={(e) => setType(e.target.value)} style={inputStyle}>
              {MARKER_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>
          <p style={{ fontSize: 13, color: '#666', margin: '12px 0 0' }}>
            Position: {marker.position.map((v) => v.toFixed(3)).join(', ')}
          </p>
        </div>
        <div style={footerStyle}>
          <button type="button" onClick={() => onDelete(marker.id)} style={deleteBtnStyle}>
            Delete
          </button>
          <button
            type="button"
            onClick={() => {
              const ok = onSave(marker.id, { name: name.trim() || 'Unnamed marker', type });
              if (ok !== false) onClose();
            }}
            style={saveBtnStyle}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

const overlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0,0,0,0.45)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 20000,
};

const dialogStyle = {
  background: '#fff',
  borderRadius: 8,
  width: 'min(420px, 92vw)',
  boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
};

const headerStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '12px 16px',
  borderBottom: '1px solid #EAEAEA',
};

const closeBtnStyle = {
  border: 'none',
  background: 'transparent',
  fontSize: 24,
  lineHeight: 1,
  color: '#666',
};

const labelStyle = {
  display: 'block',
  fontSize: 14,
  fontWeight: 600,
  color: '#555',
  marginBottom: 12,
};

const inputStyle = {
  display: 'block',
  width: '100%',
  marginTop: 6,
  padding: '8px 10px',
  border: '1px solid #ddd',
  borderRadius: 4,
  fontSize: 14,
};

const footerStyle = {
  display: 'flex',
  justifyContent: 'flex-end',
  gap: 8,
  padding: '12px 16px',
  borderTop: '1px solid #EAEAEA',
};

const deleteBtnStyle = {
  padding: '8px 16px',
  border: '1px solid #d32f2f',
  background: '#fff',
  color: '#d32f2f',
  borderRadius: 4,
};

const saveBtnStyle = {
  padding: '8px 16px',
  border: 'none',
  background: '#12539E',
  color: '#fff',
  borderRadius: 4,
};
