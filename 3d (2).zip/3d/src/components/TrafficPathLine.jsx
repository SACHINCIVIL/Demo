import { Line } from '@react-three/drei';
import { useMemo } from 'react';
import { TRAFFIC_PATH_COLOR } from '../utils/trafficPathUtils';

export default function TrafficPathLine({ path, isSelected, isDraft }) {
  const points = useMemo(() => {
    if (!path?.points?.length) return [];
    return path.points.map(([x, y, z = 0.14]) => [x, y, z]);
  }, [path?.points]);

  if (points.length < 2) return null;

  const color = isDraft ? '#f4d03f' : isSelected ? '#e6a800' : TRAFFIC_PATH_COLOR;

  return (
    <Line
      points={points}
      color={color}
      lineWidth={isSelected ? 4 : 3}
      transparent
      opacity={isDraft ? 0.85 : 1}
    />
  );
}
