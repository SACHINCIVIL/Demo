import { useEffect, useState } from 'react';
import { SHAPE_LIBRARY } from '../utils/shapeLibrary';

export default function ShapeDetailsDialog({ shape, open, onClose, onSave, onDelete }) {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#1976d2');
  const [scaleX, setScaleX] = useState(1);
  const [scaleY, setScaleY] = useState(1);
  const [scaleZ, setScaleZ] = useState(1);

  useEffect(() => {
    if (!shape) return;
    setName(shape.name || '');
    setColor(shape.color || '#1976d2');
    setScaleX(shape.scale?.[0] ?? 1);
    setScaleY(shape.scale?.[1] ?? 1);
    setScaleZ(shape.scale?.[2] ?? 1);
  }, [shape]);

  if (!open || !shape) return null;

  const shapeDef = SHAPE_LIBRARY.find((s) => s.id === shape.shapeType);

  return (
    <div className="dialog-overlay" onClick={onClose}>
      <div className="dialog-box" onClick={(e) => e.stopPropagation()}>
        <div className="dialog-header">
          <h3>Shape Details</h3>
          <button type="button" className="dialog-close" onClick={onClose}>
            ×
          </button>
        </div>
        <div className="dialog-body">
          <label className="dialog-label">
            Name
            <input value={name} onChange={(e) => setName(e.target.value)} className="dialog-input" />
          </label>
          <label className="dialog-label">
            Type
            <input value={shapeDef?.label || shape.shapeType} disabled className="dialog-input" />
          </label>
          <label className="dialog-label">
            Color
            <input
              type="color"
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="dialog-input"
            />
          </label>
          <div className="scale-row">
            <label className="dialog-label">
              Scale X
              <input
                type="number"
                min="0.05"
                step="0.05"
                value={scaleX}
                onChange={(e) => setScaleX(Number(e.target.value))}
                className="dialog-input"
              />
            </label>
            <label className="dialog-label">
              Scale Y
              <input
                type="number"
                min="0.05"
                step="0.05"
                value={scaleY}
                onChange={(e) => setScaleY(Number(e.target.value))}
                className="dialog-input"
              />
            </label>
            <label className="dialog-label">
              Scale Z
              <input
                type="number"
                min="0.05"
                step="0.05"
                value={scaleZ}
                onChange={(e) => setScaleZ(Number(e.target.value))}
                className="dialog-input"
              />
            </label>
          </div>
        </div>
        <div className="dialog-footer">
          <button type="button" className="btn-danger" onClick={() => onDelete(shape.id)}>
            Delete
          </button>
          <button
            type="button"
            className="btn-primary"
            onClick={() => {
              onSave(shape.id, {
                name: name.trim() || shapeDef?.label || 'Shape',
                color,
                scale: [scaleX, scaleY, scaleZ],
              });
              onClose();
            }}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
}
