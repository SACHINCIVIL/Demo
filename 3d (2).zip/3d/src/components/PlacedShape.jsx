import { Html } from '@react-three/drei';
import { forwardRef, useImperativeHandle, useMemo, useRef } from 'react';
import LibraryModel from './LibraryModel';
import { getShapeDef } from '../utils/shapeLibrary';

export function ShapeGeometryInner({ shapeType, color, emissiveIntensity }) {
  if (shapeType === 'arrow') return <ArrowShape color={color} emissiveIntensity={emissiveIntensity} />;
  if (shapeType === 'traffic') return <TrafficShape color={color} emissiveIntensity={emissiveIntensity} />;
  if (shapeType === 'drain') {
    return (
      <group>
        <mesh>
          <cylinderGeometry args={[0.35, 0.35, 0.05, 24]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
        </mesh>
        <mesh position={[0, 0.03, 0]}>
          <torusGeometry args={[0.2, 0.03, 8, 24]} />
          <meshStandardMaterial color="#1b5e20" />
        </mesh>
      </group>
    );
  }
  if (shapeType === 'tank') {
    return (
      <group>
        <mesh>
          <cylinderGeometry args={[0.35, 0.35, 0.7, 24]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
        </mesh>
        <mesh position={[0, 0.45, 0]}>
          <sphereGeometry args={[0.2, 16, 16]} />
          <meshStandardMaterial color="#0d47a1" />
        </mesh>
      </group>
    );
  }

  const mat = <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />;

  switch (shapeType) {
    case 'sphere':
      return (
        <mesh>
          <sphereGeometry args={[1, 24, 24]} />
          {mat}
        </mesh>
      );
    case 'cylinder':
      return (
        <mesh>
          <cylinderGeometry args={[1, 1, 1, 24]} />
          {mat}
        </mesh>
      );
    case 'cone':
      return (
        <mesh>
          <coneGeometry args={[1, 1, 24]} />
          {mat}
        </mesh>
      );
    case 'torus':
      return (
        <mesh>
          <torusGeometry args={[1, 0.35, 16, 32]} />
          {mat}
        </mesh>
      );
    case 'plane':
      return (
        <mesh>
          <boxGeometry args={[1, 1, 1]} />
          {mat}
        </mesh>
      );
    case 'capsule':
      return (
        <mesh>
          <capsuleGeometry args={[1, 1, 8, 16]} />
          {mat}
        </mesh>
      );
    case 'octahedron':
      return (
        <mesh>
          <octahedronGeometry args={[1, 0]} />
          {mat}
        </mesh>
      );
    default:
      return (
        <mesh>
          <boxGeometry args={[1, 1, 1]} />
          {mat}
        </mesh>
      );
  }
}

function ArrowShape({ color, emissiveIntensity }) {
  return (
    <group>
      <mesh position={[0, 0.15, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 0.3, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh position={[0, 0.38, 0]}>
        <coneGeometry args={[0.14, 0.22, 12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
      </mesh>
    </group>
  );
}

function TrafficShape({ color, emissiveIntensity }) {
  return (
    <group rotation={[0, 0, -Math.PI / 2]}>
      <mesh position={[0.15, 0, 0]}>
        <boxGeometry args={[0.5, 0.08, 0.12]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
      </mesh>
      <mesh position={[-0.1, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <coneGeometry args={[0.1, 0.2, 3]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={emissiveIntensity} />
      </mesh>
    </group>
  );
}

const PlacedShape = forwardRef(function PlacedShape(
  {
    shape,
    isSelected,
    isHovered,
    onSelect,
    onHover,
    onLeave,
    disableInteraction = false,
  },
  ref
) {
  const groupRef = useRef();
  useImperativeHandle(ref, () => groupRef.current);

  const emissiveIntensity = isSelected ? 0.45 : isHovered ? 0.3 : 0.05;
  const highlight = isSelected || isHovered;
  const def = getShapeDef(shape.shapeType);

  const euler = useMemo(() => shape.rotation || [0, 0, 0], [shape.rotation]);

  if (shape.hidden) return null;

  return (
    <group
      ref={groupRef}
      position={shape.position}
      rotation={euler}
      scale={shape.scale || [1, 1, 1]}
      onClick={(e) => {
        if (disableInteraction || shape.locked) return;
        e.stopPropagation();
        onSelect(shape.id);
      }}
      onPointerOver={(e) => {
        if (disableInteraction) return;
        e.stopPropagation();
        document.body.style.cursor = shape.locked ? 'not-allowed' : 'pointer';
        onHover(shape.id);
      }}
      onPointerOut={(e) => {
        e.stopPropagation();
        document.body.style.cursor = 'auto';
        onLeave();
      }}>
      <LibraryModel
        modelUrl={shape.modelUrl || def.modelUrl}
        shapeType={shape.shapeType}
        color={shape.color}
        emissiveIntensity={emissiveIntensity}
      />
      {highlight && (
        <Html distanceFactor={10} style={{ pointerEvents: 'none' }}>
          <div
            className="shape-label-3d"
            style={{ borderColor: shape.color }}>
            {shape.name}
            {shape.locked && ' 🔒'}
          </div>
        </Html>
      )}
    </group>
  );
});

export default PlacedShape;
