import { useEffect, useState } from 'react';
import { getShapeDef } from '../utils/shapeLibrary';

function Vec3Input({ label, value, onChange, disabled }) {
  const [local, setLocal] = useState(value || [0, 0, 0]);

  useEffect(() => {
    setLocal(value || [0, 0, 0]);
  }, [value]);

  const update = (index, v) => {
    const next = [...local];
    next[index] = Number(v) || 0;
    setLocal(next);
    onChange(next);
  };

  return (
    <div className="props-vec3">
      <span className="props-vec3__label">{label}</span>
      {['X', 'Y', 'Z'].map((axis, i) => (
        <label key={axis} className="props-vec3__axis">
          {axis}
          <input
            type="number"
            step="0.05"
            disabled={disabled}
            value={Number(local[i]?.toFixed(3) ?? 0)}
            onChange={(e) => update(i, e.target.value)}
          />
        </label>
      ))}
    </div>
  );
}

export default function PropertiesPanel({
  selectedShape,
  selectedMarker,
  onUpdateShape,
  onUpdateMarker,
  onDuplicateShape,
  onDuplicateMarker,
  onDeleteShape,
  onDeleteMarker,
}) {
  const target = selectedShape || selectedMarker;
  const isShape = Boolean(selectedShape);

  if (!target) {
    return (
      <aside className="properties-panel">
        <div className="properties-panel__header">
          <strong>Properties</strong>
        </div>
        <p className="properties-panel__empty">Select an object to edit transform, lock, or hide.</p>
      </aside>
    );
  }

  const def = isShape ? getShapeDef(target.shapeType) : null;
  const locked = Boolean(target.locked);
  const hidden = Boolean(target.hidden);

  const patch = (fields) => {
    if (isShape) onUpdateShape(target.id, fields);
    else onUpdateMarker(target.id, fields);
  };

  return (
    <aside className="properties-panel">
      <div className="properties-panel__header">
        <strong>Properties</strong>
        <span className="properties-panel__type">
          {isShape ? def?.label || target.shapeType : target.type}
        </span>
      </div>

      <div className="properties-panel__body">
        <label className="props-field">
          Name
          <input
            type="text"
            value={target.name || ''}
            disabled={locked}
            onChange={(e) => patch({ name: e.target.value })}
          />
        </label>

        <Vec3Input
          label="Position"
          value={target.position}
          disabled={locked}
          onChange={(position) => patch({ position })}
        />

        {isShape && (
          <>
            <Vec3Input
              label="Rotation"
              value={target.rotation || [0, 0, 0]}
              disabled={locked}
              onChange={(rotation) => patch({ rotation })}
            />
            <Vec3Input
              label="Scale"
              value={target.scale || [1, 1, 1]}
              disabled={locked}
              onChange={(scale) => patch({ scale })}
            />
          </>
        )}

        <div className="props-toggles">
          <label className="props-toggle">
            <input
              type="checkbox"
              checked={locked}
              onChange={(e) => patch({ locked: e.target.checked })}
            />
            Lock object
          </label>
          <label className="props-toggle">
            <input
              type="checkbox"
              checked={hidden}
              onChange={(e) => patch({ hidden: e.target.checked })}
            />
            Hide object
          </label>
        </div>

        <div className="props-actions">
          <button
            type="button"
            className="btn-secondary btn-small"
            disabled={locked}
            onClick={() => (isShape ? onDuplicateShape(target.id) : onDuplicateMarker(target.id))}>
            Duplicate
          </button>
          <button
            type="button"
            className="btn-danger btn-small"
            onClick={() => (isShape ? onDeleteShape(target.id) : onDeleteMarker(target.id))}>
            Delete
          </button>
        </div>
      </div>
    </aside>
  );
}
