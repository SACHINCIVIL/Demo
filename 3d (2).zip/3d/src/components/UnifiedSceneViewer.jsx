import { Bounds, Center, OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { Canvas } from '@react-three/fiber';
import { Suspense, useCallback, useRef } from 'react';
import * as THREE from 'three';
import { getRotationFromNormal, resolveMarkerPosition, resolveShapePosition } from '../utils/markerUtils';
import MarkerPin from './MarkerPin';
import CameraFocus from './CameraFocus';
import ImageBoard from './ImageBoard';
import Model3D from './Model3D';
import PlacedShape from './PlacedShape';
import TextureEnhancer from './TextureEnhancer';
import TrafficPathLine from './TrafficPathLine';

function SceneContent({
  asset,
  boardSize,
  onBoardReady,
  markers,
  shapes,
  trafficPaths,
  draftTrafficPathPoints,
  selectedTrafficPathId,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  onSurfacePlace,
  onTrafficPathPointAdd,
  onTrafficMarkerPlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  focusMarkerId,
}) {
  const isImage = asset?.type === 'image';
  const boundsRef = useRef(null);
  const focusMarker = focusMarkerId ? markers.find((m) => m.id === focusMarkerId) : null;
  const resolvedFocusMarker =
    focusMarker && isImage
      ? { ...focusMarker, position: resolveMarkerPosition(focusMarker, boardSize) }
      : focusMarker;

  const handleSurfacePointerDown = useCallback(
    (e) => {
      if (!placementMode || !asset?.url) return;
      e.stopPropagation();
      const point = e.point;

      if (placementMode === 'trafficPath') {
        const z = isImage ? 0.14 : point.z + 0.02;
        onTrafficPathPointAdd?.([point.x, point.y, z]);
        return;
      }

      if (placementMode === 'trafficMarker') {
        onTrafficMarkerPlace?.(point, boardSize);
        return;
      }

      let normal = { x: 0, y: 0, z: 1 };
      if (!isImage && e.face?.normal) {
        normal = e.face.normal.clone().transformDirection(e.object.matrixWorld);
      }
      const offset = placementMode === 'shape' ? 0.2 : 0.15;
      const position = isImage
        ? [point.x, point.y, offset]
        : [
            point.x + normal.x * offset,
            point.y + normal.y * offset,
            point.z + normal.z * offset,
          ];
      const rotation = getRotationFromNormal(isImage ? { x: 0, y: 0, z: 1 } : normal);
      onSurfacePlace(position, rotation, normal, e);
    },
    [
      placementMode,
      asset,
      isImage,
      onSurfacePlace,
      onTrafficPathPointAdd,
      onTrafficMarkerPlace,
      boardSize,
    ]
  );

  const boardContent = (
    <>
      <group onPointerDown={handleSurfacePointerDown}>
        <Suspense fallback={null}>
          {isImage ? (
            <ImageBoard url={asset.url} onReady={onBoardReady} />
          ) : (
            <Center>
              <Model3D url={asset.url} />
            </Center>
          )}
        </Suspense>
      </group>

      {trafficPaths?.map((path) => (
        <TrafficPathLine
          key={path.id}
          path={path}
          isSelected={path.id === selectedTrafficPathId}
        />
      ))}

      {draftTrafficPathPoints?.length > 0 && (
        <TrafficPathLine
          path={{ id: 'draft', points: draftTrafficPathPoints }}
          isDraft
        />
      )}

      {shapes.map((shape) => {
        const pos = isImage ? resolveShapePosition(shape, boardSize) : shape.position;
        return (
          <PlacedShape
            key={shape.id}
            shape={{ ...shape, position: pos }}
            isSelected={shape.id === selectedShapeId}
            isHovered={shape.id === hoveredShapeId}
            onSelect={onShapeSelect}
            onHover={onShapeHover}
            onLeave={onShapeLeave}
          />
        );
      })}

      {markers.map((marker) => {
        const pos = isImage ? resolveMarkerPosition(marker, boardSize) : marker.position;
        return (
          <MarkerPin
            key={marker.id}
            marker={{ ...marker, position: pos }}
            boardMode={isImage}
            isSelected={marker.id === selectedMarkerId}
            isHovered={marker.id === hoveredMarkerId}
            onSelect={onMarkerSelect}
            onHover={onMarkerHover}
            onLeave={onMarkerLeave}
          />
        );
      })}
    </>
  );

  return (
    <>
      <color attach="background" args={['#dde3ea']} />
      <ambientLight intensity={0.95} />
      <directionalLight position={[5, 8, 10]} intensity={0.5} />
      <directionalLight position={[-5, 2, 4]} intensity={0.25} />

      <gridHelper args={[40, 40, '#b0bec5', '#cfd8dc']} position={[0, -6, 0]} />

      {isImage && (
        <Suspense fallback={null}>
          <TextureEnhancer url={asset.url} />
        </Suspense>
      )}

      {/* Bounds auto-fits camera to full board on load */}
      <Bounds
        ref={boundsRef}
        fit
        clip
        observe
        margin={isImage ? 1.55 : 1.35}
        maxDuration={0.6}>
        {boardContent}
      </Bounds>

      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={0.5}
        maxDistance={150}
      />

      {resolvedFocusMarker && <CameraFocus marker={resolvedFocusMarker} />}
    </>
  );
}

export default function UnifiedSceneViewer({
  asset,
  markers,
  shapes,
  trafficPaths,
  draftTrafficPathPoints,
  selectedTrafficPathId,
  selectedMarkerId,
  selectedShapeId,
  hoveredMarkerId,
  hoveredShapeId,
  placementMode,
  activeShapeType,
  onSurfacePlace,
  onTrafficPathPointAdd,
  onTrafficMarkerPlace,
  onMarkerSelect,
  onShapeSelect,
  onMarkerHover,
  onMarkerLeave,
  onShapeHover,
  onShapeLeave,
  clearSelection,
  boardSize,
  onBoardReady,
  focusMarkerId,
}) {
  const isImage = asset?.type === 'image';

  const placementLabel =
    placementMode === 'marker'
      ? 'Click once on the board — one marker per click'
      : placementMode === 'shape'
        ? `Click once to place: ${activeShapeType}`
        : placementMode === 'trafficPath'
          ? `Click to add path points (${draftTrafficPathPoints?.length || 0}) — Finish in sidebar`
          : placementMode === 'trafficMarker'
            ? 'Click on the yellow traffic path to add a marker'
            : null;

  return (
    <div className="scene-wrap">
      <Canvas
        shadows={!isImage}
        onPointerMissed={() => {
          if (!placementMode) clearSelection?.();
        }}
        style={{ width: '100%', height: '100%' }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: 'high-performance',
        }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.NoToneMapping;
          gl.outputColorSpace = THREE.SRGBColorSpace;
        }}
        dpr={typeof window !== 'undefined' ? Math.min(window.devicePixelRatio, 2) : 1}>
        <PerspectiveCamera makeDefault fov={45} near={0.1} far={800} position={[0, 0, 20]} />
        <SceneContent
          key={asset.url}
          asset={asset}
          boardSize={boardSize}
          onBoardReady={onBoardReady}
          markers={markers}
          shapes={shapes}
          trafficPaths={trafficPaths}
          draftTrafficPathPoints={draftTrafficPathPoints}
          selectedTrafficPathId={selectedTrafficPathId}
          selectedMarkerId={selectedMarkerId}
          selectedShapeId={selectedShapeId}
          hoveredMarkerId={hoveredMarkerId}
          hoveredShapeId={hoveredShapeId}
          placementMode={placementMode}
          onSurfacePlace={onSurfacePlace}
          onTrafficPathPointAdd={onTrafficPathPointAdd}
          onTrafficMarkerPlace={onTrafficMarkerPlace}
          onMarkerSelect={onMarkerSelect}
          onShapeSelect={onShapeSelect}
          onMarkerHover={onMarkerHover}
          onMarkerLeave={onMarkerLeave}
          onShapeHover={onShapeHover}
          onShapeLeave={onShapeLeave}
          focusMarkerId={focusMarkerId}
        />
      </Canvas>

      {isImage && <div className="scene-asset-badge">3D floor plan board</div>}
      {!isImage && asset?.url && (
        <div className="scene-asset-badge scene-asset-badge--model">3D model</div>
      )}

      {placementLabel && <div className="scene-placement-hint">{placementLabel}</div>}

      <div className="scene-controls-hint">
        Scroll to zoom · Drag to rotate · Right-drag to pan
      </div>
    </div>
  );
}
