# 3D Model Library

Drop GLB files here to load from the shape library **3D Models** category:

- `pump.glb`
- `valve.glb`
- `motor.glb`
- `pipe.glb`

If a file is missing, the editor uses a primitive mesh fallback automatically.
